/*
 * Ejemplo de uso de la interfaz ActionListener
 */
package ejemplointerfazactionlistener;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class EjemploInterfazActionListener extends JFrame implements ActionListener {

    JButton botonBeep1, botonBeep2;
    JPanel panel;
    
    public EjemploInterfazActionListener() {
        // Creamos los objetos gráficos ;
        botonBeep1 = new JButton ("Un pitido" );
        botonBeep2 = new JButton ("Dos pitidos" );
        panel = new JPanel();

        // Añadimos los componentes al panel
        panel.add (botonBeep1);
        panel.add (botonBeep2);
        
        // Añadimos el panel al frame
        this.getContentPane().add (panel);
        
        // Establecer como oyente del botón al frame (esta clase) (la clase principal de la aplicación)
        botonBeep1.addActionListener(this);
        botonBeep2.addActionListener(this);
    }

    // Implementación del método actionPerformed para recibir la llegada de eventos
    public void actionPerformed(ActionEvent evento) {
        // Obtenemos el botón que disparó el evento)
        JButton botonPulsado= (JButton) evento.getSource();
        // Generar uno o dos sonidos dependiendo del botón pulsado
        if (botonPulsado == botonBeep1) {
            Toolkit.getDefaultToolkit().beep();    // Un beep       
        } else if (botonPulsado == botonBeep2) {   // Dos beeps 
            Toolkit.getDefaultToolkit().beep();      
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
            }
            Toolkit.getDefaultToolkit().beep();           
        }
    }

    public static void main(String[] args) {
            // Crear la ventana
            EjemploInterfazActionListener ventana = new EjemploInterfazActionListener() ;
            
            // Establecer el título, el tamaño y hacerla visible 
            ventana.setTitle("Ejemplo de la interfaz ActionListener");
            ventana.setSize(350, 80);
            ventana.setVisible(true);

    
    }

}
