/*
 * Clase Profesor
 */
package ejemplopolimorfismopersona;

/**

 */
import java.util.*;
import java.text.*;

/**
 *
 * Clase Profesor
 */
public class Profesor extends Persona {
	String especialidad;
	double salario; 
        
        // Constructores
        // -------------

        public Profesor (String nombre, String apellidos, GregorianCalendar fechaNacim, String especialidad, double salario) {
            super (nombre, apellidos, fechaNacim);
            this.especialidad= especialidad;
            this.salario= salario;            
        }
        
        public Profesor (String nombre, String apellidos, GregorianCalendar fechaNacim) {
            super (nombre, apellidos, fechaNacim);
            // Valores por omisión para un profesor: especialidad "GEN" y sueldo de 1000 euros.
            this.especialidad= "GEN";
            this.salario= 1000;                        
        }

        // Métodos get
        // -----------
        
        // Método getEspecialidad
        public String getEspecialidad (){
            return especialidad;
        }

        // Método getSalario
        public double getSalario (){
            return salario;
        }

        // Métodos set
        // -----------

        // Método setSalario
        public void setSalario (double salario){
            this.salario= salario;
        }
        
        // Método setESpecialidad
        public void setESpecialidad (String especialidad){
            this.especialidad= especialidad;
        }

        
        // Redefinición de los métodos de la interfaz Imprimible
        // -------------------------------------------------------
        
        // Método devolverContenidoHashtable 
        @Override
        public Hashtable devolverContenidoHashtable () {
            // Llamada al método de la superclase
            Hashtable contenido= super.devolverContenidoHashtable();
            // Añadimos los atributos específicos
            contenido.put ("salario", this.salario);
            contenido.put ("especialidad", this.especialidad);
            // Devolvemos la Hashtable rellena                       
            return contenido;
        }
        
        // Método devolverContenidoArrayList
        @Override
        public ArrayList devolverContenidoArrayList () {
            // Llamada al método de la superclase
            ArrayList contenido= super.devolverContenidoArrayList ();            
            // Añadimos los atributos específicos
            contenido.add(this.salario);
            contenido.add (this.especialidad);
            // Devolvemos el ArrayList relleno
            return contenido;
        }
        
        // Método devolverContenidoString
        @Override
        public String devolverContenidoString () {
            // Aprovechamos el método estático para transformar una Hashtable en String
            String contenido= Persona.HashtableToString(this.devolverContenidoHashtable());
            // Devolvemos el String creado.
            return contenido;
        }
        
}

