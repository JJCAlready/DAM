/*
 * Interfaz Imprimible
 */
package ejemplopolimorfismopersona;

import java.util.Hashtable;
import java.util.ArrayList;

/**
 *
 * Interfaz Imprimible
 */
public interface Imprimible {
	String devolverContenidoString ();
	ArrayList devolverContenidoArrayList (); 
	Hashtable devolverContenidoHashtable (); 

}
