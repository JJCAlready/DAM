/*
 * Clase Alumno.
 */
package ejemplopolimorfismopersona;
import java.util.*;
import java.text.*;

/**
 *
 * Clase Alumno
 */
public class Alumno extends Persona  {
        protected String grupo;
        protected double notaMedia; 
    
        
        // Constructores
        // -------------
        public Alumno (String nombre, String apellidos, GregorianCalendar fechaNacim, String grupo, double notaMedia) {
            super (nombre, apellidos, fechaNacim);
            this.grupo= grupo;
            this.notaMedia= notaMedia;            
        }
        
        public Alumno (String nombre, String apellidos, GregorianCalendar fechaNacim) {
            super (nombre, apellidos, fechaNacim);
            // Valores por omisión para un alumno: Grupo "GEN" y nota media de 0.
            this.grupo= "GEN";
            this.notaMedia= 0;                        
        }
        
        // Métodos get
        // ------------
        
        // Método getGrupo
        public String getGrupo (){
            return grupo;
        }

        // Método getNotaMedia
        public double getNotaMedia (){
            return notaMedia;
        }

        // Métodos set
        // -----------

        // Método setGrupo
        public void setGrupo (String grupo){
            this.grupo= grupo;
        }
        
        // Método setNotaMedia
        public void setNotaMedia (double notaMedia){
            this.notaMedia= notaMedia;
        }
        
        // Redefinición de los métodos de la interfaz Imprimible
        // -------------------------------------------------------
        
        // Método devolverContenidoHashtable 
        @Override
        public Hashtable devolverContenidoHashtable () {
            // Llamada al método de la superclase
            Hashtable contenido= super.devolverContenidoHashtable();
            // Añadimos los atributos específicos
            contenido.put ("grupo", this.grupo);
            contenido.put ("notaMedia", this.notaMedia);
            // Devolvemos la Hashtable rellena                       
            return contenido;
        }
        
        // Método devolverContenidoArray
        @Override
        public ArrayList devolverContenidoArrayList () {
            // Llamada al método de la superclase
            ArrayList contenido= super.devolverContenidoArrayList ();            
            // Añadimos los atributos específicos
            contenido.add(this.grupo);
            contenido.add (this.notaMedia);
            // Devolvemos el ArrayList relleno
            return contenido;
        }
        
        // Método devolverContenidoString
        @Override
        public String devolverContenidoString () {
            // Aprovechamos el método estático para transformar una Hashtable en String
            String contenido= Persona.HashtableToString(this.devolverContenidoHashtable());
            // Devolvemos el String creado.
            return contenido;
        }

        
        
}

