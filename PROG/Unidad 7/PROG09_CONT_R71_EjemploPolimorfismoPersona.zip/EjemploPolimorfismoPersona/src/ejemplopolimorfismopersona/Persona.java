/*
 * Clase Persona
 */
package ejemplopolimorfismopersona;

import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.text.SimpleDateFormat;
/**
 * Clase Persona
 */
public abstract class Persona implements Imprimible {
        protected String nombre;
        protected String apellidos;
        protected GregorianCalendar fechaNacim;

        // Constructores
        // -------------
                
        // Constructor
        public Persona (String nombre, String apellidos, GregorianCalendar fechaNacim) {           
            this.nombre= nombre;
            this.apellidos= apellidos;
            this.fechaNacim= (GregorianCalendar) fechaNacim.clone();
        }
        
        // Métodos get
        // -------------
        
        // Método getNombre
        protected String getNombre (){
            return nombre;
        }
        
        // Método getApellidos
        protected String getApellidos (){
            return apellidos;
        }
        
        // Método getFechaNacim
        protected GregorianCalendar getFechaNacim (){
            return this.fechaNacim;
        }

        // Métodos set
        // -------------

        // Método setNombre
        protected void setNombre (String nombre){
            this.nombre= nombre;
        }
        
        // Método setApellidos
        protected void setApellidos (String apellidos){
            this.apellidos= apellidos;
        }
        
        // Método setFechaNacim
        protected void setFechaNacim (GregorianCalendar fechaNacim){
            this.fechaNacim= fechaNacim;
        }       
                
        // Implementación de los métodos de la interfaz Imprimible
        // -------------------------------------------------------
        
        // Método devolverContenidoHashtable 
        public Hashtable devolverContenidoHashtable () {
            // Creamos la Hashtable que va a ser devuelta
            Hashtable contenido= new Hashtable ();
            
            // Añadimos los atributos específicos
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            String stringFecha= formatoFecha.format(this.fechaNacim.getTime());
            contenido.put ("nombre", this.nombre);
            contenido.put ("apellidos", this.apellidos);
            contenido.put ("fechaNacim", stringFecha);

            // Devolvemos la Hashtable
            return contenido;
        }

        // Método devolverContenidoArrayList 
        public ArrayList devolverContenidoArrayList () {
            ArrayList contenido= new ArrayList ();
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            String stringFecha= formatoFecha.format(this.fechaNacim.getTime());
            
            contenido.add(this.nombre);
            contenido.add (this.apellidos);
            contenido.add(stringFecha);
            
            return contenido;
        }
 

        // Método devolverContenidoString 
        public String devolverContenidoString () {
            String contenido= Persona.HashtableToString(this.devolverContenidoHashtable());
            return contenido;
        }        
        
        // Métodos estáticos (herramientas)
        // --------------------------------
        
        // Método HashtableToString 
        protected static String HashtableToString (Hashtable tabla) {
            String contenido;
            String clave;
            Enumeration claves= tabla.keys();          
            
            contenido= "{";
            if (claves.hasMoreElements()) {
                clave= claves.nextElement().toString();
                contenido= contenido + clave + "=" + tabla.get(clave).toString();
            }
            while (claves.hasMoreElements()) {
                    clave= claves.nextElement().toString();
                    contenido += ",";
                    contenido= contenido.concat (clave) ;
                    contenido= contenido.concat ("=" + tabla.get(clave));
            }
            contenido= contenido + "}";
            
            return contenido;
        }        
        
}

