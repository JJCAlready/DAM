/*
 * JDTenista.java
 *
 * Fecha creación 06-mar-2012, 9:00:31
 *
 */

package tarea_7;

/**
 * Implementa un cuadro de dialogo para permitir agregar torneos en la aplicación
 * Es llamado por el formulario principal al seleccionar la opción de menú
 * Añadir -> Torneo ...
 *
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class JDTorneo extends javax.swing.JDialog {
    // variable para que el formulario principal pueda controlar si el usuario
    // pulsó el boton Aceptar  mediante la consulta del método haPulsadoAceptar()
    private boolean haPulsadoAceptar;

    // Constantes para utilizar en las categorías de torneo
    private static String TIPO_TORNEO_GS ="Gran Slam";
    private static String TIPO_TORNEO_T1000 ="ATP World Tour Masters 1000";
    private static String TIPO_TORNEO_T500 ="ATP World Tour 500";
    private static String TIPO_TORNEO_T250 ="ATP World Tour 250";

    // Array para pasar como parametro en la creación del modelo de datos del
    // combobox de categorias de torneo. 
    // Cada elemento tiene su correspondiente puntuación en el array
    // nArrayPuntuacionesCategoria
    //
    // En caso necesitar ampliar las categorías se añadirían los nuevos valores
    // a estos arrays
    //
    private String[] strArrayCategoriasTorneo = {
        TIPO_TORNEO_GS,
        TIPO_TORNEO_T1000,
        TIPO_TORNEO_T500,
        TIPO_TORNEO_T250
    };

    private int[] nArrayPuntuacionesCategoria = {
        2000,
        1000,
        500,
        250
    };


    /**
     * Permite al formulario padre consultar si el usuario pulsó el botón aceptar
     *
     * @return valor del atributo haPulsadoAceptar, debe ser true si se pulsado
     *         el botón aceptar en caso contrario debe ser false
     */
    public boolean haPulsadoAceptar() {
        return haPulsadoAceptar;
    }


    /**
     * Nos devuelve una instancia de la clase torneo con los valores
     * introducidos en el cuadro de texto y el JComboBox
     * @return instancia de la clase torneo con los valores
     *         introducidos en los cuadros de texto
     */
    public Torneo getTorneo() {
        int puntuacion = nArrayPuntuacionesCategoria[jComboBoxCategorias.getSelectedIndex()];
        Torneo torneo = new Torneo(jTextFieldNombre.getText(),puntuacion);
        return torneo;
    }

    /**
     *  Crea un nuevo formulario JDTorneo
     */
    public JDTorneo(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        UtilVentana.CentrarVentana(this);
    }

    /**
     * Este método es llamado desde el constructor para inicializar el formulario.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabelNombre = new javax.swing.JLabel();
        jLabelCategoria = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jButtonAceptar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jComboBoxCategorias = new javax.swing.JComboBox();

        setTitle("Añadir Torneo");
        setAlwaysOnTop(true);
        setBackground(java.awt.Color.white);
        setMinimumSize(new java.awt.Dimension(445, 270));
        setModal(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                CierraVentana(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("AÑADIR NUEVO TORNEO");

        jLabelNombre.setText("Nombre:");

        jLabelCategoria.setText("Categoria:");

        jButtonAceptar.setText("Aceptar");
        jButtonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAceptarActionPerformed(evt);
            }
        });

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jComboBoxCategorias.setModel(new javax.swing.DefaultComboBoxModel(strArrayCategoriasTorneo ));
        jComboBoxCategorias.setMinimumSize(new java.awt.Dimension(51, 18));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabelCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jComboBoxCategorias, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jButtonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(118, 118, 118)
                .addComponent(jButtonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabelTitulo)
                .addGap(6, 6, 6)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabelNombre))
                    .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabelCategoria))
                    .addComponent(jComboBoxCategorias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonAceptar)
                    .addComponent(jButtonCancelar)))
        );

        pack();
        
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Al pulsar el boton Cancelar ponemos el valor del atributo
     * haPulsadoAceptar a false y la visibilidad del dialogo a false
     * @param evt no se utiliza
     */
    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        haPulsadoAceptar = false;
        setVisible(false);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    /**
     * Al pulsar el boton Aceptar ponemos el valor del atributo
     * haPulsadoAceptar a true y la visibilidad del dialogo a false
     * @param evt no se utiliza
     */
    private void jButtonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAceptarActionPerformed
        haPulsadoAceptar = true;
        setVisible(false);
    }//GEN-LAST:event_jButtonAceptarActionPerformed

    /**
     * Método que se ejecuta al pulsar el usuario el botón de cierre de la
     * esquina superior derecha del cuadro de dialogo.
     * @param evt No se utiliza
     */
    private void CierraVentana(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_CierraVentana
        // TODO add your handling code here:
        haPulsadoAceptar = false;
        setVisible(false);
    }//GEN-LAST:event_CierraVentana


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAceptar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JComboBox jComboBoxCategorias;
    private javax.swing.JLabel jLabelCategoria;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables

}
