package tarea_7;


import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;



/**
 * Clase para centrar las ventanas de una aplicación en la pantalla.
 * Forma parte de la Tarea 7 del módulo de Programación del ciclo
 * Desarrollo de Aplicaciones Multiplataforma.
 *
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 *
 */
public class UtilVentana {
    /**
     * Función para centrar una ventana en la pantalla
     * @param ventana JFrame a centrar
     */
    public static void CentrarVentana(Window ventana) {

     // Se obtienen las dimensiones en pixels de la pantalla.
     Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
     // Se obtienen las dimensiones en pixels de la ventana.
     Dimension dimension = ventana.getSize();
     // Una cuenta para situar la ventana en el centro de la pantalla.
     ventana.setLocation((pantalla.width - dimension.width) / 2,
                                (pantalla.height - dimension.height) / 2);
    }
}
