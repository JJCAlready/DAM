
package tarea_7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Clase para guardar la información de un Tenista. <br>
 * Forma parte de la Tarea 7 del módulo de Programación del ciclo
 * Desarrollo de Aplicaciones Multiplataforma <br><br>
 *
 * Fecha de implementación: Marzo de 2012
 *
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class Tenista implements Serializable {
    private String nombre;
    private int edad;
    private ArrayList<Torneo> palmares;

    /**
     * Constructor de la clase. El palmarés estará vacío inicialmente.
     * @param nombre nombre del tenista a crear
     * @param edad edad del tenista a crear
     */
    public Tenista(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
        this.palmares = new ArrayList<Torneo>();
    }

    /**
     * Metodo de acceso al atributo edad.
     * @return Edad del tenista
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Metodo para modificar el atributo edad.
     * @param edad valor para asignar al atributo edad
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Metodo de acceso al atributo nombre.
     * @return nombre del tenista
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Metodo para modificar el atributo nombre.
     * @param nombre valor para asignar al atributo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     *  Devuelve un array con los nombres de los torneos ganados por el tenista
     * @return array de String con los nombres de los torneos ganados por el
     *         tenista
     */
    public String [] getPalmares() {
        int nTorneos = palmares.size();
        String [] arrayPalmares = new String[nTorneos];
        for(int i=0; i<nTorneos; i++)
            arrayPalmares[i] = this.palmares.get(i).getNombre();
        return arrayPalmares;
    } 

    /**
     * Permite consultar si el tenista tiene en su palmarés un torneo cuyo
     * nombre coincide con el valor pasado por parámetro.
     *
     * @param torneo String que representa el nombre del palmarés a comprobar.
     * @return true si el tenista tiene el torneo en su palmarés, false en
     *         caso contrario.
     */
    public boolean tieneTorneo(String torneo) {
        Torneo t = new Torneo(torneo, -1);
        return palmares.contains(t);
  
    }

    /**
     * Añade el torneo pasado por parámetro al palmarés del tenista.
     * @param torneo a añadir al palmarés del tenista.
     */
    public void añadirPalmares(Torneo torneo) {
        palmares.add(torneo);
    }

    /**
     * Devuelve la puntuación obtenida por el tenista según su palmarés.
     * @return int con la puntuación obtenida por el tenista según su palmarés
     */
    public int getPuntuacionATP(){
        int nTorneos = palmares.size();
        int puntuacion = 0;
        // sumamos todas las puntuaciones del palmarés del tenista
        for(int i=0; i<nTorneos; i++)
            puntuacion += palmares.get(i).getPuntuacion();
        return puntuacion;
    }


    /**
     * Se le pasa por parámetro un fichero que contiene los datos de los
     * tenistas y devuelve los mismos en un ArrayList de tenistas.
     * Si se produce algún error, el método devuelve null
     * @param fichero
     * @return ArrayList de tenistas contenidos en el fichero. En caso de error
     *          devuelve null.
     */
    public static ArrayList<Tenista> cargar(File fichero) {

        ObjectInputStream ois = null;
        ArrayList<Tenista> arrayLista = null;
        try {
            // Abrimos el fichero para leerlo
            ois = new ObjectInputStream(new FileInputStream(fichero));
            // Leemos el objeto desde el fichero
            arrayLista = (ArrayList<Tenista>)ois.readObject();
            ois.close();
        } catch (Exception ex) {
            arrayLista = null;
        } finally {
            // devolvemos el ArrayList;
            return arrayLista;
        }
    }

    /**
     * Se le pasa por parámetro el ArrayList con la lista de tenistas a guardar
     * y el fichero donde se almacenarán los datos. Devuelve true si los datos
     * se guardan correctamente y false en caso contrario.
     * @param lista lista de tenistas a guardar
     * @param fichero fichero donde se almacenarán los datos
     * @return true si los datos se guardan correctamente y false en caso
     *         contrario
     */
    public static boolean guardar(ArrayList<Tenista> lista, File fichero){
        boolean exito= false;
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero));
            // escribimos la lista pasada por parámetro
            oos.writeObject(lista);
            // Cerramos el fichero
            oos.close();
            exito = true;

        } catch (Exception ex) {
            exito = false;
        } finally {
            return exito;
        }

    }

    /**
     * Sobrescribe el método equals heredado de la clase objeto para adaptarla
     * de modo que para que dos tenistas sean iguales basta con que sean el mismo
     * objeto o bien coincidan sus nombres.
     * @param o objeto a comparar con este
     * @return true si el objeto o es igual a este
     */
    @Override
     public boolean equals(Object o) {
      if (o == null)
       return false;
      if (o == this)
       return true;
      if (!(o instanceof Tenista))
       return false;
      Tenista t = (Tenista) o;
      if (nombre == null || !nombre.trim().equalsIgnoreCase(t.getNombre().trim()))
       return false;
     return true;
     }
}
