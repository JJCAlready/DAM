package tarea_7;

/**
 * Clase Main que lanza el formulario principal de la aplicación GesTenis
 *
 * @author Fernando Arnedo Ayensa
 */
public class Main {

    /**
     * @param argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        
        new PrincipalJFrame().setVisible(true);
        
    }

}
