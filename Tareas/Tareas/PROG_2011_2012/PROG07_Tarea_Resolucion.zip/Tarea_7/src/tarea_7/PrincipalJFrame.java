/*
 * PrincipalJFrame.java
 *
 * Fecha de creación: Marzo-2012
 */

package tarea_7;

import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.swing.AbstractListModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.ListModel;

/**
 * Formulario principal de la aplicación GesTenis <br>
 * Forma parte de la Tarea 7 del módulo de Programación del ciclo
 * Desarrollo de Aplicaciones Multiplataforma. 
 *
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class PrincipalJFrame extends javax.swing.JFrame {
    /*
     * Constantes para los textos a presentar en los dialogos
     */
    private static final String TORNEOS_CARGADO = "La lista de torneos se cargó correctamente";
    private static final String TORNEOS_NO_CARGADO = "La lista de torneos no pudo cargarse correctamente";
    private static final String TORNEOS_GUARDADO = "La lista de torneos se guardó correctamente";
    private static final String TORNEOS_NO_GUARDADO = "La lista de torneos no pudo guardarse correctamente";
    private static final String TORNEO_NO_SELECCIONADO = "No se ha seleccionado un torneo";
    private static final String TORNEO_YA_EN_PALMARES = "El tenista ya tiene ese torneo en su palmarés";
    private static final String TORNEO_YA_EXISTE = "Ya hay un torneo en la lista con ese nombre";
    private static final String CARGA_TORNEOS = "Cargar torneos";
    private static final String CARGA_TENISTAS = "Cargar tenistas";
    private static final String GUARDAR_TORNEOS = "Guardar torneos";
    private static final String GUARDAR_TENISTAS = "Guardar tenistas";
    private static final String NINGUN_FICHERO_SELECCIONADO = "No se seleccionó ningún fichero";
    private static final String TENISTAS_GUARDADO = "La lista de tenistas se guardó correctamente";
    private static final String TENISTAS_NO_GARGADO = "La lista de tenistas no pudo cargarse correctamente";
    private static final String TENISTAS_NO_GUARDADO = "La lista de tenistas no pudo guardarse correctamente";
    private static final String AGREGAR_AL_PALMARES = "Añadir torneo al palmarés";
    private static final String EDAD_NO_VALIDA = "El valor introducido en el campo edad no es válido";
    private static final String LISTA_TENISTAS_VACIA = "La lista de tenistas está vacia";
    private static final String NOMBRE_NO_VALIDO = "El valor introducido en el campo nombre no es válido";
    private static final String TENISTA_NO_EN_LISTA = "No se encontró el tenista en la lista";
    private static final String TENISTA_NO_SELECCIONADO = "No se ha seleccionado un tenista";
    private static final String TENISTA_YA_EXISTE = "Ya hay un tenista en la lista con ese nombre";
    /*
     * Variables para la creación y seguimiento de los cuadros de dialogo
     */
    private JDTenista jdtenista;
    private JDTorneo jdtorneo;
    
    /*
     * Variables para los modelos de datos
     */
    private ArrayList<Tenista> listaTenistas = new ArrayList<Tenista>();
    private ArrayList<Torneo> listaTorneos = new  ArrayList<Torneo>();
    
    /*
     * Variables para el control del formulario principal
     */
    
    // Indice del tenista actual
    private int indice; 
    // Modelo de datos para jComboBoxCategorias
    private DefaultComboBoxModel comboBoxModel;
    // Modelo de datos para jListTorneos
    private ListModel listModel; //

    // Clase interna para tomar el modelo de datos del jListTorneos
    // del ArrayList listaTorneos
    private class ListModelTorneos extends AbstractListModel {
                
        @Override
        public int getSize() {
            return listaTorneos.size();
        }
        @Override
        public Object getElementAt(int index) {
          return  listaTorneos.get(index).getNombre();
        }

    }

    /**
     * Códogp a ejecutar cuando se crea un nuevo formulario PrincipalJFrame
     */
    public PrincipalJFrame() {
        ImageIcon iconoAp = new ImageIcon(this.getClass().getResource("/recursos/iconoapp.png"));
        setIconImage(iconoAp.getImage());
        initComponents();
        UtilVentana.CentrarVentana(this);
        inicializar(null);
    }

    /**
     * Este método es llamado desde el constructor para inicializar los
     * componentes del formulario.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelBuscar = new javax.swing.JPanel();
        jLabelNombreTenista = new javax.swing.JLabel();
        jTextFieldTenista = new javax.swing.JTextField();
        jPanelDatosTenista = new javax.swing.JPanel();
        jLabelDatosNombre = new javax.swing.JLabel();
        jLabelDatosEdad = new javax.swing.JLabel();
        jLabelDatosPuntuacion = new javax.swing.JLabel();
        jLabelDatosPalmares = new javax.swing.JLabel();
        jTextFieldDatosNombre = new javax.swing.JTextField();
        jTextFieldDatosEdad = new javax.swing.JTextField();
        jTextFieldDatosPuntuacion = new javax.swing.JTextField();
        jComboBoxPalmares = new javax.swing.JComboBox();
        jPanelAgregarPalmares = new javax.swing.JPanel();
        jLabelTorneos = new javax.swing.JLabel();
        jButtonAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListTorneos = new javax.swing.JList();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuArchivo = new javax.swing.JMenu();
        jMenuItemInicializar = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItemCargaTenistas = new javax.swing.JMenuItem();
        jMenuItemGuardarTenistas = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenuItemCargarTorneos = new javax.swing.JMenuItem();
        jMenuItemGuardarTorneos = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();
        jMenuAñadir = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("GesTenis");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFont(new java.awt.Font("Tahoma", 0, 11)); // NOI18N
        setForeground(java.awt.Color.white);
        setMinimumSize(new java.awt.Dimension(356, 477));
        setName("jFramePrincipal"); // NOI18N
        setResizable(false);

        jPanelBuscar.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanelBuscar.setToolTipText("Introduzca el nombre del tenista a buscar en el cuadro de texto");

        jLabelNombreTenista.setText("Nombre del tenista");

        jTextFieldTenista.setToolTipText("Introduzca el nombre del tenista a buscar y pulse Enter ");
        jTextFieldTenista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldTenistaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelBuscarLayout = new javax.swing.GroupLayout(jPanelBuscar);
        jPanelBuscar.setLayout(jPanelBuscarLayout);
        jPanelBuscarLayout.setHorizontalGroup(
            jPanelBuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelBuscarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelNombreTenista)
                .addGap(32, 32, 32)
                .addComponent(jTextFieldTenista, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanelBuscarLayout.setVerticalGroup(
            jPanelBuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelBuscarLayout.createSequentialGroup()
                .addGroup(jPanelBuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombreTenista)
                    .addComponent(jTextFieldTenista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanelDatosTenista.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos Tenista", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanelDatosTenista.setToolTipText("Datos del tenista actualmente seleccionado");

        jLabelDatosNombre.setText("Nombre:");

        jLabelDatosEdad.setText("Edad:");

        jLabelDatosPuntuacion.setText("Puntuación ATP:");

        jLabelDatosPalmares.setText("Palmarés:");

        jTextFieldDatosNombre.setEditable(false);

        jTextFieldDatosEdad.setEditable(false);

        jTextFieldDatosPuntuacion.setEditable(false);
        jTextFieldDatosPuntuacion.setToolTipText("Suma de las puntuaciones obtenidas por el tenista según su palmarés");

        jComboBoxPalmares.setModel(new javax.swing.DefaultComboBoxModel());
        jComboBoxPalmares.setToolTipText("Lista de tornes ganados por el tenista");

        javax.swing.GroupLayout jPanelDatosTenistaLayout = new javax.swing.GroupLayout(jPanelDatosTenista);
        jPanelDatosTenista.setLayout(jPanelDatosTenistaLayout);
        jPanelDatosTenistaLayout.setHorizontalGroup(
            jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDatosTenistaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelDatosNombre)
                    .addComponent(jLabelDatosEdad)
                    .addComponent(jLabelDatosPuntuacion)
                    .addComponent(jLabelDatosPalmares))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jComboBoxPalmares, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextFieldDatosPuntuacion, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldDatosEdad, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextFieldDatosNombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanelDatosTenistaLayout.setVerticalGroup(
            jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDatosTenistaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextFieldDatosNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDatosNombre))
                .addGap(11, 11, 11)
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDatosEdad)
                    .addComponent(jTextFieldDatosEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDatosPuntuacion)
                    .addComponent(jTextFieldDatosPuntuacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanelDatosTenistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDatosPalmares)
                    .addComponent(jComboBoxPalmares, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanelAgregarPalmares.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Añadir Palmarés", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 0))); // NOI18N
        jPanelAgregarPalmares.setToolTipText("Seleccione un palmarés de la lista y pulse Añadir para añadir un palmarés al tenista");

        jLabelTorneos.setText("Torneos");

        jButtonAgregar.setText("Añadir");
        jButtonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarActionPerformed(evt);
            }
        });

        jListTorneos.setModel(new ListModelTorneos());
        jScrollPane1.setViewportView(jListTorneos);

        javax.swing.GroupLayout jPanelAgregarPalmaresLayout = new javax.swing.GroupLayout(jPanelAgregarPalmares);
        jPanelAgregarPalmares.setLayout(jPanelAgregarPalmaresLayout);
        jPanelAgregarPalmaresLayout.setHorizontalGroup(
            jPanelAgregarPalmaresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelAgregarPalmaresLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelTorneos)
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 146, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jButtonAgregar)
                .addContainerGap())
        );
        jPanelAgregarPalmaresLayout.setVerticalGroup(
            jPanelAgregarPalmaresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelAgregarPalmaresLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabelTorneos)
                .addContainerGap(65, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAgregarPalmaresLayout.createSequentialGroup()
                .addContainerGap(60, Short.MAX_VALUE)
                .addComponent(jButtonAgregar)
                .addGap(60, 60, 60))
            .addGroup(jPanelAgregarPalmaresLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jMenuArchivo.setText("Archivo");
        jMenuArchivo.setToolTipText("Acceso a las funciones de carga y salvado de datos");

        jMenuItemInicializar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemInicializar.setText("Inicializar");
        jMenuItemInicializar.setToolTipText("Inicializa todos los datos del programa");
        jMenuItemInicializar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicializar(evt);
            }
        });
        jMenuArchivo.add(jMenuItemInicializar);
        jMenuArchivo.add(jSeparator1);

        jMenuItemCargaTenistas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemCargaTenistas.setText("Cargar Tenistas ...");
        jMenuItemCargaTenistas.setToolTipText("Carga la lista de tenistas desde un archivo existente en disco");
        jMenuItemCargaTenistas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarTenistas(evt);
            }
        });
        jMenuArchivo.add(jMenuItemCargaTenistas);

        jMenuItemGuardarTenistas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemGuardarTenistas.setText("Guardar Tenistas");
        jMenuItemGuardarTenistas.setToolTipText("Guarda los tenistas en un archivo en disco");
        jMenuItemGuardarTenistas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarTenistas(evt);
            }
        });
        jMenuArchivo.add(jMenuItemGuardarTenistas);
        jMenuArchivo.add(jSeparator2);

        jMenuItemCargarTorneos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemCargarTorneos.setText("Cargar Torneos ...");
        jMenuItemCargarTorneos.setToolTipText("Carga los torneos desde un archivo existente en disco");
        jMenuItemCargarTorneos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarTorneos(evt);
            }
        });
        jMenuArchivo.add(jMenuItemCargarTorneos);

        jMenuItemGuardarTorneos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemGuardarTorneos.setText("Guardar Torneos");
        jMenuItemGuardarTorneos.setToolTipText("Guarda los torneos en un fichero");
        jMenuItemGuardarTorneos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarTorneos(evt);
            }
        });
        jMenuArchivo.add(jMenuItemGuardarTorneos);

        jMenuItemSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemSalir.setText("Salir");
        jMenuItemSalir.setToolTipText("Termina la ejecución de la aplicación");
        jMenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir(evt);
            }
        });
        jMenuArchivo.add(jMenuItemSalir);

        jMenuBar1.add(jMenuArchivo);

        jMenuAñadir.setText("Añadir");
        jMenuAñadir.setToolTipText("Acceso a formularios para añadir tenistas y torneos");

        jMenuItem7.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem7.setText("Tenista ..");
        jMenuItem7.setToolTipText("Añade un nuevo tenista a la base de datos");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarTenista(evt);
            }
        });
        jMenuAñadir.add(jMenuItem7);

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem8.setText("Torneo ...");
        jMenuItem8.setToolTipText("Añade un nuevo torneo a la base de datos");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarTorneo(evt);
            }
        });
        jMenuAñadir.add(jMenuItem8);

        jMenuBar1.add(jMenuAñadir);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanelAgregarPalmares, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelDatosTenista, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelBuscar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanelBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanelDatosTenista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanelAgregarPalmares, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Muestra los datos del tenista en la posición indice de la lista
     *
     * @param indice posicion del tenista en el ArrayList de la lista de tenistas
     */
    private void mostrarDatosTenista(int indice) {
        Tenista tenista = listaTenistas.get(indice);
        jTextFieldDatosNombre.setText(tenista.getNombre());
        jTextFieldDatosEdad.setText(String.valueOf(tenista.getEdad()));
        jTextFieldDatosPuntuacion.setText(String.valueOf(tenista.getPuntuacionATP()));
        // Establece el modelo del JComboBox pasándole al constructor de
        // DefaultComboBoxModel un array con los nombres de los torneos
        // ganados por el tenista (su palmarés)
        comboBoxModel = new DefaultComboBoxModel(tenista.getPalmares());
        jComboBoxPalmares.setModel(comboBoxModel);
    }

    /**
     * Metodo a ejecutar cuando se pulse el boton de cierre de la ventana
     *
     * @param evt No se utiliza.
     */
    private void Salir(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir
        // Salimos de la aplicación
        this.dispose();
    }//GEN-LAST:event_Salir

    /**
     * Inicializa la lista de tenistas y torneos, el índice y los
     * componentes de la interfaz gráfica para que no muestren ningún dato.
     *
     * @param evt No se utiliza.
     */
    private void inicializar(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicializar
        indice = -1;
        listaTenistas = new ArrayList<Tenista>();
        listaTorneos = new ArrayList<Torneo>();
        jTextFieldTenista.setText(null);
        comboBoxModel = new DefaultComboBoxModel();
        jComboBoxPalmares.setModel(comboBoxModel);
        listModel = new ListModelTorneos();
        jListTorneos.setModel(listModel); 
        jTextFieldDatosNombre.setText(null);
        jTextFieldDatosEdad.setText(null);
        jTextFieldDatosPuntuacion.setText(null);
    }//GEN-LAST:event_inicializar

    /**
     * Muestra un JFileChooser para seleccionar el archivo a cargar.
     * Se muestra un mensaje con JOptionPane tanto si el archivo se carga con
     * éxito como si ocurre algún error.
     *
     * @param evt No se utiliza.
     */
    private void cargarTenistas(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarTenistas
        JFileChooser jfilechoser = new JFileChooser();
        jfilechoser.setDialogTitle(CARGA_TENISTAS);
        int resultado = jfilechoser.showOpenDialog(this);
        // Si se seleccionó un fichero
        if (resultado == JFileChooser.APPROVE_OPTION) {
           // intentamos cargar el fichero
           listaTenistas = Tenista.cargar(jfilechoser.getSelectedFile());
           // Si la carga tuvo exito mostramos el mensaje de carga correcta
           if (listaTenistas != null) {
               JOptionPane.showMessageDialog(this, TENISTAS_NO_GARGADO, CARGA_TENISTAS, JOptionPane.INFORMATION_MESSAGE);
           // Si la carga no tuvo éxito mostramos el mensaje de error
           } else {
               JOptionPane.showMessageDialog(this, TENISTAS_NO_GARGADO, CARGA_TENISTAS, JOptionPane.ERROR_MESSAGE);
           }
        // En caso de producirse en error en el cuadro de selección de fichero
        // Mostramos el mensaje de error
        } else if (resultado == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(this, TENISTAS_NO_GARGADO, CARGA_TENISTAS, JOptionPane.ERROR_MESSAGE);
        // Y en el caso de no haber seleccionado ningún archivo
        // mostramos el correspondiente mensaje
        } else if (resultado == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(this, NINGUN_FICHERO_SELECCIONADO, CARGA_TENISTAS, JOptionPane.INFORMATION_MESSAGE);
        }
        
    }//GEN-LAST:event_cargarTenistas

    /**
     * Muestra unJFileChooser para seleccionar el archivo donde guardar los
     * datos. Se muestra un mensaje con JOptionPane tanto si el archivo se
     * guarda con éxito como si ocurre algún error.
     *
     * @param evt No se utiliza.
     */
    private void guardarTenistas(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarTenistas
        JFileChooser jfilechoser = new JFileChooser();
        jfilechoser.setDialogTitle(GUARDAR_TENISTAS);
        int resultado = jfilechoser.showSaveDialog(this);
        // Si se seleccionó un fichero
        if (resultado == JFileChooser.APPROVE_OPTION) {
           // intentamos guardar el fichero
           boolean exitoGuarda = Tenista.guardar(listaTenistas, jfilechoser.getSelectedFile());
           // Si la operación tuvo exito mostramos el mensaje de guardado correcto
           if (exitoGuarda) {
               JOptionPane.showMessageDialog(this, TENISTAS_GUARDADO, GUARDAR_TENISTAS, JOptionPane.INFORMATION_MESSAGE);
           // Si la operación no tuvo éxito mostramos el mensaje de error
           } else {
               JOptionPane.showMessageDialog(this, TENISTAS_NO_GUARDADO, GUARDAR_TENISTAS, JOptionPane.ERROR_MESSAGE);
           }
        // En caso de producirse un error en el cuadro de selección de fichero
        // Mostramos el mensaje de error
        } else if (resultado == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(this, TENISTAS_NO_GUARDADO, GUARDAR_TENISTAS, JOptionPane.ERROR_MESSAGE);
        // Y en el caso de no haber seleccionado ningún archivo
        // mostramos el correspondiente mensaje
        } else if (resultado == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(this, NINGUN_FICHERO_SELECCIONADO, GUARDAR_TENISTAS, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_guardarTenistas

    /**
     * Muestra unJFileChooser para seleccionar el archivo a cargar.
     * Se muestra un mensaje con JOptionPane tanto si el archivo se carga
     * con éxito como si ocurre algún error.
     * Muestra un JFileChooser para seleccionar el archivo a cargar.
     * Se muestra un mensaje con JOptionPane tanto si el archivo se carga con
     * éxito como si ocurre algún error.
     *
     * @param evt No se utiliza.
     */
    private void cargarTorneos(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarTorneos
        JFileChooser jfilechoser = new JFileChooser();
        jfilechoser.setDialogTitle(CARGA_TORNEOS);
        int resultado = jfilechoser.showOpenDialog(this);
        // Si se seleccionó un fichero
        if (resultado == JFileChooser.APPROVE_OPTION) {
           // intentamos cargar el fichero
           listaTorneos = Torneo.cargar(jfilechoser.getSelectedFile());
           // Si la carga tuvo exito mostramos el mensaje de carga correcta
           // y actualizamos lista de torneos
           if (listaTorneos != null) {
               listModel = new ListModelTorneos();
               jListTorneos.setModel(listModel);
               JOptionPane.showMessageDialog(this, TORNEOS_CARGADO, CARGA_TORNEOS, JOptionPane.INFORMATION_MESSAGE);
           // Si la carga no tuvo éxito mostramos el mensaje de error
           } else {
               JOptionPane.showMessageDialog(this, TORNEOS_NO_CARGADO, CARGA_TORNEOS, JOptionPane.ERROR_MESSAGE);
           }
        // En caso de producirse en error en el cuadro de selección de fichero
        // Mostramos el mensaje de error
        } else if (resultado == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(this, TORNEOS_NO_CARGADO, CARGA_TORNEOS, JOptionPane.ERROR_MESSAGE);
        // Y en el caso de no haber seleccionado ningún archivo
        // mostramos el correspondiente mensaje
        } else if (resultado == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(this, NINGUN_FICHERO_SELECCIONADO, CARGA_TORNEOS, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_cargarTorneos

    /**
     * Muestra unJFileChooser para seleccionar el archivo donde se guardarán
     * los datos. Se muestra un mensaje con JOptionPane tanto si el archivo
     * se guarda con éxito como si ocurre algún error.
     *
     * @param evt No se utiliza
     */
    private void guardarTorneos(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarTorneos
        JFileChooser jfilechoser = new JFileChooser();
        jfilechoser.setDialogTitle(GUARDAR_TORNEOS);
        int resultado = jfilechoser.showSaveDialog(this);
        // Si se seleccionó un fichero
        if (resultado == JFileChooser.APPROVE_OPTION) {
           // intentamos guardar el fichero
           boolean exitoGuarda = Torneo.guardar(listaTorneos, jfilechoser.getSelectedFile());
           // Si la operación tuvo exito mostramos el mensaje de guardado correcto
           if (exitoGuarda) {
               JOptionPane.showMessageDialog(this, TORNEOS_GUARDADO, GUARDAR_TORNEOS, JOptionPane.INFORMATION_MESSAGE);
           // Si la operación no tuvo éxito mostramos el mensaje de error
           } else {
               JOptionPane.showMessageDialog(this, TORNEOS_NO_GUARDADO, GUARDAR_TORNEOS, JOptionPane.ERROR_MESSAGE);
           }
        // En caso de producirse en error en el cuadro de selección de fichero
        // Mostramos el mensaje de error
        } else if (resultado == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(this, TORNEOS_NO_GUARDADO, GUARDAR_TORNEOS, JOptionPane.ERROR_MESSAGE);
        // Y en el caso de no haber seleccionado ningún archivo
        // mostramos el correspondiente mensaje
        } else if (resultado == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(this, NINGUN_FICHERO_SELECCIONADO, GUARDAR_TORNEOS, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_guardarTorneos

    /**
     * Crea y hace visible la ventanaJDTenista con la opción modal a true.
     * Se comprueba si el usuario pulsa el botón aceptar y se añade el nuevo
     * tenista a la lista de tenistas.
     *
     * @param evt No se utiliza
     */
    private void agregarTenista(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarTenista
        

        // Creamos el dialogo y lo hacemos visible
        jdtenista = new JDTenista(this, true);
        
        boolean bSalir = false;
        while (!bSalir) {
            jdtenista.setVisible(true);
            // Comprobamos si el usuario pulsa el botón aceptar
            if (jdtenista.haPulsadoAceptar()) {
                    // Comprobamos los datos de los cuadros de texto
                    // Solo se permiten nombres formados por al menos 2 palabras
                    // de un máximo de 30 caracteres cada una
                    // La primera palabra no puede ser menor de 2 letras
                    // y el resto de palabras pueden ser de 1 letra.
                    // Un nombre solo puede contener caracteres alfabéticos
                    boolean bNombreValido = Pattern.matches("[a-zA-ZáéíóúüAÉÍÓÚÜÑñ ]{2,30}( ([a-zA-ZáéíóúüAÉÍÓÚÜÑñ ]{1,30}))+",
                            jdtenista.getTenista().getNombre().toUpperCase());
                    // Solo se admiten edades positivas, aunque podría
                    // restringirse a otras edades mínimas
                    boolean bEdadValida = (jdtenista.getTenista().getEdad()>0);
                    // En caso de existir algún campo no válido componemos el texto a
                    // mostrar en función de los errores
                    // Para evitar errores en busquedas, solo se admiten separaciones
                    // de un espacio entre palabras y no se permiten espacios al
                    // principio ni final del nombre
                    String msg = bNombreValido?"":NOMBRE_NO_VALIDO;
                    msg += bEdadValida?"":"\n"+EDAD_NO_VALIDA;
                    // Si algún campo no es válido mostramos el error
                    if (!bNombreValido || !bEdadValida) {
                        JOptionPane.showMessageDialog(this, msg, this.getTitle(), JOptionPane.ERROR_MESSAGE);
                        bSalir = false;
                    // Si nombre y edad son correctos, añadimos el tenista
                    // a la lista de tenistas, en caso de no existir, y salimos
                    } else {
                        Tenista tenista = jdtenista.getTenista();
                        bSalir = true;
                        if (listaTenistas.contains(tenista))
                            JOptionPane.showMessageDialog(this, TENISTA_YA_EXISTE, this.getTitle(), JOptionPane.ERROR_MESSAGE);
                        else
                            listaTenistas.add(tenista);
                    }
                // Si el usuario no pulsó aceptar, nos toca salir
                } else {
                    bSalir = true;
                }
        }
    }//GEN-LAST:event_agregarTenista

    /**
     * Crea y hace visible la ventanaJDTorneo con la opción modal a true.
     * Se comprueba si el usuario pulsa el botón aceptar y se añade el
     * nuevo torneo a la lista de torneos. Se llama al método
     * updateUI del JList para que aparezca el nuevo torneo
     *
     * @param evt
     */
    private void agregarTorneo(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarTorneo
       // Creamos el dialogo y lo hacemos visible y modal
        jdtorneo = new JDTorneo(this, true);
        boolean bSalir = false;
        while (!bSalir) {
            jdtorneo.setVisible(true);
            // Si el usuario pulsa el botón aceptar
            if (jdtorneo.haPulsadoAceptar()) {
                // comprobamos los datos
                Torneo torneo = jdtorneo.getTorneo();
                // Los nombres de los torneos estarán formados por una o mas palabras
                // de un máximo de 30 caracteres por palabra.
                // Solo se permiten caracteres alfanuméricos
                boolean bNombreValido = Pattern.matches(
                        "([a-zA-ZáéíóúüAÉÍÓÚÜÑñ0-9 ]{1,30})+",
                        torneo.getNombre().trim().toUpperCase());
                if (!bNombreValido) {
                    JOptionPane.showMessageDialog(this, NOMBRE_NO_VALIDO, this.getTitle(), JOptionPane.ERROR_MESSAGE);
                    bSalir = false;
                // Si el valor introducido en el cuadro de texto del nombre
                // es un nombre de torneo válido
                } else {
                    bSalir = true;
                    // Añadimos el torneo a la lista de torneos, si no existia
                    // previamente un torneo con ese nombre en la lista de torneos
                    if (listaTorneos.contains(torneo))
                        JOptionPane.showMessageDialog(this, TORNEO_YA_EXISTE, this.getTitle(), JOptionPane.ERROR_MESSAGE);
                    else {
                        listaTorneos.add(torneo);
                        jListTorneos.updateUI();
                    }
                    
               }
            // si no ha pulsado aceptar, salimos
            } else {
                bSalir = true;
            }
        }
    }//GEN-LAST:event_agregarTorneo


    /**
     * Función que se ejecutará al realizar un cambio en el cuadro de busqueda
     * de tenistas y se pulse intro. <br>
     * Busca un tenista en la lista con el mismo nombre que el introducido
     * en el cuadro de texto. Si lo encuentra establece el valor del
     * atributo índice a la posición del tenista en la lista y llamará al
     * método mostrarDatosTenista para que se muestren los datos en la
     * aplicación. En caso de que la lista esté vacía o el tenista no se
     * haya encontrado se mostrará un mensaje de error con JOptionPane.
     *
     */
    private void jTextFieldTenistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTenistaActionPerformed
        boolean encontrado = false;
        int indiceLista = 0;
        int tamanyoLista = listaTenistas.size();
        // Si la lista contiene datos de tenistas
        if (tamanyoLista > 0) {
            // Busca un tenista en la lista con el mismo nombre que el introducido
            while (!encontrado && indiceLista<tamanyoLista) {
                // Si lo encuentra establece el valor del atributo índice a la
                // posición del tenista en la lista y llamará al método 
                // mostrarDatosTenista para que se muestren los datos en la aplicación
                if (listaTenistas.get(indiceLista).getNombre().equalsIgnoreCase(jTextFieldTenista.getText())){
                    encontrado = true;
                    indice = indiceLista;
                    mostrarDatosTenista(indice);
                } else {
                indiceLista ++;
                }
            }
         }
        // En caso de que la lista esté vacía o el tenista no se haya encontrado
        // se mostrará un mensaje de error con JOptionPane.
        if (tamanyoLista==0 || !encontrado) {
            String msg = tamanyoLista == 0?LISTA_TENISTAS_VACIA:TENISTA_NO_EN_LISTA;
            JOptionPane.showMessageDialog(this,
                    msg,
                    "Busqueda tenista",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jTextFieldTenistaActionPerformed

    /**
     * Añade el torneo seleccionado del JList al palmarés del tenista actual.
     * Si no hay tenista o torneo seleccionado se mostrará un mensaje de
     * error con JOptionPane.
     *
     * @param evt No se utiliza.
     */
    private void jButtonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarActionPerformed
        // Si no hay tenista o torneo seleccionado
        int nIndiceTorneo = jListTorneos.getSelectedIndex();
        if (indice<0 || nIndiceTorneo<0 ) {
            String msg;
            if (indice < 0)
                msg = TENISTA_NO_SELECCIONADO;
            else
                msg = TORNEO_NO_SELECCIONADO;
            JOptionPane.showMessageDialog(this, msg, AGREGAR_AL_PALMARES, JOptionPane.ERROR_MESSAGE);
        // Si hay un tenista y un torneo seleccionados
        } else {
           // recuperamos el nombre del torneo seleccionado en la lista de torneos
           String strTorneo = listaTorneos.get(nIndiceTorneo).getNombre();
           // recuperamos el tenista seleccionado actualmente
           Tenista tenista = listaTenistas.get(indice);
           // Si el tenista seleccionado no tiene en su palmarés el torneo
           // seleccionado lo agregamos a su palmarés y actualizamos la vista
           if (!tenista.tieneTorneo(strTorneo)) {
               tenista.añadirPalmares(listaTorneos.get(nIndiceTorneo));
               mostrarDatosTenista(indice);
            // Si el tenista ya tiene el torneo en su palmarés, mostramos aviso
            } else {
               JOptionPane.showMessageDialog(this, TORNEO_YA_EN_PALMARES, AGREGAR_AL_PALMARES, JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButtonAgregarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAgregar;
    private javax.swing.JComboBox jComboBoxPalmares;
    private javax.swing.JLabel jLabelDatosEdad;
    private javax.swing.JLabel jLabelDatosNombre;
    private javax.swing.JLabel jLabelDatosPalmares;
    private javax.swing.JLabel jLabelDatosPuntuacion;
    private javax.swing.JLabel jLabelNombreTenista;
    private javax.swing.JLabel jLabelTorneos;
    private javax.swing.JList jListTorneos;
    private javax.swing.JMenu jMenuArchivo;
    private javax.swing.JMenu jMenuAñadir;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItemCargaTenistas;
    private javax.swing.JMenuItem jMenuItemCargarTorneos;
    private javax.swing.JMenuItem jMenuItemGuardarTenistas;
    private javax.swing.JMenuItem jMenuItemGuardarTorneos;
    private javax.swing.JMenuItem jMenuItemInicializar;
    private javax.swing.JMenuItem jMenuItemSalir;
    private javax.swing.JPanel jPanelAgregarPalmares;
    private javax.swing.JPanel jPanelBuscar;
    private javax.swing.JPanel jPanelDatosTenista;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JTextField jTextFieldDatosEdad;
    private javax.swing.JTextField jTextFieldDatosNombre;
    private javax.swing.JTextField jTextFieldDatosPuntuacion;
    private javax.swing.JTextField jTextFieldTenista;
    // End of variables declaration//GEN-END:variables

}
