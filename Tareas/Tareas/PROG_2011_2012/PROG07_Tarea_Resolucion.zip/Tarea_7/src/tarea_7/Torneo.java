
package tarea_7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Clase para guardar la información de un Torneo de tenis. <br>
 * Forma parte de la Tarea 7 del módulo de Programación del ciclo
 * Desarrollo de Aplicaciones Multiplataforma <br><br>
 * 
 * Fecha de implementación: Marzo de 2012
 *
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class Torneo implements Serializable {
    private String nombre;
    private int puntuacion;

    /**
     * Constructor de la clase, inicializa los dos atributos privados.
     * @param nombre nombre del torneo a crear.
     * @param puntuacion puntuación con la que se crea el torneo
     */
    public Torneo(String nombre, int puntuacion) {
        this.nombre = nombre;
        this.puntuacion = puntuacion;
    }

    /**
     * Retorna el valor del atributo nombre del objeto Torneo
     * @return String con el valor del atributo nombre del torneo
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Estable el valor del atributo nombre
     * @param nombre valor que se asignará al atributo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Retorna el valor del atributo puntuación del objeto Torneo
     * @return String con el valor del atributo puntuación del torneo
     */
    public int getPuntuacion() {
        return puntuacion;
    }

    /**
     * Estable el valor del atributo puntuación
     * @param nombre valor que se asignará al atributo puntuación
     */
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    /**
     * Se le pasa por parámetro un fichero que contiene los datos de los torneos
     * y devuelve los mismos en un ArrayList de torneos. Si se produce algún
     * error, el método devuelve null
     *
     * @param fichero fichero que contiene los datos de los torneos
     * @return ArrayList de torneos con los torneos contenidos en el fichero
     *         Si se produce algún error, el método devuelve null
     */
    public static ArrayList<Torneo>cargar(File fichero) {
        ObjectInputStream ois = null;
        ArrayList<Torneo> arrayLista = null;
        try {
            // Abrimos el fichero para leerlo
            ois = new ObjectInputStream(new FileInputStream(fichero));
            // Leemos el objeto desde el fichero
            arrayLista = (ArrayList<Torneo>)ois.readObject();
            ois.close();
        } catch (Exception ex) {
            arrayLista = null;
        } finally {
            // devolvemos el ArrayList;
            return arrayLista;
        }
    }


    /**
     * Se le pasa por parámetro el ArrayList con la lista de torneos a guardar y
     * el fichero donde se almacenarán los datos. Devuelve true si los datos se
     * guardan correctamente y false en caso contrario.
     * @param lista lista de torneos a guardar
     * @param fichero fichero donde se almacenarán los datos
     * @return true si los datos se guardan correctamente y falso en caso
     *         contrario
     */
    public static boolean guardar(ArrayList<Torneo> lista, File fichero) {
        boolean exito= false;
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero));
            // escribimos la lista pasada por parámetro
            oos.writeObject(lista);
            // Cerramos el fichero
            oos.close();
            exito = true;

        } catch (Exception ex) {
            exito = false;
        } finally {
            return exito;
        }
    }


    /**
     * Sobrescribe el método equals heredado de la clase objeto para adaptarla
     * de modo que para que dos torneos sean iguales basta con que sean el mismo
     * objeto o bien coincidan sus nombres.
     * @param o objeto a comparar con este
     * @return true si el objeto o es igual a este
     */
    @Override
     public boolean equals(Object o) {
      if (o == null)
       return false;
      if (o == this)
       return true;
      if (!(o instanceof Torneo))
       return false;
      Torneo t = (Torneo) o;
      if (nombre == null || !nombre.trim().equalsIgnoreCase(t.getNombre().trim()))
       return false;
     return true;
     }
}
