/*
 * JDTenista.java
 *
 * Fecha de creación: 06-mar-2012, 9:00:31
 */

package tarea_7;

/**
 * Cuadro de dialogo que permite añadir un tenista en la aplicación GesTenis <br>
 * Forma parte de la Tarea 7 del módulo de Programación del ciclo
 * Desarrollo de Aplicaciones Multiplataforma.
 *
 * @author Fernando Arnedo Ayensa
 */
public class JDTenista extends javax.swing.JDialog {
    private boolean haPulsadoAceptar;

    /** 
     * Crea un nuevo formulario JDTenista
     */
    public JDTenista(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        UtilVentana.CentrarVentana(this);
    }

    /**
     * Método que permite al formulario principal consultar si el usuario ha
     * pulsado o no el boton aceptar para salir del díalogo.
     *
     * @return valor del atributo haPulsadoAceptar, debe ser true si se pulsado
     *         el botón aceptar en caso contrario debe ser false
     */
    public boolean haPulsadoAceptar() {
        return haPulsadoAceptar;
    }


    /**
     * Nos devuelve una instancia de la clase tenista con los valores
     * introducidos en los cuadros de texto.
     *
     * @return instancia de la clase tenista con los valores
     *         introducidos en los cuadros de texto
     */
    public Tenista getTenista() {
        String nombre = jTextFieldNombre.getText();
        int edad = -1;
        try {
           edad = Integer.parseInt(jTextFieldEdad.getText());
        // en caso de que el cuadro no contenga un entero, devolvemos -1
        // indicando que el cuadro de texto contiene una edad no válida
        } catch (NumberFormatException e){
          edad = -1 ;
        }
        Tenista tenista = new Tenista(nombre, edad);
        return tenista;
    } 

    /**
     * Este método se llama desde el constructor para inicializar el formulario
     * 
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelTitulo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabelNombre = new javax.swing.JLabel();
        jLabelEdad = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextFieldEdad = new javax.swing.JTextField();
        jButtonAceptar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();

        setTitle("Añadir Tenista");
        setAlwaysOnTop(true);
        setBackground(java.awt.Color.white);
        setMinimumSize(new java.awt.Dimension(445, 270));
        setModal(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                CierraVentana(evt);
            }
        });

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTitulo.setText("AÑADIR NUEVO TENISTA");

        jLabelNombre.setText("Nombre:");

        jLabelEdad.setText("Edad:");

        jButtonAceptar.setText("Aceptar");
        jButtonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAceptarActionPerformed(evt);
            }
        });

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabelEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jTextFieldEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jButtonAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(118, 118, 118)
                .addComponent(jButtonCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabelTitulo)
                .addGap(6, 6, 6)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabelNombre))
                    .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabelEdad))
                    .addComponent(jTextFieldEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonAceptar)
                    .addComponent(jButtonCancelar)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Al pulsar el boton Cancelar ponemos el valor del atributo
     * haPulsadoAceptar a false y la visibilidad del dialogo a false
     * @param evt no se utiliza
     */
    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        haPulsadoAceptar = false;
        setVisible(false);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    /**
     * Al pulsar el boton Aceptar ponemos el valor del atributo
     * haPulsadoAceptar a true y la visibilidad del dialogo a false
     * @param evt no se utiliza
     */
    private void jButtonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAceptarActionPerformed
        haPulsadoAceptar = true;
        setVisible(false);
    }//GEN-LAST:event_jButtonAceptarActionPerformed

    /**
     * Método que se ejecuta al pulsar el usuario el botón de cierre de la
     * esquina superior derecha del cuadro de dialogo.
     * @param evt No se utiliza
     */
    private void CierraVentana(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_CierraVentana
        haPulsadoAceptar = false;
        setVisible(false);
    }//GEN-LAST:event_CierraVentana


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAceptar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JLabel jLabelEdad;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTextFieldEdad;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables

}
