package numeros;

/**
 * Clase para la implementación del apartado 5 de la tarea
 * @author Fernando Arneedo Ayensa
 */
public class Complejo {
    double real;
    double imag;
    
    /**
     * Constructor que inicializa los atributos a cero.
     */
    public Complejo() {
      real = 0;
      imag = 0;
    }
    
    /**
     * 
     * Constructor que inicializa los atributos a los valores indicados 
     * por los parámetros.
     * 
     * @param real parte real del número complejo
     * @param imag parte imaginaria del número complejo
     * 
     */
    public Complejo(double real, double imag) {
        this.real = real;
        this.imag = imag;
    }
    
    /**
     * 
     * @return Devuelve la parte real del objeto.
     */
    public double consulta_Real() {
        return real;
    }
    
    /**
     * 
     * @return Devuelve la parte imaginaria del objeto.
     */
    public double consulta_Imag() {
        return imag;
    }
    
    /**
     * Asigna a la parte real del objeto el valor indicado en el parámetro real.
     * 
     * @param real valor con el modificar la parte real del número complejo
     */
    public void cambia_Real(double real) {
        this.real = real;
    }
    
    /**
     * Asigna a la parte imaginaria del objeto el valor indicado en el 
     * parámetro imag.
     * 
     * @param imag valor con el modificar la parte imaginaria del número complejo
     */
    public void cambia_Imag(double imag) {
        this.imag = imag;
    }
    
    /**
     * Convierte a String el número complejo, mediante la concatenación de sus
     * atributos y devuelve como resultado la cadena de texto que representa al
     * número complejo en forma binomial.
     * 
     * @return Cadena de texto que representa al número complejo en forma binomial 
     */
    @Override
    public String toString() {
        String signo;
        // Seleccionamos el caracter correspondiente a mostrar en función de si
        // la parte real es positiva o negativa
        signo = Math.abs(imag)==imag ? "+" : "-";
        // componemos y retornamos el string
        return real + " " + signo + " " + Math.abs(imag) + "*i";
    }
    
    
    /**
     * Suma la parte real con la parte real del número complejo b y la parte 
     * imaginaria con la parte imaginaria del número complejo b.
     * 
     * @param b : número complejo a sumar
     */
    public void sumar(Complejo b) {
        this.real += b.real;
        this.imag += b.imag;
    }
}
