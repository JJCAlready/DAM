package Ejercicio01;

/**
 * Clase Persona: Clase base para el desarrollo de la Tarea 3 de PROGRAMACIÓN
 * @author F.P.D. Junta de Andalucía (metodos de consulta y modificación del
 * @version 1.0
 */
public class Persona {
    String nombre;
    int edad;
    float altura;

    public String consulta_Nombre(){
        return nombre;
    }

    public void cambia_Nombre(String nom){
        nombre=nom;
    }
    
    // métodos de consulta y modificación del resto de atributos
    // apartado 2 de la tarea
    public int consulta_Edad(){
        return edad;
    }

    public void cambia_Edad(int ed){
        edad=ed;
    }
    
    public float consulta_Altura(){
        return altura;
    }

    public void cambia_Altura(float alt){
        altura=alt;
    }
    
    
    // Metodo constructor de la clase Persona
    // Implementado como requisito del apartado 3 de la tarea
    public Persona() {
        nombre="Luisa Perez";
        edad=22;
        altura=1.70f ;
    }

    
    /**
     * 
     * Metodo constructor con parámetros de la clase Persona
     * Implementado como requisito del apartado 4 de la tarea
     * 
     * @param nombre String que contiene el nombre para la persona
     * @param edad int con la edad de la persona
     * @param altura float con la altura de la persona
     * 
     */
    public Persona(String nombre, int edad, float altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
    }
    
}
