package Ejercicio01;

import java.util.Scanner;

/** 
 * Clase Ejercicio01: Clase para el desarrollo del apartado 1 de la tarea 3 de
 * programación. Contiene el método principal
 * 
 * @author Fernando
 * @version 1
 */
public class Ejercicio01 {

    /**
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // leeremos el nombre por teclado
        Scanner teclado = new Scanner( System.in );
        String nombre;
        // creamos una nueva instancia de persona
        Persona persona = new Persona();
        
        // Leemos el nombre para la persona     
        System.out.println( "Introducir nombre para la persona: " ); 
        nombre = teclado.nextLine();
        // Asignamos el nombre a la persona
        persona.cambia_Nombre(nombre);
        // ahora mostramos el nombre de la persona
        System.out.println( "El nombre de la persona es: " + persona.consulta_Nombre() ); 
    }
}

