
package Ejercicio05;

import java.util.Scanner;

// La clase Complejo se encuentra en el paquete numeros del proyecto 
import numeros.Complejo;

/**
 * Clase para la implementación del apartado 5 de la tarea
 * 
 * @author Fernando Arnedo Ayensa
 * @version  1.0
 */
public class Ejercicio05 {

    /**
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        
        // leeremos datos por teclado
        Scanner teclado = new Scanner( System.in );
        Complejo c1, c2;
        double r, i;
        
        // creamos un objeto de la clase Complejo con el constructor sin
        // parámetros.
        c1 = new Complejo();
        System.out.print("\nCreado complejo c1 con construtor sin parámetros");
        // y monstramos sus atributos
        System.out.print("\nMostrando complejo creado con construtor sin parámetros");
        System.out.print("\n\tParte real: " + c1.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c1.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c1.toString());
        
        // leemos los valores de parte real y parte imaginaria para asignar a c1
        System.out.print("\nIntroduzca el valor de la parte real para c1: ");
        r = teclado.nextDouble();
        
        System.out.print("Introduzca el valor de la parte imaginaria para c1: ");
        i = teclado.nextDouble();
             
        // modificamos c1 con los valores introducidos
        c1.cambia_Real(r);
        c1.cambia_Imag(i);
        // y mostramos los nuevos valores
        System.out.print("Mostrando los nuevos valores de c1");
        System.out.print("\n\tParte real: " + c1.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c1.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c1.toString());
        
        // leemos los valores de parte real y parte imaginaria para asignar a c2
        System.out.print("\nIntroduzca el valor de la parte real para c2: ");
        r = teclado.nextDouble();
        
        System.out.print("Introduzca el valor de la parte imaginaria para c2: ");
        i = teclado.nextDouble();
        
        // creamos c2 con los valores introducidos
        c2 = new Complejo(r, i);
        System.out.print("Creado complejo c2 con construtor con los valores "
                           + "introducidos como parámetros");
        // y monstramos sus atributos
        System.out.print("\nMostrando complejo creado con construtor sin parámetros");
        System.out.print("\n\tParte real: %f" + c2.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c2.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c2.toString());
        
        // sumamos a c2 el complejo c1
        System.out.print("\nSumamos a c2 el complejo c1");
        c2.sumar(c1);
        // y monstramos sus atributos
        System.out.print("\nMostrando complejo c2 tras la suma");
        System.out.print("\n\tParte real: " + c2.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c2.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c2.toString());
        
    }
}
