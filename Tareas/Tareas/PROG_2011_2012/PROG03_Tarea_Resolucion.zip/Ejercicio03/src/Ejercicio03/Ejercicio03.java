package Ejercicio03;
import Ejercicio01.Persona; 
/**
 * Clase para la implementación del apartado 3 de la tarea
 * 
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class Ejercicio03 {

    /**
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // creamos una Persona
        Persona persona = new Persona();
        // y monstramos sus atributos
        System.out.printf("\nNombre: %s" , persona.consulta_Nombre());
        System.out.printf("\nEdad: %d" , persona.consulta_Edad());
        System.out.printf("\nAltura: %.2f\n" , persona.consulta_Altura());
        
    }
}
