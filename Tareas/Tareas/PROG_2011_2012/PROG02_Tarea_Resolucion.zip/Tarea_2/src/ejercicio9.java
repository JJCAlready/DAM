import java.util.Scanner;

/**
 * ejercicio9: desarrollo del punto 9 de la tarea 2
 * Programa Java que solicita un número de 5 dígitos del teclado, separa el
 * número en sus dígitos individuales y los muestra por pantalla.
 * NO SE REALIZA GESTIÓN DE ERRORES, SE SUPONEN TODAS LAS ENTRADAS VÁLIDAS
 * 
 * @version 1.0   26/10/2011
 * @author Fernando Arnedo Ayensa
 */
public class ejercicio9 {

    /**
     * metodo principal
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // leemos el número por teclado
        Scanner teclado = new Scanner( System.in );
        int x;
        // guardaremos cada dígito en un byte
        byte dm, um, c, d, u;
        System.out.print( "Introducir un número de cinco cifras: " );
        x = teclado.nextInt();
        
        dm = (byte)(x / 10000);  // calculamos las decenas de millar
        x = x -10000*dm;         // y nos quedamos solo con cuatro cifras
        
        um = (byte)(x / 1000);   // calculamos las unidades de millar
        x = x -1000*um;          // y nos quedamos solo con tres cifras
        
        c = (byte)(x / 100);     // calculamos las centenas
        x = x -100*c;            // y nos quedamos solo con dos cifras
        
        d = (byte)(x / 10);      // calculamos las centenas
        u = (byte)(x -10*d);     // y nos quedamos solo con 1 cifra
        // mostramos los digitos obtenidos
        System.out.printf("\n%d  %d  %d  %d  %d", dm, um, c, d, u);       
    }
}
