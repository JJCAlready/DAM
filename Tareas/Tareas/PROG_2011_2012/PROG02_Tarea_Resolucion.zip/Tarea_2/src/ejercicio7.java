
import java.util.Scanner;

/**
 * ejercicio7: desarrollo del punto 7 de la tarea 2
 * Programa Java que resuelve una ecuación de primer grado con una incógnita (x)
 * Los coeficientes de la ecuación (C1 y C2) se introducen desde teclado
 * NO SE REALIZA GESTIÓN DE ERRORES, SE SUPONEN TODAS LAS ENTRADAS VÁLIDAS
 * 
 * @version 1.0   26/10/2011
 * @author Fernando Arnedo Ayensa
 */
public class ejercicio7 {
     /*
     * metodo main
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // leemos coeficientes por teclado
        Scanner teclado = new Scanner( System.in );
        // Utilizaremos variables double para poder entrar números reales
        double c1, c2;
        System.out.print( "Introducir coeficiente c1: " ); 
        c1 = teclado.nextDouble();
        System.out.print( "Introducir coeficiente c2: " );
        c2 = teclado.nextDouble(); 
        // mostramos la solución
        System.out.println("X = " + (double)(-c2/c1) );
    }
}
