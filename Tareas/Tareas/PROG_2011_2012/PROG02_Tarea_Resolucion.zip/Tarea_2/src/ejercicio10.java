import java.util.Scanner;

/**
 * ejercicio10: desarrollo del punto 10 de la tarea 2
 * Programa Java que para leer las longitudes de los lados de un triangulo 
 * (L1, L2, L3) y calcular el área del mismo
 * NO SE REALIZA GESTIÓN DE ERRORES, SE SUPONEN TODAS LAS ENTRADAS VÁLIDAS
 * 
 * @version 1.0   26/10/2011
 * @author Fernando Arnedo Ayensa
 */
public class ejercicio10 {

    /**
     * metodo principal
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // leeremos los lados por teclado
        Scanner teclado = new Scanner( System.in );
        double l1, l2, l3, sp, superficie;
        
        System.out.print( "Introducir L1: " );
        l1 = teclado.nextDouble();
        System.out.print( "Introducir L2: " );
        l2 = teclado.nextDouble();
        System.out.print( "Introducir L3: " );
        l3 = teclado.nextDouble();
        
        // calculamos el semiperimetro y la superficie
        sp = (l1+l2+l3)/2;       
        superficie = Math.sqrt(sp*(sp-l1)*(sp-l2)*(sp-l3));
        
        // mostramos el resultado
        System.out.println("La superficie del triangulo vale: " + superficie);       
    }
}
