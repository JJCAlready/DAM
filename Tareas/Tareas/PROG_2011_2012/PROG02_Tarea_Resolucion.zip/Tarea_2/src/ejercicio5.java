/**
 * ejercicio5: clase para el desarrollo del apartado 5 de la tarea 4
 * programa Java que pide dos números por teclado, determina si el primero 
 * es múltiplo del segundo y muestre el resultado. 
 * NO SE REALIZA GESTIÓN DE ERRORES, SE SUPONEN TODAS LAS ENTRADAS VÁLIDAS
 * 
 * @author Fernando Arnedo Ayensa
 * @version 1.0     26/10/2011
 */

import java.util.Scanner;

public class ejercicio5 {

    /**
     * metodo principal
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner( System.in );
        int x, y;
        String mensaje;
        System.out.print( "Introducir primer número entero : " ); 
        x = teclado.nextInt();
        System.out.print( "Introducir segundo número entero: " );
        y = teclado.nextInt(); 
        // construimos mensaje de salida en función de si es multiplo o no
        mensaje = x%y == 0 ? " es múltiplo de " : " no es múltiplo de ";
        System.out.println(x+mensaje+y);
    }
}
