/**
 * ejercicio6: desarrollo del punto 6 de la tarea 2
 * programa Java que crea un tipo enumerado para los meses del año. 
 * El programa realiza las siguientes operaciones:
 *    - Crea una variable m del tipo enumerado y le asignarle el mes de marzo. 
 *    - Muestra por pantalla su valor.
 * 
 * @version 1.0   26/10/2011
 * @author Fernando Arnedo Ayensa
 */
public class ejercicio6 {
    // creamos el tipo enumerado
    enum mes { ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO, JULIO, AGOSTO, 
               SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE }
    
    /*
     * metodo main
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // creamos variable del tipo mes
        mes m = mes.MARZO;
        System.out.println("El valor de la variable m es " + m );
    }
}
