

package Utilidades;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Clase para crear y presentar un menú por consola
 * @author Fernando
 */
public class Menu {
    private static final String NO_VALIDO = "\tOpci\u00f3n no v\u00e1lida";
    private static final String SELECCIONAR = "\n\tSeleccione una opci\u00f3n: ";
    HashMap Entradas;
    ArrayList Claves;

    /**
     * Constructor de la clase
     */
    public Menu() {
        Entradas = new HashMap();
        Claves = new ArrayList();
    }

   /**
    * Agrega una nueva entrada para presentar en el menu 
    * @param Clave Caracter para seleccionar la opción de menu correspondiente a esta entrada
    * @param Valor Texto a presentar en la opcion de menu correspondiente a esta entrada
    */
   public void AgregarEntrada(char Clave, String Valor ) {
        Entradas.put(Clave, Valor);
        Claves.add(Clave);
    }

   /**
    * Muestra en la c�nsola el men�, solicitando la entrada de una opci�n v�lida
    * @return Caracter correspondiente a la opci�n seleccionada
    */
   public char Mostrar() {
        String opcionSeleccionada="";
        String strMenu = "";
        int i = 0;
        boolean bValido = false;
        // creamos el menu
       Iterator it = Claves.iterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (i==0)
                strMenu += "\n" + Entradas.get(obj) + "\n";
            else
                strMenu += "\n" +  obj + ". " + Entradas.get(obj);
            i++;
            }
        // imprimimos el menu
        System.out.println(strMenu);
        // solicitamos entrada hasta obtener un valor válido
        do {
            opcionSeleccionada = Entrada.leerString(SELECCIONAR, NO_VALIDO);
            if (!opcionSeleccionada.equals(""))
                bValido = Entradas.containsKey(opcionSeleccionada.charAt(0));
            if (!bValido)
               System.out.print(NO_VALIDO);
        } while (!bValido);
        // Una vez leida una opción válida la retornamos
        return opcionSeleccionada.charAt(0);
    }


}
