
package Utilidades;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Clase para facilitar la lectura de un tipos de datos, capturando las
 * excepciones en caso de leer un dato inexperado y reiterando la lectura del
 * dato solicitado hasta que se introducca un valor correcto del tipo solicitado.
 * No posee atributos, tan solo métodos, todos ellos static.
 *
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 */
public class Entrada {
    /**
     * Facilita la lectura de un tipo String que encaje con un patron
     * determinado por una expresi�n regurlar
     * @param textoMostrar texto previo que se mostrar� al solicitar el dato
     * @param textoError texto que se mostrar� si el valor leido es erroneo
     * @param strPatron Expresi�n regular, patron con el que ha de concordar el valor leido
     * @return String leido
     */
    public static String leerString(String textoMostrar, String textoError, String strPatron) {
       String valorLeido;
       boolean bValido = false;
       Scanner teclado = new Scanner( System.in );
       do {
           System.out.println(textoMostrar);
           valorLeido = teclado.nextLine();
           if (valorLeido.trim().matches(strPatron))
               bValido = true;
           else
               System.out.println(textoError); // mostramos el texto de error
       // repetimos hasta leer un string que concuerde con el patron
       } while (!bValido);
       
     // retornamos el string leido
     return valorLeido;
   }

   /**
     * Facilita la lectura de un tipo String.
     * @param textoMostrar texto previo que se mostrar� al solicitar el dato
     * @param textoError texto que se mostrar� si el valor leido es erroneo
     * @return String leido
     */
    public static String leerString(String textoMostrar, String textoError) {
       return leerString(textoMostrar, textoError, "(.)*");
   }




   /**
     * Facilita la lectura de un tipo Double.
     * @param textoMostrar texto previo que se mostrar� al solicitar el dato
     * @param textoError texto que se mostrar� si el valor leido es erroneo
     * @return Double leido
     */
   public static Double leerDouble(String textoMostrar, String textoError) {
       double valorLeido =0;
       boolean valorValido = false;
       Scanner teclado = new Scanner( System.in );
       do {
           try { // Tratamos de leer un Double y lo guardamos
               System.out.println(textoMostrar);
               valorLeido = teclado.nextDouble();
               valorValido = true;
           }
           catch (InputMismatchException e){ // Si no se introduce un Double
              System.out.println(textoError);
              // consumir caracter "\n"
              teclado.nextLine();
              valorValido = false;
           }
         // repetimos hasta leer un Double
       } while (!valorValido);
     // retornamos el valor leido
       return valorLeido;
   }



   /**
     * Facilita la lectura de un tipo Int.
     * @param textoMostrar texto previo que se mostrar� al solicitar el dato
     * @param textoError texto que se mostrar� si el valor leido es erroneo
     * @return Double leido
     */
   public static int leerInt(String textoMostrar, String textoError) {
       int valorLeido =0;
       boolean valorValido = true;
       Scanner teclado = new Scanner( System.in );
       do {
           try { // Tratamos de leer un int y lo guardamos
               System.out.println(textoMostrar);
               valorLeido = teclado.nextInt();
               valorValido = true;
           }
           catch (InputMismatchException e){ // Si no se introduce un int
              System.out.println(textoError); // mostramos mensaje de error
              teclado.nextLine();
              valorValido = false;
           }
         // repetimos hasta leer un int
       } while (!valorValido);
     // retornamos el valor leido
       return valorLeido;
   }

    /**
     * Facilita la lectura de un tipo String que encaje con un patron de tipo fecha
     * (dd-MM-yyyy), adem�s la fecha ha de ser una fecha v�lida.
     * @param textoMostrar texto previo que se mostrar� al solicitar el dato
     * @param textoError texto que se mostrar� si el valor leido es erroneo
     * @return Fecha leida
     */
    public static Date leerDate(String textoMostrar, String textoError) {
       SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
       Date fecha = null;
       String valorLeido="";
       String strPatron = "[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}";
       boolean bValido = false;
       Scanner teclado = new Scanner( System.in );
       do {
           try { // Tratamos de leer un string y lo guardamos
               System.out.println(textoMostrar);
               valorLeido = teclado.nextLine();
           }
           catch (Exception e){ // Si no se produce un error
              System.out.println(textoError); // mostramos mensaje de error
              bValido = false;
           }
		   // Por si el usuario utiliz� los caracteres \ o / en lugar de -
           valorLeido = valorLeido.replace("\\", "-");
           valorLeido = valorLeido.replace("/", "-");
		   // Si el string encaja con el patr�n y adem�s es una fecha v�lida
           if (valorLeido.matches(strPatron) && FechaValida(valorLeido)) {
                try {
                    // convertimos el string a un valor Date
                    fecha = sdf.parse(valorLeido);
                    bValido = true;
                } catch (ParseException ex) {
                    System.out.println(textoError);
                    bValido = false;
                }
           }
           else
               System.out.println(textoError); // mostramos el texto de error
        // repetimos hasta leer un string que concuerde con el patron
       } while (!bValido);
     // retornamos la fecha leida
     return fecha;
   }

    /*
     *
     */
    private static boolean FechaValida(String strFecha){
        boolean bValido = true;
        boolean bBisiesto;
        String []Subcadena = strFecha.split("-");
        int anyo = Integer.parseInt(Subcadena[2]);
        int mes = Integer.parseInt(Subcadena[1]);
        int dia = Integer.parseInt(Subcadena[0]);
        // comprobamos el mes
        if (mes>12)
            bValido = false;
        // comprobamos el d�a
        if (dia>31)
            bValido = false;
        // comprobamos el dia en funci�n del mes
        if ((mes==4 || mes==6 || mes==9 || mes==11) && dia>30)
            bValido = false;
        // en caso de que el mes sea febrero
        if (mes==2) {
            // Si es a�o bisiesto
            if ((anyo % 4 == 0) && ((anyo % 100 != 0) || (anyo % 400 == 0))) {
			    // no puede tener mas de 29 dias
                if (dia > 29)
                   bValido = false;
            } // si no es a�o bisiesto, no puede tener mas de 28 d�as
            else if (dia > 28)
                bValido = false;

        }
       return bValido;
    }

}
