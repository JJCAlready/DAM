
package Utilidades;

/**
 * Interfaz para las clases que deban presentar informaci�n en pantalla
 * @author Fernando Arnedo Ayensa
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 */
public interface Imprimible {
    /**
     * Imprime por la salida estandar un String con los datos de la clase
     */
    public abstract void Imprimir();
}
