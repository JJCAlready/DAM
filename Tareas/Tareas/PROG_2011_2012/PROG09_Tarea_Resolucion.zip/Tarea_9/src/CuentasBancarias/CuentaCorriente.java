
package CuentasBancarias;

import Usuarios.Persona;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una cuenta de ahorro. <br>
 * Deriva de la clase CuentaBancaria, por lo que hereda todos los m�todos de
 * esta clase.<br>
 * Se trata de una clase abstracta por lo que no pueden instanciarse objetos de
 * esta clase.<br>

 * Se define el atributo:<br><ul>
 *   <li><b>EntidadesAsociadas</b>, variable de tipo Hashtable en la que se
 *          almacenar�n la Entidades,conjunto de pares de valores (entidad, valor m�ximo de cargo)</li>
 *  </ul>
 *
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @see CuentaBancaria
 * @see CuentaAhorro
 * @see CuentaCorrientePersonal
 * @see CuentaCorrienteEmpresa
 * @see java.util.Hashtable
 * @author Fernando Arnedo
 * @version 1.0
 */
public abstract class CuentaCorriente extends CuentaBancaria {
    private static final String CARGO_ENTIDAD = ", maximo cargo: ";
    private static final String EURO = " \u20ac";
    private static final String FIN_ENTIDADES = "\n--- Fin entidades asociadas ---";
    private static final String INICIO_ENTIDADES = "\n--- Entidades asociadas ---";
    private static final String INI_TITULO_ENTIDAD = "\n     E";
    Hashtable EntidadesAsociadas;

    /**
     * Constructor de la clase
     * @param Titular Persona titular de la cuenta
     * @param Saldo Valor del saldo inicial de la cuenta
     * @param CCC C�digo Cuenta Corriente
     * @param EntidadesAsociadas Lista de pares de valores (entidad, valor m�ximo de cargo)
     * @throws Exception los correspondientes a la clase CuentaBancaria
     */
    public CuentaCorriente(Persona Titular, double Saldo, String CCC, Hashtable EntidadesAsociadas)  throws Exception {
        super(Titular, Saldo, CCC);
        this.EntidadesAsociadas =  EntidadesAsociadas;
    }

    /**
     * Constructor de la clase que inicializa todos los atributos con valores nulos o cero
     * @throws Exception
     */
    public CuentaCorriente()  throws Exception {
        this(null, 0, null, null);
        EntidadesAsociadas = new Hashtable();
    }

    /**
     *
     * @return Lista de entidades que pueden pasar cargos en cuenta
     */
    public Hashtable getEntidadesAsociadas() {
        return EntidadesAsociadas;
    }

    /**
     * Asigna una lista de entidades que podr�n pasar cargos en cuenta
     * @param EntidadesAsociadas lista de entidades que pueden pasar cargos en cuenta
     */
    public void setEntidadesAsociadas(Hashtable EntidadesAsociadas) {
        this.EntidadesAsociadas = EntidadesAsociadas;
    }

    /**
     * Agrega el par (entidad, cargo) a la lista de entidades que pueden pasar cargos en cuenta
     * @param Entidad valor de la entidad
     * @param Maximo valor del cargo m�ximo a pasar en cuenta
     * @return Lista de entidades tal y como queda despues de agregar la entidad
     * @see CuentaCorriente#QuitarEntidad(java.lang.String)
     */
    public Hashtable AgregarEntidad(String Entidad, double Maximo) {
       EntidadesAsociadas.put(Entidad, Maximo);
       return EntidadesAsociadas;
    }

    /**
     * Elimina la entidad pasada como par�metro de la lista de entidades que
     * pueden pasar cargos en cuenta
     * @param Entidad entidad a eliminar de la lista de entidades
     * @return Nueva lista de entidades tras eliminar la entidad pasada como par�metro
     * @see CuentaCorriente#AgregarEntidad(java.lang.String, double)
     */
    public Hashtable QuitarEntidad(String Entidad) {
       EntidadesAsociadas.remove(Entidad);
       return EntidadesAsociadas;
    }

    /**
     * Sobrescribe el m�todo toString de la clase CuentaBancaria para a�adirle el
     * atributo que representa el tipo de interes de ahorro.
     * @return String con los datos de la cuenta bancaria en un formato presentable
     * @see CuentaBancaria#toString()
     *
     */
    @Override
    public String toString() {
        // Recogemos el valor de la clase ancestro
        String strDatos = super.toString();
        // A�adimos las entidades asociadas y sus m�ximos cargos permitidos
        // Recorriendo la colecci�n
        strDatos += INICIO_ENTIDADES;
        Set set = EntidadesAsociadas.entrySet();
        Iterator it = set.iterator();
        int i = 1;
        while (it.hasNext()) {
            Map.Entry e = (Map.Entry)it.next();
            strDatos += INI_TITULO_ENTIDAD +  i + ": " + e.getKey() + CARGO_ENTIDAD + e.getValue()+ EURO;
            i++;
            }
        strDatos += FIN_ENTIDADES;
        return strDatos;
    }
    
}
