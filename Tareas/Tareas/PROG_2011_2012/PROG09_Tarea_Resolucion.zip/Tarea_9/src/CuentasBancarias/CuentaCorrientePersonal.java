
package CuentasBancarias;

import Usuarios.Persona;
import java.util.Hashtable;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una cuenta corriente personal. <br>
 * Deriva de la clase CuentaCorriente, por lo que hereda los m�todos y
 * propiedades de esta clase.<br>
 *
 * Se define el atributo:<br><ul>
 *  <li><b>ComisionMantenimiento</b>, variable de tipo double en la que se
 *          almacenar� el valor de la comisi�n aplicable al mantenimiento de
 *          la cuenta.</li>
 *  </ul>
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @see CuentaBancaria
 * @see CuentaCorriente
 * @see CuentaAhorro
 * @see CuentaCorrienteEmpresa
 * @author Fernando Arnedo
 * @version 1.0
 */
public class CuentaCorrientePersonal extends CuentaCorriente {
    private static final String COMISION_MANTENIMIENTO = "\nComisi�n de mantenimiento; ";
    Double ComisionMantenimiento;

    /**
     * Constructor de la clase que inicializa los atributos de la misma con los
     * valores pasados como par�metros
     * @param Titular Persona titular de la cuenta
     * @param Saldo Valor del saldo inicial de la cuenta
     * @param CCC C�digo Cuenta Corriente
     * @param EntidadesAsociadas Lista de pares de valores (entidad, valor m�ximo de cargo)
     * @param ComisionMantenimiento Cantidad que se cargar� en cuenta en concepto de Mantenimiento
     * @throws Exception los correspondientes a la clase CuentaBancaria
     * *
     * @see CuentaBancaria
     * @see CuentaCorriente
     */
    public CuentaCorrientePersonal(Persona Titular, double Saldo, String CCC, Hashtable EntidadesAsociadas, Double ComisionMantenimiento) throws Exception {
        super(Titular, Saldo, CCC, EntidadesAsociadas);
        this.ComisionMantenimiento = ComisionMantenimiento;
    }

    /**
     * Constructor de la clase que inicializa todos los atributos con valores nulos o cero
     * @throws Exception
     * @see CuentaBancaria
     * @see CuentaCorriente
     */
    public CuentaCorrientePersonal() throws Exception {
        this.ComisionMantenimiento = 0D;
    }

    /**
     * 
     * @return Cantidad a aplicar en concepto de mantenimiento de la cuenta
     */
    public Double getComisionMantenimiento() {
        return ComisionMantenimiento;
    }

    /**
     * Modifica la cantidad a cobrar en concepto de mantenimiento de la cuenta
     * con el valor pasado como par�metro
     * @param ComisionMantenimiento Cantidad a cobrar en concepto de mantenimiento de la cuenta
     */
    public void setComisionMantenimiento(Double ComisionMantenimiento) {
        this.ComisionMantenimiento = ComisionMantenimiento;
    }

    /**
     * Sobrescribe el m�todo toString de la clase CuentaCorriente para a�adirle el
     * atributo que representa el tipo de interes de ahorro.
     * @return String con los datos de la cuenta bancaria en un formato presentable
     * @see CuentaBancaria#toString()
     * @see CuentaBancaria#toString()
     */
    @Override
    public String toString() {
        // Recogemos el valor de la clase ancestro
        String strDatos = super.toString();
        // A�adimos la comisi�n de mantenimiento a los datos a mostrar
        strDatos += COMISION_MANTENIMIENTO + ComisionMantenimiento;
        return strDatos;
    }

}
