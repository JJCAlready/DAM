
package CuentasBancarias;

import Usuarios.Persona;
import java.util.Hashtable;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una cuenta corriente de empresa. <br>
 * Deriva de la clase CuentaCorriente, por lo que hereda los m�todos y
 * propiedades de esta clase.<br>
 *
 * Se definen los atributos:<br><ul>
 *  <li><b>TipoInteresDescubierto</b>, variable de tipo double en la que se
 *          almacenar� el valor del tipo de inter�s aplicable a los saldos
 *          negativos de la cuenta.</li>
 *  <li><b>ComisionDescubierto</b>, variable de tipo double en la que se
 *          almacenar� el valor de la comisi�n aplicable a los saldos
 *          negativos de la cuenta.</li>
 *  </ul>
 *
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @see CuentaBancaria
 * @see CuentaCorriente
 * @see CuentaAhorro
 * @see CuentaCorrientePersonal
 *
 * @author Fernando Arnedo Ayensa
 */
public class CuentaCorrienteEmpresa extends CuentaCorriente {
    private static final String COMISION_DESCUBIERTO = "\nComisi\u00f3n descubierto: ";
    private static final String EURO = " \u20ac";
    private static final String INTERES_DESCUBIERTO = "\nTipo interes descubierto: ";
    private static final String MAXIMO_DESCUBIERTO = "\nMaximo descubierto: ";
    double TipoInteresDescubierto;
    double ComisionDescubierto;

    /**
     * Constructor de la clase que inicializa los atributos de la misma con los
     * valores pasados como par�metros
     * @param Titular Persona titular de la cuenta
     * @param Saldo Valor del saldo inicial de la cuenta
     * @param CCC C�digo Cuenta Corriente
     * @param MaxDescubierto
     * @param EntidadesAsociadas Lista de pares de valores (entidad, valor m�ximo de cargo)
     * @param TipoInteresDescubierto Valor del inter�s a aplicar a los saldos negativos
     * @param ComisionDescubierto Cantidad a cargar en cuenta en concepto de saldos negativos
     *
     * @throws Exception Las propias de la clase CuentaBancaria
     *
     * @see CuentaBancaria
     * @see CuentaCorriente
     */
    public CuentaCorrienteEmpresa(Persona Titular, double Saldo, String CCC,
            Hashtable EntidadesAsociadas, double MaxDescubierto,
            double TipoInteresDescubierto, double ComisionDescubierto) throws Exception {
        super(Titular, Saldo, CCC, EntidadesAsociadas);
        if (MaxDescubierto < 0 || TipoInteresDescubierto < 0 || ComisionDescubierto < 0)
            throw new Exception(CuentaBancaria.EXCEPTION_CANTIDAD_INVALIDA);
        this.MaxDescubierto = MaxDescubierto;
        this.TipoInteresDescubierto = TipoInteresDescubierto;
        this.ComisionDescubierto = ComisionDescubierto;
    }

    /**
     * Constructor de la clase que inicializa todos los atributos con valores nulos o cero
     * @throws Exception
     * @see CuentaBancaria
     * @see CuentaCorriente
     */
    public CuentaCorrienteEmpresa() throws Exception {
        this(null, 0D, null, null, 0D, 0D, 0D);
    }

    /**
     * Sobrescribe el m�todo toString de la clase CuentaCorriente para a�adirle el
     * los atributos que representan el m�ximo descubierto permitido, el tipo de
     * inter�s por descubierto y la comis�n a aplicar por descubierto.
     *
     * @return String con los datos de la cuenta bancaria en un formato presentable
     * @see CuentaBancaria#toString()
     * @see CuentaCorriente#toString()
     */
    @Override
    public String toString() {
        String strDatos = super.toString();
        strDatos += MAXIMO_DESCUBIERTO + MaxDescubierto + EURO;
        strDatos += INTERES_DESCUBIERTO + TipoInteresDescubierto + "%";
        strDatos += COMISION_DESCUBIERTO + ComisionDescubierto + EURO;
        return strDatos;
    }

}
