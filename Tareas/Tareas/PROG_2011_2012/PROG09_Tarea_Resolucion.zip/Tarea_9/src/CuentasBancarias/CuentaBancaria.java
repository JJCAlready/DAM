
package CuentasBancarias;

import Utilidades.Imprimible;
import Usuarios.Persona;
import Utilidades.Entrada;
import java.lang.IllegalArgumentException;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una cuenta bancaria. <br>
 * Se trata de una clase abstracta por lo que no pueden instanciarse objetos de
 * esta clase.<br>
 * Sirve de base para los diferentes tipos de cuentas bancarias
 * Se definen los atributos:<br><ul>
 *   <li><b>Titular</b>, Objeto de la clase persona, en el que se almacenar� la
 *       informaci�n referente al titular de la cuenta bancaria</li>
 *   <li><b>Saldo</b>, variable de tipo double en la que se almacenar� el saldo de la
 *       cuenta bancaria</li>
 *   <li><b>CCC</b>, variable de tipo String en la que se almacenar� el C�digo Cuenta
 *       Cliente de la cuenta bancaria</li>
 *   <li><b>MaxDescubierto</b>, variable de tipo double en el que se almacenar� el
 *       m�ximo valor negativo que puede tener el atributo saldo de la cuenta
 *       bancaria</li>
 *  </ul>
 *
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @see CuentaCorriente
 * @see CuentaAhorro
 * @see CuentaCorrientePersonal
 * @see CuentaCorrienteEmpresa
 * @author Fernando Arnedo
 * @version 1.0
 */
public abstract class CuentaBancaria implements Imprimible {
    /**
     * Excepci�n que se lanza cuando se intenta utilizar una cantidad no v�lida al operar con una cuenta
     */
    public static final String EXCEPTION_CANTIDAD_INVALIDA =   "CantidadNoValidaExcepcion";
    /**
     * Excepci�n que se lanza cuando se intenta crear una cuenta bancaria con un CCC no v�lido
     */
    public static final String EXCEPTION_CCC_INVALIDO = "CCCInvalidoException";
    
    /**
     * Excepci�n que se lanza cuando se intenta realizar un retiro que supone un descubierto
     * superior al permitido
     */
    public static final String EXCEPTION_SUPERA_MAX_DESCUBIERTO = "SuperaMaxDescubiertoException";

    private static final String TITULAR = "\nTitular: ";
    private static final String EURO = " \u20ac";
    private static final String FIN_DATOS_CUENTA = "\n ---------- Fin datos Cuenta ----------";
    private static final String INICIO_DATOS_CUENTA = "\n ----------- Datos Cuenta ------------";
    private static final String TX_CCC = "\nCCC: ";
    private static final String FIN_DATOS_TITULAR = "\n-- Fin datos titular -";
    private static final String INICIO_DATOS_TITULAR = "--- Datos titular --- \n";
    private static final String SALDO = "\nSaldo: ";

    // Atributos de la clase
    Persona Titular;
    double Saldo;
    String CCC;
    double MaxDescubierto;

    /**
     * Constructor de la clase
     * @param Titular Persona que ser� la titular de la cuenta bancaria
     * @param Saldo Saldo inicial de la cuenta bancaria
     * @param CCC C�digo cuenta cliente
     * @throws Exception EXCEPTION_CCC_INVALIDO si el CCC introducido es un CCC
     *         no v�lido. <br>
     *         EXCEPTION_CANTIDAD_INVALIDA si el saldo inicial es menor que 0
     */
    public CuentaBancaria (Persona Titular, double Saldo, String CCC) throws Exception {
        if (CCC != null )
            if (!CuentaBancaria.comprobarCCC(CCC))
                throw new Exception(EXCEPTION_CCC_INVALIDO);
        if (Saldo < 0)
                throw new Exception(EXCEPTION_CANTIDAD_INVALIDA);
        else {
            this.Titular = Titular;
            this.Saldo = Saldo;
            this.CCC = CCC;
            MaxDescubierto = 0;
        }
    }

    /**
     * Constructor que inicializa todos los atributos con valores null o 0
     * @throws Exception
     * @see CuentaBancaria#CuentaBancaria(Usuarios.Persona, double, java.lang.String)
     */
    public CuentaBancaria() throws Exception {
        this(null, 0, null);
    }

    /**
     * 
     * @return Valor del CCC de la cuenta
     */
    public String getCCC() {
        return CCC;
    }

    /**
     * Asigna un valor al atributo CCC
     * @param CCC valor a asignar al atributo CCC
     */
    public void setCCC(String CCC) {
        this.CCC = CCC;
    }

    /**
     * Retorna el valor del atributo CCC en el formato Entidad Oficina DC NumeroCuenta
     * @return String con el valor del CCC formateado
     */
    public String getCCCFormateado() {
        return CCC.substring(0, 4) + " " + CCC.substring(4, 8)
                + " " + CCC.substring(8, 10) + " " + CCC.substring(10, 20);
    }

    /**
     * Retorna el valor del atributo CCC en el formato Entidad Oficina DC NumeroCuenta
     * @param CCC C�digo cuenta cliente en formato de 20 digitos seguidos
     * @return String con el valor del CCC formateado
     */
    public static String FormatearCCC(String CCC) {
        String CCCFormateado = null;
        if (comprobarCCC(CCC))
            CCCFormateado = CCC.substring(0, 4) + " " + CCC.substring(4, 8)
                + " " + CCC.substring(8, 10) + " " + CCC.substring(10, 20);
        return CCCFormateado;
    }


    /**
     *
     * @return Valor del atributo Saldo de la cuenta bancaria
     */
    public double getSaldo() {
        return Saldo;
    }

    /**
     * Asigna un valor al atributo Saldo
     * @param Saldo  Valor a asignar al atributo saldo
     */
    protected void setSaldo(double Saldo) {
        this.Saldo = Saldo;
    }

    /**
     * 
     * @return  Objeto Persona, titular de la cuenta bancaria
     */
    public Persona getTitular() {
        return Titular;
    }

    /**
     * Asigna un valor al atributo Titular
     * @param Titular Persona titular de la cuenta bancaria
     */
     public void setTitular(Persona Titular) {
        this.Titular = Titular;
    }

    /**
     *
     * @return Valor del m�ximo descubierto permitido en la cuenta bancaria
     */
    public double getMaxDescubierto() {
        return MaxDescubierto;
    }

    /**
     * Asigna un valor al m�ximo descubierto permitido en la cuenta bancaria
     * @param MaxDescubierto valor a asignar como m�ximo descubierto permitido
     * @throws Exception EXCEPTION_CANTIDAD_INVALIDA si MaxDescubierto es menor  que 0
     * @see CuentaBancaria#EXCEPTION_CANTIDAD_INVALIDA
     */
    public void setMaxDescubierto(double MaxDescubierto) throws Exception {
        if (MaxDescubierto>=0)
            this.MaxDescubierto = MaxDescubierto;
        else
            throw new Exception(EXCEPTION_CANTIDAD_INVALIDA);
    }


   
    /**
     * Sobrescribe el m�todo toString de la clase Object
     * @return String con los datos de la cuenta bancaria en un formato presentable 
     */
    @Override
    public String toString() {
        String strCuenta = INICIO_DATOS_TITULAR + Titular.toString()+ FIN_DATOS_TITULAR;
        strCuenta += SALDO + Saldo + EURO;
        //strCuenta += SALDO + Entrada.toEuro(Saldo);
        strCuenta += TX_CCC + getCCCFormateado();
        return strCuenta;
    }

    /**
     *
     * @return String con los datos b�sicos (CCC, nombre y apellidos del
     *         titular y saldo) de la cuenta bancaria en un formato presentable
     */
    public String datosBasicosCuenta() {
        String strCuenta = TX_CCC + getCCCFormateado();
        strCuenta += TITULAR + Titular.getNombre() + " " + Titular.getApellidos();
        strCuenta += SALDO + Saldo + EURO;
       // strCuenta += SALDO + Entrada.toEuro(Saldo);
        return strCuenta;
    }

    /**
     * Imprime por la salida estandar un String con los datos de la clase
     */
    public void Imprimir() {
        String strDatos = INICIO_DATOS_CUENTA;
        strDatos += "\n" + this.toString();
        strDatos += FIN_DATOS_CUENTA;
        System.out.println(strDatos);
    }

    /**
     * Ingresa la cantidad indicada al saldo de la cuenta.
     * Este valor debe ser positivo, en caso contrario se lanza la excepci�n
     * IllegalArgumentException.
     *
     * @param Cantidad Cantidad a ingresar en la cuenta
     * @throws IllegalArgumentException
     * @return valor del nuevo saldo tras el ingreso
     * @see CuentaBancaria#Retirar(double)
     */
    public double Ingresar(double Cantidad) throws IllegalArgumentException {
        if (Cantidad < 0 )
            throw new IllegalArgumentException();
        else
            Saldo += Cantidad;
        return Saldo;
    }

    /**
     * M�todo retirar. Se restar� la cantidad indicada del saldo de la cuenta.
     * Este valor debe ser positivo y nunca superior al saldo de la cuenta.
     * De no ser as� se lanzar� la excepci�n IllegalArgumentException
     *
     * @param Cantidad Cantidad a retirar de la cuenta
     * @throws Exception
     * @throws IllegalArgumentException
     * @return nuevo saldo tras el retiro
     * @see CuentaBancaria#Ingresar(double)
     */
    public double Retirar (double Cantidad) throws Exception, IllegalArgumentException {
        double NuevoSaldo = Saldo - Cantidad;
        if (Cantidad < 0 )
            throw new IllegalArgumentException();
        else if((NuevoSaldo + MaxDescubierto) < 0)
            throw new Exception(EXCEPTION_SUPERA_MAX_DESCUBIERTO);
        else
            Saldo = NuevoSaldo;

        return Saldo;
    }

    /**
     * Comprobar la validez de un CCC. El m�todo devolver� true o false
     * indicando si el CCC es v�lido o no.
     *
     * @param CCC 20 d�gitos correspondientes a la cuenta a comprobar
     * @return Cierto si el CCC pasado es un CCC v�lido, false en caso contrario
     * @see <a href="http://es.wikipedia.org/wiki/C%C3%B3digo_cuenta_cliente">C�digo cuenta cliente en Wikipedia</a>
     */
    public static boolean comprobarCCC(String CCC) {
        // obtenemos el DC del CCC pasado
        String DC = CCC.substring(8, 10);
        // calculamos el DC segun resto del CCC
        String DC_Calculado = obtenerDigitosControl(CCC.substring(0, 4),
                CCC.substring(4, 8), CCC.substring(10));
        // comparamos los digitos calculados con los del CCC pasado
        return DC.equals(DC_Calculado);
    }

    /**
     * Calcular los d�gitos de control de un CCC. El m�todo devuelve los dos
     * d�gitos de control, dados los c�digos de entidad, oficina y n�mero de
     * cuenta
     *
     * @param entidad 4 d�gitos correspondientes a la entidad
     * @param oficina 4 d�gitos correspondientes a la oficina
     * @param numCuenta 10 d�gitos correspondientes al n�mero de cuenta
     * @return DC de la CCC generada a partir de los datos pasados
     * @see <a href="http://es.wikipedia.org/wiki/C%C3%B3digo_cuenta_cliente">C�digo cuenta cliente en Wikipedia</a>
     */
    public static String obtenerDigitosControl(String entidad, String oficina,
            String numCuenta) {

        return calculaDigito("00" + entidad + oficina) +
                calculaDigito(numCuenta);

        }

    // Metodos privados

    /**
     * Calcula un d�gito del DC en funci�n de los 10 caracteres pasados como
     * parametro
     *
     * @param strDigitos 10 digitos en base a los cuales se calcular� el
     *        d�gito de control.
     * @return D�gito de control obtenido a partir de strDigitos
     * @see <a href="http://es.wikipedia.org/wiki/C%C3%B3digo_cuenta_cliente">C�digo cuenta cliente en Wikipedia</a>
     */
    private static String calculaDigito(String strDigitos) {
        int pesoDigito[]= {1, 2, 4, 8, 5, 10, 9, 7, 3, 6 };
        int suma=0, resto;
        String DC_Calculado;
        for (int i=0; i<10; i++) {
            suma = suma + pesoDigito[i] *
                    Integer.parseInt( strDigitos.substring(i, i+1));
        }
        resto = suma % 11;
        // obtenemos el valor a devolver dependiendo del resto obtenido
        if (resto == 0)
           DC_Calculado = 0 + "";
        else if (resto == 1)
           DC_Calculado = 1 + "";
        else
           DC_Calculado = 11-resto + "";

        return DC_Calculado;
    }
}
