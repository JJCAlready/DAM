
package CuentasBancarias;

import Usuarios.Persona;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una cuenta de ahorro. <br>
 * Deriva de la clase CuentaBancaria, por lo que hereda los m�todos y
 * propiedades de esta clase.<br>
 *
 * Se define el atributo:<br><ul>
 *   <li><b>TipoInteresAhorro</b>, variable de tipo double en la que se
 * almacenar� el valor para el tipo de inter�s a aplicar al saldo de la cuenta.</li>
 *  </ul>
 *
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @see CuentaBancaria
 * @see CuentaCorriente
 * @see CuentaCorrientePersonal
 * @see CuentaCorrienteEmpresa
 * @author Fernando Arnedo
 * @version 1.0
 */
public class CuentaAhorro extends CuentaBancaria {
    private static final String TIPO_INTERES = "\nTipo interes: ";
    double TipoInteresAhorro;
    /**
     * Constructor de la clase que inicializa los atributos de la misma con los
     * valores pasados como par�metros.
     * @param Titular Persona titular de la Cuenta de Ahorro
     * @param Saldo Saldo inicial de la cuenta
     * @param CCC C�digo Cuenta Cliente de la cuenta
     * @param TipoInteresAhorro Tipo de inter�s a aplicar al saldo de la cuenta
     * @throws Exception Las propias de la clase CuentaBancaria
     * *
     * @see CuentaBancaria
     */
    public CuentaAhorro(Persona Titular, double Saldo, String CCC, double TipoInteresAhorro) throws Exception {
        super(Titular, Saldo, CCC);
        if (TipoInteresAhorro<0)
            throw new Exception(CuentaBancaria.EXCEPTION_CANTIDAD_INVALIDA);
        else
            this.TipoInteresAhorro = TipoInteresAhorro;
    }

    /**
     * Constructor de la clase que inicializa los atributos a null o cero
     * @throws Exception
     */
    public CuentaAhorro() throws Exception  {
        this(null, 0D, null, 0D);
    }

    /**
     *
     * @return Valor de tipo de interes aplicable a la cuenta
     */
    public double getTipoInteresAhorro() {
        return TipoInteresAhorro;
    }

    /**
     * Modifica el valor de tipo de interes a aplicar al saldo de la cuenta
     * @param TipoInteresAhorro Valor a asignar al tipo de interes de ahorro
     */
    public void setTipoInteresAhorro(double TipoInteresAhorro) {
        this.TipoInteresAhorro = TipoInteresAhorro;
    }

    /**
     * Sobrescribe el m�todo toString de la clase CuentaBancaria para a�adirle el
     * atributo que representa el tipo de interes de ahorro.
     * @return String con los datos de la cuenta bancaria en un formato presentable
     */
    @Override
    public String toString() {
        // Recogemos el valor de la clase ancestro
        String strDatos = super.toString();
        // A�adimos las entidades asociadas y sus m�ximos cargos permitidos
        // Recorriendo la colecci�n
        strDatos += TIPO_INTERES + TipoInteresAhorro +"%";
        return strDatos;
    }
}
