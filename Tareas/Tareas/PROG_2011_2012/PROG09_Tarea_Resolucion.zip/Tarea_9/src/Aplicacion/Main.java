
package Aplicacion;

import CuentasBancarias.CuentaAhorro;
import CuentasBancarias.CuentaBancaria;
import CuentasBancarias.CuentaCorrienteEmpresa;
import CuentasBancarias.CuentaCorrientePersonal;
import Usuarios.Persona;
import Utilidades.Entrada;
import Utilidades.Menu;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;




/**
 * Clase para la implementaci�n de la tarea 9 de PROGRAMACI�N DAM
 * Abril de 2012
 *
 * @author Fernando Arnedo Ayensa
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 */
public class Main {
    /*
     * Constantes para literales de texto
     */
    private static final String TX_MAX_DESCUBIERTO = " y el m�ximo descubierto permitido es ";
    private static final String FALLO_OPERARENCUENTA = "Operaci�n no definida para OperarEnCuenta";
    private static final String IMPOSIBLE_RETIRAR = "No es posible retirar ";
    private static final String INTRO_INTERES_DESCUBIERTO = "Introducir tipo interes por descubierto";
    private static final String CCC_EN_USO = "El CCC introducido ya est� en uso";
    private static final String ERROR_ABRIR_CUENTA = "Se produjo un error al abrir una nueva cuenta";
    private static final String ERROR_CUENTA_AHORRO = "Error no controlado al crear cuenta de ahorro - ";
    private static final String ERROR_CUENTA_CORRIENTE = "Error no controlado al crear cuenta corriente personal - ";
    private static final String ERROR_CUENTA_EMPRESA = "Error no controlado al crear cuenta corriente de empresa - ";
    private static final String INTRO_ENTIDAD = "Introducir entidad (FIN para terminar)";
    private static final String INTRO_COMISION_DE_MANT = "Introducir comision de mantenimiento";
    private static final String INTRO_MAX_RECIBO = "Introducir m�xima cantidad por recibo";
    private static final String INTRO_M�XIMO_DESCUBIERTO = "Introducir m�ximo descubierto permitido";
    private static final String INTRO_NOMBRE = "Introducir nombre del titular";
    private static final String INTRO_SALDO = "Introducir saldo inicial";
    private static final String INTRO_TIPO_INTERES = "Introduzca tipo interes";
    private static final String INTRO_APELLIDOS = "Introducir apellidos del titular";
    private static final String INTRO_CANTIDAD = "Introducir cantidad";
    private static final String INTRO_CCC = "Introduzca CCC";
    private static final String INTRO_COM_DESCUBIERTO = "Introducir comisi�n por descubierto";
    private static final String INTRO_FECHA = "Introducir fecha de nacimiento del titular (dd-mm-aaaa)";
    private static final String TX_FIN = "FIN";
    private static final String TX_NO_CUENTA_ = "No existe la cuenta ";
    private static final String TX_SALDO = "Saldo: ";
    private static final String TX_SALDO_ACTUA = ", el saldo actual es de ";
    private static final String TX_SALDO_CUENTA_ANTES = "Saldo en cuenta antes de la operacion: ";
    private static final String TX_SALDO_CUENTA_DESPUES = "Saldo en cuenta despu�s de la operaci�n: ";
    private static final String TX_VALOR_INVALIDO = "El valor introducido no es v�lido";
    private static final String EURO = " \u20ac";

    /*
     * Constantes para presentar el texto de las opciones de men�
     */
    // Constantes para los textos de las opciones del men� principal
    private static final String MENU_ABRIR = "Abrir una nueva cuenta";
    private static final String MENU_DATOS = "Obtener los datos de una cuenta concreta";
    private static final String MENU_INGRESO = "Realizar un ingreso en una cuenta";
    private static final String MENU_LISTAR = "Ver un listado de las cuentas disponibles";
    private static final String MENU_TITULO = "------------- Menu principal ---------------";
    private static final String MENU_RETIRO = "Retirar efectivo de una cuenta";
    private static final String MENU_SALDO = "Consultar el saldo actual de una cuenta";
    private static final String MENU_SALIR = "Salir";
    
    // Constantes para los textos de las opciones del tipo cuenta
    private static final String SUBMENU_TITULO = "--- Tipo cuenta a abrir ---";
    private static final String SUBMENU_AHORRO = "Cuenta Ahorro";
    private static final String SUBMENU_EMPRESA = "Cuenta Corriente Empresa";
    private static final String SUBMENU_PERSONAL = "Cuenta Corriente Personal";

    /*
     * Constantes para representar cada una de las opciones del men�
     *
     */
    // Constantes para las opciones del men� principal
    private static final char OPCION_NUEVA = '1';
    private static final char OPCION_LISTAR = '2';
    private static final char OPCION_DATOS = '3';
    private static final char OPCION_INGRESO = '4';
    private static final char OPCION_RETIRO = '5';
    private static final char OPCION_SALDO = '6';
    private static final char OPCION_SALIR = '7';

    //Constantes para representar las opciones del tipo decuenta
    private static final char OPCION_CUENTA_AHORRO = '1';
    private static final char OPCION_CUENTA_CORRIENTE_PERSONAL = '2';
    private static final char OPCION_CUENTA_CORRIENTE_EMPRESA = '3';

    // variables a utilizar por todos los m�todos

    /**
     * Patron para un CCC, se permiten 20 digitos seguidos o 20 digitos separados por '-' o por espacios
     */
    private static final String ER_CCC = "([0-9]{20})|([0-9]{4}-[0-9]{4}-[0-9]{2}-[0-9]{10})|([0-9]{4} [0-9]{4} [0-9]{2} [0-9]{10})";

    /**
     * Patron para un nombre o apellidos. <br>
     * Un nombre o apellidos est� formado por una o m�s palabras. La primera
     * palabra debe ser de al menos dos letras
     */
    private static final String ER_NOMBRE_APELLIDOS = "[a-zA-Z������A�����?? ]{2,}( ([a-zA-Z������A�����?? ]{1,}))*";

    /**
     * Patron para las entidades. <br>
     * Similar al patr�n utilizado para los nombres y apellidos pero a�adiendo el posible uso de guiones y n�meros
     */
    private static final String ER_ENTIDAD = "[0-9a-zA-Z������A�����\\-_?? ]{2,}( ([0-9a-zA-Z������A�����\\-_?? ]{1,}))*";



    private static enum TipoOperacion { INGRESAR, RETIRAR, SALDO, DATOS_CUENTA };

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean bSalir = false;
        CuentaBancaria cuentaBancaria;
        HashMap listaCuentas = new HashMap();
        Menu menuPrincipal = CrearMenu();
        // presentar y leer menu mientras no se seleccione la opcion salir
        do {
            // obedeceedo r a la opci�n seleccionada por el usuario
           // switch (opcion_Menu()) {
           switch (menuPrincipal.Mostrar()) {
                case OPCION_NUEVA :
                    // Se realizan las acciones necesarias para abrir una nueva cuenta
                    cuentaBancaria = AbrirNuevaCuenta(listaCuentas);
                    // Si todo fue bien se agrega dicha cuenta a la lista de cuentas
                    if (cuentaBancaria != null)
                       listaCuentas.put(cuentaBancaria.getCCC(), cuentaBancaria);
                    // En caso contrario mostramos el error para poder programar
                    // la soluci�n requerida. Esto no deber�a ocurrir nunca
                    else
                       System.out.println(ERROR_ABRIR_CUENTA);
                    break;

                case OPCION_LISTAR:
                    ListarCuentas(listaCuentas);
                    break;

                case OPCION_DATOS:
                    OperarEnCuenta(TipoOperacion.DATOS_CUENTA, listaCuentas);
                    break;
                    
                case OPCION_INGRESO:
                    OperarEnCuenta(TipoOperacion.INGRESAR, listaCuentas);
                    break;

                case OPCION_RETIRO:
                    OperarEnCuenta(TipoOperacion.RETIRAR, listaCuentas);
                    break;

                case OPCION_SALDO:
                    OperarEnCuenta(TipoOperacion.SALDO, listaCuentas);
                    break;

                case OPCION_SALIR:
                    // No es necesario realizar nada antes de salir
                    bSalir = true;
                    break;
            }
            // permanecer en el men� hasta que se seleccione salir
        } while (!bSalir);
    }


   /**
    * Muestra por la salida estandar un listado de las cuentas que contiene la lista de cuentas bancarias
    * @param listaCuentas lista que contiene las cuentas bancarias
    */
   private static void ListarCuentas(HashMap listaCuentas) {
       System.out.println("------------- Listado de cuentas --------------------------");
       // Recorrremos toda la lista imprimiendo los datos b�sicos de cada una
       int i=1;
       Set set = listaCuentas.entrySet();
       Iterator it = set.iterator();
       while (it.hasNext()) {
            Map.Entry e = (Map.Entry)it.next();
            if (i!=1)
                System.out.println("---------------------------------------");
            System.out.println(((CuentaBancaria)e.getValue()).datosBasicosCuenta());
            i++;
       }
       System.out.println("------------ Fin listado de cuentas ------------------------");
   }
    
   /**
    * Se encarga de pedir los datos necesarios para abrir una nueva cuenta bancaria
    * y la crea. <br>
    * En primer lugar solicita el CCC y comprueba si no existe previamente en la
    * lista de cuentas bancarias existentes. En caso de existir, avisa al usuario
    * de tal circunstancia, instando a introducir un nuevo CCC
    * @param listaCuentas lista de cuentas bancarias existentes
    * @return cuenta bancaria creada o null en caso de no haberse podido crear la cuenta
    */
   private static CuentaBancaria AbrirNuevaCuenta(HashMap listaCuentas) {
        CuentaBancaria cuentaBancaria = null;
        Menu menuTipoCuenta = CrearSubMenu();
        String strCCC;
        boolean bValido = false;
        do {
            // Solicitamos el CCC de la cuenta a crear
            strCCC = PedirCCC();
            // En caso de no existir una cuenta con ese CCC salimos del bucle
            if (!listaCuentas.containsKey(strCCC))
                 bValido = true;
            // en caso contrario, lo notificamos y seguimos insistiendo
             else
                 System.out.println(CCC_EN_USO);
            } while (!bValido);
        // Solicitamos el resto de datos necesarios
        Persona titular = PedirDatosTitular();
        double saldoInicial = PedirSaldoInicial();
        // Presentamos un submenu para solicitar el tipo de cuenta
        //int tipoCuenta = opcion_Menu_TipoCuenta();
        Hashtable entidades;
        // En funci�n del tipo de cuenta pedimos unos datos u otros, tras lo cual
        // creamos la cuenta
        switch (menuTipoCuenta.Mostrar()) {
                case OPCION_CUENTA_AHORRO :
                    // Pedir datos cuenta ahorro
                    double tipoInteres;
                    do {
                        tipoInteres = Entrada.leerDouble( INTRO_TIPO_INTERES, TX_VALOR_INVALIDO);
                        if (tipoInteres<0)
                            System.out.println(TX_VALOR_INVALIDO);
                    } while(tipoInteres<0);
                    try {
                      cuentaBancaria = new CuentaAhorro(titular, saldoInicial, strCCC, tipoInteres);
                    } catch (Exception ex) {
                        System.out.print(ERROR_CUENTA_AHORRO + ex.getMessage());
                    }
                    break;

                case OPCION_CUENTA_CORRIENTE_PERSONAL:
                    // Pedir datos cuenta corriente personal
                    entidades = PedirEntidades();
                    double comision;
                    do {
                        comision = Entrada.leerDouble( INTRO_COMISION_DE_MANT, TX_VALOR_INVALIDO);
                        if (comision<0)
                            System.out.println(TX_VALOR_INVALIDO);
                    } while (comision<0);
                    try {
                        cuentaBancaria = new CuentaCorrientePersonal(titular, saldoInicial, strCCC, entidades, comision);
                    } catch (Exception ex) {
                        System.out.print(ERROR_CUENTA_CORRIENTE + ex.getMessage());
                    }
                    break;

                case OPCION_CUENTA_CORRIENTE_EMPRESA:
                    // Pedir datos cuenta corriente empresa
                    entidades = PedirEntidades();
                    double maxDescubierto;
                    double interesDescubierto;
                    double comisionDescubierto;
                   // Leer un valor positivo para maxDescubierto
                    do {
                        maxDescubierto = Entrada.leerDouble(INTRO_M�XIMO_DESCUBIERTO, TX_VALOR_INVALIDO);
                        if (maxDescubierto<0)
                            System.out.println(TX_VALOR_INVALIDO);
                    } while (maxDescubierto<0);
                    // Leer un valor positivo para interesDescubierto
                    do {
                        interesDescubierto = Entrada.leerDouble(INTRO_INTERES_DESCUBIERTO, TX_VALOR_INVALIDO);
                        if (interesDescubierto<0)
                            System.out.println(TX_VALOR_INVALIDO);
                    } while (interesDescubierto<0);
                    // Leer un valor positivo para interesDescubierto
                    do {
                        comisionDescubierto = Entrada.leerDouble(INTRO_COMISION_DE_MANT, TX_VALOR_INVALIDO);
                        if (comisionDescubierto<0)
                            System.out.println(TX_VALOR_INVALIDO);
                    } while (comisionDescubierto<0);

                    // Crear la cuenta
                    try {
                      cuentaBancaria = new CuentaCorrienteEmpresa(titular, saldoInicial,
                              strCCC, entidades, maxDescubierto, interesDescubierto, comisionDescubierto);
                    } catch (Exception ex) {
                        System.out.print(ERROR_CUENTA_EMPRESA + ex.getMessage());
                    }
                    break;
            }
        // finalmente, devolvemos la cuenta creada, o null si no se cre� ninguna
        return cuentaBancaria;
    }

   /**
    * Pide los datos necesarios para el titular de una cuenta
    * @return Objeto Persona con los datos introducidos
    */
   private static Persona PedirDatosTitular() {
        String Nombre = Entrada.leerString( INTRO_NOMBRE, TX_VALOR_INVALIDO, ER_NOMBRE_APELLIDOS);
        String Apellidos = Entrada.leerString( INTRO_APELLIDOS, TX_VALOR_INVALIDO, ER_NOMBRE_APELLIDOS);
        Date Fecha = Entrada.leerDate( INTRO_FECHA, TX_VALOR_INVALIDO);
        Persona p = new Persona(Nombre, Apellidos, Fecha);
        return p;
    }

   /**
    * Pide el saldo inicial para crear un cuenta, asegur�ndose de que este sea
    * mayor que 0
    * @return Saldo inicial para crear la cuenta
    */
   private static double PedirSaldoInicial() {
        double saldoInicial = -1;
        do {
            saldoInicial = Entrada.leerDouble( INTRO_SALDO, TX_VALOR_INVALIDO);
            if (saldoInicial < 0 )
                System.out.println(TX_VALOR_INVALIDO);
        } while (saldoInicial < 0);
        return saldoInicial;
    }

   /**
    * Pide la entrada por teclado de los digitos de una cuenta bancaria, insistiendo
    * mientras que no sea v�lido
    * @return
    */
   private static String PedirCCC() {
        String CCC;
        boolean bValido = false;
        do {
            CCC = Entrada.leerString( INTRO_CCC, TX_VALOR_INVALIDO, ER_CCC);
            // El CCC se almacenar� y comprobar� siempre como 20 d�gitos seguidos,
            // a pesar de que en la entrada del mismo se permite el uso de espacios
            // o guiones para separar entidad, oficina, dc, y cuenta
            CCC = CCC.replace("-", "");
            CCC = CCC.replace(" ", "");
            bValido = CuentaBancaria.comprobarCCC(CCC);
            if (!bValido)
               System.out.println(TX_VALOR_INVALIDO);
        } while (!bValido);
        return CCC;
    }

   /**
    * Pide la entrada por teclado de pares (entidad, cargo_m�ximo_permitido_en_cuenta)
    * hasta que se introducca el valor "FIN" o "fin" para una entidad
    * @return lista de entidades con sus respectivos cargos
    */
    private static Hashtable PedirEntidades() {
        String strEntidad;
        Hashtable entidades = new Hashtable();
        double maximo;
        do {
            strEntidad = Entrada.leerString( INTRO_ENTIDAD, TX_VALOR_INVALIDO, ER_ENTIDAD);
            // Si se introdujo una entidad
            if (!strEntidad.equalsIgnoreCase(TX_FIN)) {
                // Solicitar valor m�ximo del recibo a domiciliar
                do {
                    maximo = Entrada.leerDouble( INTRO_MAX_RECIBO, TX_VALOR_INVALIDO);
                    if (maximo <= 0)
                        System.out.println(TX_VALOR_INVALIDO);
                  // continuar solicitando valor m�ximo hasta entrar un valor > 0
                } while (maximo<=0);
                entidades.put(strEntidad, maximo);
            }
         // no salir del bucle hasta introducir FIN
        } while ((!strEntidad.equalsIgnoreCase(TX_FIN)));
        // retornar las entidades introducida
        return entidades;
    }

    /**
     * Realiza en cuenta un ingreso o un retiro, dependiendo del tipo de operaci�n solicitada
     * @param operacion Operaci�n a realizar en cuenta (retirar, ingresar, ver saldo, ver datos cuenta)
     * @param listaCuentas lista de cuentas en la que buscar la cuenta a operar
     */
    private static void OperarEnCuenta(TipoOperacion operacion, HashMap listaCuentas) {
        // Pedir cuenta para la operacion
        String strCCC = PedirCCC();
        CuentaBancaria cuentaBancaria = (CuentaBancaria)listaCuentas.get(strCCC);
        // Si no existe la cuenta bancaria, avisamos de la circunstancia

        if (cuentaBancaria==null) {
            strCCC = CuentaBancaria.FormatearCCC(strCCC);
            System.out.println(TX_NO_CUENTA_ + strCCC);
        }
        // En caso de existir la cuenta
        else { 
            // Si se trata de ver el saldo
            if (operacion==TipoOperacion.SALDO)
                System.out.println(TX_SALDO + cuentaBancaria.getSaldo() + EURO);
            // Si es una operaci�n de imprimir datos de la cuenta
            else if (operacion==TipoOperacion.DATOS_CUENTA)
                cuentaBancaria.Imprimir();
            // Si es una operaci�n de ingreso o retiro
            else {
                // pedir cantidad
                double cantidad = -1;
                // insistir hasta que la cantidad sea positiva o cero
                do {
                   cantidad = Entrada.leerDouble( INTRO_CANTIDAD, TX_VALOR_INVALIDO);
                   if (cantidad < 0)
                          System.out.println(TX_VALOR_INVALIDO);
                   } while (cantidad < 0);
                try {
                     System.out.println(TX_SALDO_CUENTA_ANTES + cuentaBancaria.getSaldo() + EURO);
                     if (operacion == TipoOperacion.INGRESAR)
                         cuentaBancaria.Ingresar(cantidad);
                     else if (operacion == TipoOperacion.RETIRAR)
                         cuentaBancaria.Retirar(cantidad);
                     else
                         System.out.println(FALLO_OPERARENCUENTA);
                     System.out.println(TX_SALDO_CUENTA_DESPUES + cuentaBancaria.getSaldo() + EURO);
                     listaCuentas.put(strCCC, cuentaBancaria);
                     } catch (Exception e) {
                        if (e.getMessage().equals(CuentaBancaria.EXCEPTION_SUPERA_MAX_DESCUBIERTO))
                            System.out.println(IMPOSIBLE_RETIRAR + cantidad  + EURO +
                                  TX_SALDO_ACTUA + cuentaBancaria.getSaldo() + EURO +
                                  TX_MAX_DESCUBIERTO + cuentaBancaria.getMaxDescubierto() + EURO        );

                     } // fin catch
            } // fin si es retiro o ingreso
        } // fin si es una cuenta v�lida
    } // fin de la funci�n


    /**
     * Crear el men� principal de la aplicaci�n
     * @return Menu creado
     * @see Menu
     * @see Menu#AgregarEntrada(char, java.lang.String)
     */
    private static Menu CrearMenu() {
        Menu menu = new Menu();
        menu.AgregarEntrada('0', MENU_TITULO);
        menu.AgregarEntrada(OPCION_NUEVA, MENU_ABRIR);
        menu.AgregarEntrada(OPCION_LISTAR, MENU_LISTAR);
        menu.AgregarEntrada(OPCION_DATOS, MENU_DATOS);
        menu.AgregarEntrada(OPCION_INGRESO, MENU_INGRESO);
        menu.AgregarEntrada(OPCION_RETIRO, MENU_RETIRO);
        menu.AgregarEntrada(OPCION_SALDO, MENU_SALDO);
        menu.AgregarEntrada(OPCION_SALIR, MENU_SALIR);
        return menu;
    }



    /**
     * Crea el submenu para pedir el tipo de cuenta bancaria a abrir
     * @return Menu creado
     * @see Menu
     * @see Menu#AgregarEntrada(char, java.lang.String)
     */
    private static Menu CrearSubMenu() {
        Menu menu = new Menu();
        menu.AgregarEntrada('0', SUBMENU_TITULO);
        menu.AgregarEntrada(OPCION_CUENTA_AHORRO, SUBMENU_AHORRO);
        menu.AgregarEntrada(OPCION_CUENTA_CORRIENTE_PERSONAL, SUBMENU_PERSONAL);
        menu.AgregarEntrada(OPCION_CUENTA_CORRIENTE_EMPRESA, SUBMENU_EMPRESA);
        return menu;
  }
}
