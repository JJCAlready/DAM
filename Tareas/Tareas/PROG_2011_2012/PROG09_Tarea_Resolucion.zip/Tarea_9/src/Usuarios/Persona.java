
package Usuarios;

import Utilidades.Imprimible;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase para la implementaci�n de la Tarea 9 del m�dulo de Programaci�n
 * del ciclo Desarrollo de Aplicaciones Multiplataforma.<br>
 * Se utiliza para guardar los datos referentes a una persona que ser� la
 * titular de una cuenta bancaria. <br>
 * Se definen los atributos Nombre, Apellidos y Fecha_Nacimiento.
 *
 * @see <a href="../resources/DiagramaClases.png">Diagrama de clases de la aplicaci�n</a>
 * @author Fernando Arnedo
 * @version 1.1
 */
public class Persona implements Imprimible {
    private String Nombre;
    private String Apellidos;
    private Date Fecha_Nacimiento;

    /**
     * Constructor de la clase
     *
     * @param Nombre Valor para asignar al atributo Nombre
     * @param Apellidos Valor para asignar al atributo Apellidos
     * @param Fecha_Nacimiento Valor para asignar al atributo Fecha_Nacimiento
     */
    public Persona(String Nombre, String Apellidos, Date Fecha_Nacimiento) {
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    /**
     * Constructor de la clase que inicializa todos los atributos a null
     */
    public Persona() {
        this(null, null, null);
    }

    /**
     * M�todo que retorna el valor del atributo Apellidos
     * @return valor del atributo Apellidos
     */
    public String getApellidos() {
        return Apellidos;
    }

     /**
     * M�todo que asigna un valor al atributo Apellidos
     * @param Apellidos Valor a asignar al atributo Apellidos
     */
    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    /**
     * M�todo que retorna el valor del atributo Fecha_Nacimiento
     * @return valor del atributo Fecha_Nacimiento
     */
    public Date getFecha_Nacimiento() {
        return Fecha_Nacimiento;
    }

    /**
     * M�todo que asigna un valor al atributo Fecha_Nacimiento
     * @param Fecha_Nacimiento Valor a asignar al atributo Fecha_Nacimiento
     */
    public void setFecha_Nacimiento(Date Fecha_Nacimiento) {
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    /**
     * M�todo que retorna el valor del atributo Nombre
     * @return valor del atributo Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * M�todo que asigna un valor al atributo Nombre
     * @param Nombre Valor a asignar al atributo Nombre
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * Sobrescribe el m�todo toString para una mejor presentaci�n de la clase 
     * @return String con los datos de los atributos en un formato imprimible
     */
    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String strPersona = "Nombre: " + Nombre;
        strPersona += "\nApellidos: " + Apellidos;
        strPersona += "\nFecha nacimiento: " + sdf.format(Fecha_Nacimiento);
        return strPersona;
    }

    /**
     * Imprime por la salida estandar un String con los datos de la clase
     */
    public void Imprimir() {
        String strDatos = "\n ----------- Datos persona ------------";
        strDatos += "\n" + this.toString();
        strDatos += "\n ---------- Fin datos persona ----------";
        System.out.println(strDatos);
    }
}
