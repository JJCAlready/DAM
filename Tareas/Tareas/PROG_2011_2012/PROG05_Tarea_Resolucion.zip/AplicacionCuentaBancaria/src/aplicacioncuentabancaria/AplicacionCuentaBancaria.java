package aplicacioncuentabancaria;

// Paquete implementado para tareas anteriores y que se reutiliza en esta.
// Su finalidad es facilitar la entrada por teclado de diferentes tipos de dato
import Utilidades.Entrada;

/**
 * Clase para la implementación de la tarea 5 del módulo de Programación del
 * ciclo DAM.
 * 
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 * @version 1.0
 */
public class AplicacionCuentaBancaria {

    /**
     * @param argumentos de la linea de comandos, no se requieren
     */
    public static void main(String[] args) {
        boolean bSalir = false; 
        boolean bSalir2 = false; 
        String entidad, oficina, numCuenta, DC;
        Double cantidad;
        
        // Creamos la cuenta bancaria
        CuentaBancaria cuenta = new CuentaBancaria("Fernando Arnedo Ayensa", 
                "00720101930000122351");
        
        // presentar y leer menu mientras no se seleccione la opcion salir
        do {
            switch(opcion_Menu()) {
                case '1':
                    // Ver número de cuenta completo
                    entidad = cuenta.obtenerEntidad();
                    oficina = cuenta.obtenerOficina();
                    numCuenta = cuenta.obtenerNumCuenta();
                    DC = CuentaBancaria.obtenerDigitosControl(entidad, 
                            oficina, numCuenta);
                    System.out.println("CCC: " + entidad + oficina + DC + numCuenta);
                    break;
                
                case '2':
                    // Ver el titular de la cuenta
                    System.out.println("Titular: " + cuenta.obtenerTitular());
                    break;
                
                case '3':
                    // Ver el código de la entidad
                    System.out.println("Entidad: " + cuenta.obtenerEntidad());
                    break;
                
                case '4':
                    // Ver el código de la oficina
                     System.out.println("Oficina: " + cuenta.obtenerOficina());
                    break;
                
                case '5':
                    // Ver número de cuenta
                     System.out.println("Numero de cuenta: " + cuenta.obtenerNumCuenta());
                    break;
                
                case '6':
                    // Ver los dígitos de control
                    entidad = cuenta.obtenerEntidad();
                    oficina = cuenta.obtenerOficina();
                    numCuenta = cuenta.obtenerNumCuenta();
                    DC = CuentaBancaria.obtenerDigitosControl(entidad, 
                            oficina, numCuenta);
                     System.out.println("DC: " + DC);
                    break;
                
                case '7':
                    // Realizar un ingreso
                    // Tratamos de realizar el ingreso hasta lograrlo
                    bSalir2 = false;
                    do {
                        cantidad = Entrada.leerDouble("Introduzca cantidad a ingresar", 
                            "El valor introducido no es válido");
                        try {
                            cuenta.ingresar(cantidad);
                            bSalir2 = true;
                        }
                        catch (IllegalArgumentException e) {
                           System.out.println("El valor introducido no es válido");
                           bSalir2 = false;
                        }
                    } while (!bSalir2);
                    break;
                
                case '8':
                    // Retirar efectivo
                    // Tratamos de realizar el retiro hasta lograrlo
                    bSalir2 = false;
                    do {
                        cantidad = Entrada.leerDouble("Introduzca cantidad a retirar", 
                            "El valor introducido no es válido");
                        try {
                            cuenta.retirar(cantidad);
                            bSalir2 = true;
                        }
                        catch (IllegalArgumentException e) {
                           System.out.println("El valor introducido no es válido");
                           bSalir2 = false;
                        }
                    } while (!bSalir2);
                    break;
                
                case '9':
                    // Consultar saldo
                    System.out.println("Saldo: " + cuenta.obtenerSaldo());
                    break;    
                case '0':
                    bSalir=true;
                    break; 
            }
          // permanecer en el menú hasta que se seleccione salir 
        } while (!bSalir);
        
    }
    
     /**
     * Funcion que solicita por pantalla un menu y solicita la introducción de 
     * de la opción seleccionada
     *
     * @return  caracter correspondiente a la opción seleccionada
     */  
   private static char opcion_Menu() {
       String opcionSeleccionada = "";
       boolean valorValido = false;
              
       // Mostramos el menu
       System.out.println("\nMenú Aplicación Cuenta Bancaria");
       System.out.println("-------------------------------\n");
       System.out.println("\t1.- Ver el número de cuenta completo (CCC – Código Cuenta Cliente).");
       System.out.println("\t2.- Ver el titular de la cuenta.");
       System.out.println("\t3.- Ver el código de la entidad.");
       System.out.println("\t4.- Ver el código de la oficina.");
       System.out.println("\t5.- Ver el número de la cuenta.");
       System.out.println("\t6.- Ver los dígitos de control de la cuenta.");
       System.out.println("\t7.- Realizar un ingreso.");
       System.out.println("\t8.- Retirar efectivo.");
       System.out.println("\t9.- Consultar saldo.");
       System.out.println("\t0.- Salir.\n");
 
       // Leemos el teclado hasta obtener una opción válida
       do {
           opcionSeleccionada = Entrada.leerString("\tSeleccione una opción: ", "\tOpción no válida");
           // Si la opcion seleccionada está en el rango establecido, marcar como válida
           if (opcionSeleccionada.compareTo("0") >= 0 && opcionSeleccionada.compareTo("9") <= 0)
               valorValido = true;   
           else 
               System.out.println("\tOpción no válida"); 

      } while (!valorValido);
      // Una vez leida una opción válida la retornamos 
      return opcionSeleccionada.charAt(0);
   }
}
