package aplicacioncuentabancaria;

import java.lang.IllegalArgumentException;

/**
 * Clase para la implementación de la tarea 5 del módulo de Programación del
 * ciclo DAM.
 *
 * Una cuenta bancaria se compone de una persona titular de la cuenta, el saldo
 * en euros, y un código de cuenta (el CCC o Código Cuenta Cliente).
 * El CCC consta de 20 dígitos: 4 dígitos que representan el código de la
 * entidad, 4 dígitos que representan el código de la oficina, 2 dígitos de
 * control y 10 dígitos con el número de la cuenta. Los dos dígitos de control
 * se calculan con los valores de la entidad, la oficina y el número de cuenta
 * por lo que no es necesario almacenarlos.
 * El nombre del titular tendra una longitud máxima de 100 caracteres y una
 * longitud mínima de 10 caracteres
 *
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 * @version 1.0
 */
public class CuentaBancaria {
    // Atributos privados
    private String titular;
    private double saldo;
    private String entidad;
    private String oficina;
    private String numCuenta;
    
    // Atributos de clase públicos
    public static int MAX_LONG_TITULAR = 100;
    public static int MIN_LONG_TITULAR = 10;
    
    // Metodos públicos
    
   /**
     * Constructor con los parámetros básicos de la cuenta corriente. Si alguno
     * de los parámetros y/o el CCC no es válido se lanza la excepción
     * IllegalArgumentException.
     * 
     * @param titular Títular de la cuenta
     * @param entidad 4 dígitos correspondientes a la entidad a la que pertenece
     *        la cuenta
     * @param oficina 4 dígitos correspondientes a la oficina a la que pertenece
     *        la cuenta
     * @param DC  2 digitos de control de la cuenta
     * @param numCuenta 10 digitos correspondientes al número de cuenta
     * @throws IllegalArgumentException 
     */
    public void CuentaBancaria(String titular, String entidad, String oficina, 
            String DC, String numCuenta) throws IllegalArgumentException {
          String DC_Calculado;
          // validar longitud del titular o lanzar excepción  
          if (titular.length() > MAX_LONG_TITULAR 
                 || titular.length() < MIN_LONG_TITULAR ) 
              throw new IllegalArgumentException();
          else  
              this.titular = titular;
          
          // validar longitud de la entidad o lanzar excepción  
          if (entidad.length() != 4) 
              throw new IllegalArgumentException();
          else  
              this.entidad = entidad;
          
          // validar longitud de la oficina o lanzar excepción  
          if (oficina.length() != 4) 
              throw new IllegalArgumentException();
          else  
              this.oficina = oficina;
          
          // validar longitud de la cuenta o lanzar excepción  
          if (numCuenta.length() != 10) 
              throw new IllegalArgumentException();
          else  
              this.numCuenta = numCuenta;
        
          // validar DC
          DC_Calculado = CuentaBancaria.obtenerDigitosControl(entidad, oficina, numCuenta);
          if (!DC_Calculado.equals(DC))
             throw new IllegalArgumentException();     
       
    }
    
    
    /**
     * Constructor con los parámetros titular y CCC sin descomponer. 
     * Este constructor descompone CCC y llama al constructor básico
     * Si alguno de los parámetros y/o el CCC no es válido se lanza la 
     * excepción IllegalArgumentException.
     * 
     * @param titular Titular de la cuenta
     * @param CCC 20 dígitos correspondientes a la entidad, oficina, digitos de
     *        control y número de cuenta
     * @throws IllegalArgumentException 
     */
    public CuentaBancaria(String titular, String CCC) throws IllegalArgumentException {
        String entidad_CCC;
        String oficina_CCC;
        String numCuenta_CCC;
        String DC_CCC;
        
        // Descomponemos el CCC
        entidad_CCC = CCC.substring(0, 4);
        oficina_CCC = CCC.substring(4, 8);
        DC_CCC = CCC.substring(8, 10);
        numCuenta_CCC = CCC.substring(10, 20);
        
        // Llamamos al constructor básico
        try {
            CuentaBancaria(titular, entidad_CCC, oficina_CCC, DC_CCC, numCuenta_CCC);
        }
        catch (IllegalArgumentException e) {
           throw new IllegalArgumentException(); 
        } 
        
    }
    
    
    // Métodos obtener y establecer
    
    /**
     * Modifica el valor del atributo que identifica al Titular de la cuenta
     * @param titular Titular de la cuenta
     * @throws IllegalArgumentException 
     */
    public void establecerTitular (String titular) throws IllegalArgumentException {
        // validar longitud del titular o lanzar excepción  
          if (titular.length() > MAX_LONG_TITULAR 
                 || titular.length() < MIN_LONG_TITULAR ) 
              throw new IllegalArgumentException();
          else  
              this.titular = titular;
    }
    
    /**
     * 
     * @return Valor del atributo entidad
     */
    public String obtenerEntidad() {
        return entidad;
    }

    /**
     * 
     * @return 10 Digitos correspondientes al numero de cuenta
     */
    public String obtenerNumCuenta() {
        return numCuenta;
    }

    /**
     * 
     * @return 4 Digitos correspondientes a la oficina
     */
    public String obtenerOficina() {
        return oficina;
    }

    /**
     * 
     * @return Saldo de la cuenta
     */
    public double obtenerSaldo() {
        return saldo;
    }

    /**
     * 
     * @return Titular de la cuenta
     */
    public String obtenerTitular() {
        return titular;
    }

   /**
     * Ingresa el dinero correspondiente al saldo de la cuenta.
     * Este valor debe ser positivo, en caso contrario se lanza la excepción
     * IllegalArgumentException.
     * 
     * @param cantidad Cantidad a ingresar en la cuenta
     * @throws IllegalArgumentException 
     */
    public void ingresar(double cantidad) throws IllegalArgumentException {
        if (cantidad < 0 ) 
            throw new IllegalArgumentException();
        else
            saldo += cantidad;
    }
    
   
    /**
     * Método retirar. Se restará la cantidad indicada del saldo de la cuenta.
     * Este valor debe ser positivo y nunca superior al saldo de la cuenta. 
     * De no ser así se lanzará la excepción IllegalArgumentException
     * 
     * @param cantidad Cantidad a retirar de la cuenta
     * @throws IllegalArgumentException 
     */
    public void retirar(double cantidad)  throws IllegalArgumentException {
        if (cantidad < 0 || cantidad > saldo) 
            throw new IllegalArgumentException();
        else
            saldo -= cantidad;
    }
    
    
    /**
     * Comprobar la validez de un CCC. El método devolverá true o false
     * indicando si el CCC es válido o no.
     * 
     * @param CCC 20 dígitos correspondientes a la cuenta a comprobar
     * @return 
     */
    public static boolean comprobarCCC(String CCC) {
        // obtenemos el DC del CCC pasado
        String DC = CCC.substring(8, 10);
        // calculamos el DC segun resto del CCC
        String DC_Calculado = obtenerDigitosControl(CCC.substring(0, 4),
                CCC.substring(4, 8), CCC.substring(10));
        // comparamos los digitos calculados con los del CCC pasado
        return DC.equals(DC_Calculado);
    }
    
   
    /**
     * Calcular los dígitos de control de un CCC. El método devuelve los dos
     * dígitos de control, dados los códigos de entidad, oficina y número de
     * cuenta
     * 
     * @param entidad 4 dígitos correspondientes a la entidad
     * @param oficina 4 dígitos correspondientes a la oficina
     * @param numCuenta 10 dígitos correspondientes al número de cuenta
     * @return 
     */
    public static String obtenerDigitosControl(String entidad, String oficina, 
            String numCuenta) {
       
        return calculaDigito("00" + entidad + oficina) +
                calculaDigito(numCuenta);
     
        }
        
  
    /**
     * 
     * @return cadena con los datos del titular, CCC y saldo de la cuenta
     */
    @Override
    public String toString() {
        String strTexto = "";
        strTexto += ("\nTitular: " + titular);
        strTexto += ("\nCCC: " + entidad + oficina + 
                obtenerDigitosControl(entidad, oficina, numCuenta) + numCuenta);
        strTexto += ("\nSaldo: " + saldo);
        return strTexto;
    }
    
    // Metodos privados
    
    /**
     * Calcula un dígito del DC en función de los 10 caracteres pasados como
     * parametro
     * 
     * @param strDigitos 10 digitos en base a los cuales se calculará el 
     *        dígito de control.
     * @return Dígito de control obtenido a partir de strDigitos
     */
    private static String calculaDigito(String strDigitos) {
        int pesoDigito[]= {1, 2, 4, 8, 5, 10, 9, 7, 3, 6 };
        int suma=0, resto;
        String DC_Calculado;
        for (int i=0; i<10; i++) {
            suma = suma + pesoDigito[i] * 
                    Integer.parseInt( strDigitos.substring(i, i+1));
        }
        resto = suma % 11;
        // obtenemos el valor a devolver dependiendo del resto obtenido
        if (resto == 0)
           DC_Calculado = 0 + "";
        else if (resto == 1)
           DC_Calculado = 1 + "";
        else
           DC_Calculado = 11-resto + ""; 
        
        return DC_Calculado;
    }
}
