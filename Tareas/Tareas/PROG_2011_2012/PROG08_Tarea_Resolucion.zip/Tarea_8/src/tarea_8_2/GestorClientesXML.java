
package tarea_8_2;

import java.util.ArrayList;
import java.util.Collections;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Clase para la implementación de la tarea 8 del módulo de Programación del
 * ciclo Desarrollo de Aplicaciones Multiplataforma
 * Gestiona el paso de una cadena de texto a un documento XML según los
 * requerimientos de dicha tarea.
 *
 * @author Fernando Arnedo Ayensa
 */
public class GestorClientesXML {
    // Todos los atributos de la clase son privados
    private static String strDNI=null;
    private static String strNombre=null;
    private static String strApellidos=null;
    private static ArrayList arraylistTelefonos = new ArrayList();
    private static ArrayList  arraylistEmails = new ArrayList();
    private static ArrayList  arraylistErrores = new ArrayList();
    private static String [] arraystrEntrada;

    /*
     * Declaración de constantes para los textos
     */
    private static final String ERROR_DNI = ", no concuerda con un DNI";
    private static final String ERROR_NOMBRE = ", no concuerda con un Nombre";
    private static final String ERROR_APELLIDOS = ", no concuerda con unos Apellidos";
    private static final String ERROR_TFNO_EMAIL = ", no concuerda con un telefono ni con un email";
    private static final String ERROR_TFNO_EMAIL_REPETIDO = ", se encuentra repetido";
    private static final String ERROR_POSICION = "Error en la posición ";

    /*
     * Declaración de constantes para los patrones de datos
     */

    // Un DNI está formado por 7 u 8 dígitos seguidos de una letra
    // Un NIE es similar a un DNI solo que empieza por X o Y
    private static final String REGEX_DNI_NIE = "^[XY]{0,1}[0-9]{7,8}[A-Z]";

    // Un nombre o apellidos está formado por una o más palabras. La primera
    // palabra debe ser de al menos dos letras
    private static final String REGEX_NOMBRE_APELLIDOS = "[a-zA-ZáéíóúüAÉÍÓÚÜÑñ ]{2,}( ([a-zA-ZáéíóúüAÉÍÓÚÜÑñ ]{1,}))*";

    // Un telefono puede o no comenzar por un carater + y estar seguido de uno o
    // mas dígitos que podrán estar o no separados por espacios.
    // Se permite que exista un grupo de dígitos encerrados entre paréntesis
    private static final String REGEX_TELEFONO = "^\\+?[0-9 ]*(\\([0-9 ]+\\))*[0-9 ]+";

    // Un email será del tipo usuario@dominio
    // La parte usuario puede contener caracteres alfanuméricos, guiones y .
    // Un dominio a su vez puede tener los mismos caracteres que un usuario, solo
    // que tiene que terminar en un punto seguido de 2 a 4 caracteres alfabeticos
    private static final String REGEX_EMAIL = "^([A-Za-z0-9_\\-\\.])+"
            + "\\@([A-Za-z0-9_\\-\\.])+"
            + "\\.([A-Za-z]{2,4})$";

    /*
     * Métodos de la clase
     */

    /**
     * Constructor de la clase. Toma como parámetro una cadena de texto y en base
     * a dicha cadena rellena los atributos de la clase.
     *
     * @param strEntrada Cadena de texto a partir de la cual se rellenan los
     *        atributos de la clase.
     */
    public GestorClientesXML(String strEntrada) {
        // Guardamos la cadena analizada en le arraylistErrores para mostrarla
        // tras todos los elementos como comentario.
        arraylistErrores.add("CADENA ANALIZADA: " + strEntrada);
        // Partimos la entrada de texto según la posición de las comas
        arraystrEntrada = strEntrada.split(",");
        // Y analizamos cada una de las partes
        for (int i=0; i<arraystrEntrada.length; i++) {
            String strPosErr = ERROR_POSICION + i + ": ";
            switch (i) {
                case 0:
                    // La primera parte debería corresponder con un DNI o NIE
                    strDNI = arraystrEntrada[i].toUpperCase().toString();
                     // Si no corresponde con un DNI o un NIE, guardar error
                    if (!strDNI.matches(REGEX_DNI_NIE)) {
                       arraylistErrores.add(strPosErr+arraystrEntrada[i]+ERROR_DNI);
                       strDNI = null;
                    }
                    break;

                case 1:
                    // La segunda parte debería corresponder con un nombre
                    strNombre = arraystrEntrada[i].replace('"', ' ').trim();
                    // Si no corresponde con un nombre, guardar error
                    if (!strNombre.matches(REGEX_NOMBRE_APELLIDOS)) {
                        arraylistErrores.add(strPosErr+arraystrEntrada[i]+ERROR_NOMBRE);
                        strNombre = null;
                    }
                    break;

                case 2:
                    // La tercera parte debería corresponder con unos apellidos
                    strApellidos = arraystrEntrada[i].replace('"', ' ').trim();
                    // Si no corresponde con un nombre, guardar error
                    if (!strApellidos.matches(REGEX_NOMBRE_APELLIDOS)) {
                        arraylistErrores.add(strPosErr+arraystrEntrada[i]+ERROR_APELLIDOS);
                        strApellidos = null;
                    }
                    break;

                default:
                    // El resto de entradas deberían corresponder con teléfonos o arraylistEmails
                    String str = arraystrEntrada[i].trim();
                    // Si es un telefono
                    if (str.matches(REGEX_TELEFONO)) {
                        // quitamos los posibles paréntesis y los espacios intermedios
                        str = str.replace("(", "").replace(")", "").replace(" ", "");
                        // y agregamos el telefono a la lista solo si no había uno igual
                    if (!arraylistTelefonos.contains(str))
                            arraylistTelefonos.add(str);
                        // si ya había uno igual, guardamos error
                        else
                            arraylistErrores.add(strPosErr+str+ERROR_TFNO_EMAIL_REPETIDO);
                    // Si es un email
                    } else if (str.matches(REGEX_EMAIL)) {
                        // lo pasamos a minusculas
                        str = str.toLowerCase();
                        // y agregamos el email a la lista solo si no había uno igual
                        if (!arraylistEmails.contains(str))
                            arraylistEmails.add(str);
                       // si ya había uno igual, guardamos error
                        else
                            arraylistErrores.add(strPosErr+str+ERROR_TFNO_EMAIL_REPETIDO);
                     // Si no es un telefono ni un email, es un error
                    } else
                        arraylistErrores.add(strPosErr+str+ERROR_TFNO_EMAIL);
                    break;
            }
            // una vez recuperados todos los datos, ordenamos los arraylistTelefonos
            Collections.sort(arraylistTelefonos, new ComparadorTelefono());
        }
    }


    /**
     * Método encargado de pasar los datos almacenados en los atributos
     * strDNI, strNombre, strApellidos, arraylistTelefonos,  arraylistEmails y
     * arraylistErrores al documento que se le pasa como parámetro
     * @param doc Documento en que se han de guardar los datos
     * @return  Document El mismo documento que se le pasa como parámetro pero
     *          completo con los elementos creados a partir de los atributos de
     *          la clase.
     */  
    public Document pasarDatosAXML() {
        Document doc=DOMUtil.crearDOMVacio("datos_cliente");
        // Si no se pudo crear el documento, mostrar error y terminar
        if (doc != null) {

            Element e=null;
            // Agregamos el valor del DNI al elemento id
            e = doc.createElement("id");
            doc.getDocumentElement().appendChild(e);
            e.setTextContent(strDNI);

            // Agregamos el valor del nombre al elemento nombre
            e = doc.createElement("nombre");
            doc.getDocumentElement().appendChild(e);
            e.setTextContent(strNombre);

            // Agregamos el valor de los apellidos al elemento apellidos
            e = doc.createElement("apellidos");
            doc.getDocumentElement().appendChild(e);
            e.setTextContent(strApellidos);

            // agregar arraylistTelefonos al elemento telefonos
            e = doc.createElement("telefonos");
            doc.getDocumentElement().appendChild(e);
            // como atributo del elemento ponemos el total de telefonos
            e.setAttribute("total", String.valueOf(arraylistTelefonos.size()));
            // agregamos cada telefono a un nuevo elemento telefono
            for(int i=0; i<arraylistTelefonos.size(); i++) {
                Element t = doc.createElement("telefono");
                t.setTextContent((String)arraylistTelefonos.get(i));
                e.appendChild(t);
            }

            // Agregar arraylistEmails al elemento email
            e = doc.createElement("emails");
            doc.getDocumentElement().appendChild(e);
             // agregamos cada email a un nuevo elemento email
            for(int i=0; i<arraylistEmails.size(); i++) {
                Element t = doc.createElement("email");
                t.setTextContent((String)arraylistEmails.get(i));
                e.appendChild(t);
            }

            // Agregar arraylistErrores como comentarios, un comentario por error
           for(int i=0; i<arraylistErrores.size(); i++) {
             Comment c = doc.createComment((String)arraylistErrores.get(i));
             doc.getDocumentElement().appendChild(c);
           }
        } // Fin if (doc != null)
      return doc;
    }
}
