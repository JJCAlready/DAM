
package tarea_8_2;

/**
 * Clase para realizar la ordenación de los teléfonos solicitada en los
 * requerimientos de la Tarea 8 del módulo de Programación del ciclo Desarrollo
 * de Aplicaciones Multiplataforma
 *
 * @author Fernando Arnedo Ayensa
 */
public class ComparadorTelefono implements java.util.Comparator {

    public int compare(Object o1, Object o2) {
         String str1 = (String)o1;
         String str2 = (String)o2;
         int resultado = 0;
         // analizaremos las cuatro posibles combinaciones de aparición de +
         // en los dos elementos, dando prioridad a los elementos que no
         // contienen + y en el caso de que ambos lo contenga o ambos no lo
         // contengan se establece un orden inverso al de su valor numérico
         // para conseguir el orden deseado en los requerimientos
         if (str1.contains("+") && !str2.contains("+"))
             resultado = 1;
         else if (!str1.contains("+") && str2.contains("+"))
             resultado = -1;
         else {
             // eliminamos el carácter '+' del principio para evitar problemas
             // en el Long.parseLong
             str1 = str1.substring(1);
             str2 = str2.substring(1);
             try {
                 if (Long.parseLong(str1)>Long.parseLong(str2))
                     resultado = -1;
                 else if (Long.parseLong(str1)<Long.parseLong(str2))
                     resultado = 1;
                 else
                     resultado = 0;
             } catch (NumberFormatException e) {
                 System.out.printf("\nSe produjo un error inexperado en "
                         + "ComparadorTelefono.compare(%s, %s) ", str1, str2);
             }
         }
         return resultado;
    }

}
