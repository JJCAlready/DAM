package tarea_8_2;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import org.w3c.dom.Document;

/**
 * Implementación de la tarea 8 del módulo de Programación del ciclo superior
 * Desarrollo de Aplicaciones Multiplataforma
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class Main {
    private static final String ERROR_DATOS_GUARDADOS = "Los datos no pudieron guardarse en el documento ";
    private static final String ERROR_NO_SELECCION_ARCHIVO = "No se seleccionó ningún fichero";
    private static final String ERROR_SELECCION_ARCHIVO = "Ocurrió un error al seleccionar el archivo";
    private static final String ERROR_XML = "No pudo crearse el documento XML";
    private static final String TITULO_DIALOGO = " - Seleccione el archivo de destino";
    private static final String MSG_DATOS_GUARDADOS = "Los datos fueron guardados correctamente.";
    private static final String MSG_INTRODUCIR_DATOS = "Introduzca cadena de datos del cliente";
    private static final String TITULO_APP = "Tarea_08_PROG";

    /**
     * Método principal que contiene el código a ejecutar para resolver los
     * requerimientos de la tarea
     *
     * @param argumentos de la linea de comandos, no se utilizan, aunque en
     *        posteriores versiones podrían utilizarse para pasar como parámetros
     *        la entrada a analizar y la ruta del archivo XML
     */
    public static void main(String[] args) {
        String strFichero = null;
        // Solicitamos la entrada de datos al usuario
        String strEntrada = JOptionPane.showInputDialog(MSG_INTRODUCIR_DATOS);
        // Si el usuario cancela la acción salimos de la aplicación
        if (strEntrada == null)
            return;
        // Analizamos la entrada del usuario y construimos el documento
        GestorClientesXML gcxml = new GestorClientesXML(strEntrada);
        Document doc = gcxml.pasarDatosAXML();
        // Si no se pudo crear el documento, mostrar error y terminar
        if (doc == null) {
            JOptionPane.showMessageDialog(null, ERROR_XML, TITULO_APP, JOptionPane.ERROR_MESSAGE);
            return;
        }
       // Solicitar nombre del documento en el que guardar los datos
        JFileChooser jfilechoser = new JFileChooser();
        jfilechoser.setDialogTitle(TITULO_APP + TITULO_DIALOGO);
        int resultado = jfilechoser.showOpenDialog(null);
        // Si se seleccionó un fichero
        if (resultado == JFileChooser.APPROVE_OPTION) {
           // recogemos el nombre del archivo
           strFichero = jfilechoser.getSelectedFile().getPath();
        // En caso de producirse en error en el cuadro de selección de fichero lo mostramos
        } else if (resultado == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(null, ERROR_SELECCION_ARCHIVO, TITULO_APP, JOptionPane.ERROR_MESSAGE);
        // Y en el caso de no haber seleccionado ningún archivo mostramos el correspondiente mensaje
        } else if (resultado == JFileChooser.CANCEL_OPTION) {
            JOptionPane.showMessageDialog(null, ERROR_NO_SELECCION_ARCHIVO, TITULO_APP, JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        // Guardamos el documento XML en el archivo seleccionado
        if (DOMUtil.DOM2XML(doc,strFichero))
            JOptionPane.showMessageDialog(null, MSG_DATOS_GUARDADOS, TITULO_APP, JOptionPane.ERROR_MESSAGE);
        else
            JOptionPane.showMessageDialog(null, ERROR_DATOS_GUARDADOS, TITULO_APP, JOptionPane.ERROR_MESSAGE);
    }
}
