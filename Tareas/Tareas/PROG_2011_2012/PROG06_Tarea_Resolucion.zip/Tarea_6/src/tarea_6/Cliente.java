package tarea_6;

import Utilidades.Entrada;
import java.io.Serializable;

/**
 * Clase para contener los datos de clientes.
 * Implementa la clase Serializable para poder ser guardado en un fichero de
 * bytes.
 * @author Fernando
 * @version 1.0
 */
public class Cliente implements Serializable {
    private String NIF;
    private String Nombre;
    private String Teléfono;
    private String Dirección;
    private double Deuda;

    /**
     * Crea un String con los datos del cliente
     * @return String con los datos del cliente
     */
    @Override
    public String toString() {
        String strCliente = "\n-----------------------------------------"
                + "--------------------------";
        strCliente += "\nNIF:       " + NIF;
        strCliente += "\nNombre:    " + Nombre;
        strCliente += "\nTeléfono:  " + Teléfono;
        strCliente += "\nDirección: " + Dirección;
        strCliente += "\nDeuda:     " + Deuda;
        strCliente += "\n-----------------------------------------"
                + "--------------------------";
        return strCliente;
    }
    
    /**
     * Pide la entrada por teclado de los datos para asignar a un cliente.
     */
    public void EntrarCliente() {
        System.out.println("\n----------------- Entrada de datos de cliente --"
                + "--------------------------------");
        NIF = Entrada.leerString("\nNIF: ", "El valor introducido no es válido");
        NIF = NIF.trim().toUpperCase();
        Nombre = Entrada.leerString("\nNombre: ", "El valor introducido no es válido");
        Teléfono = Entrada.leerString("\nTeléfono: ", "El valor introducido no es válido");
        Dirección = Entrada.leerString("\nDirección: ", "El valor introducido no es válido");
        Deuda = Entrada.leerDouble("\nDeuda: ", "El valor introducido no es válido");
    }


    /**
     * Da el dato Deuda de un cliente
     * @return double que representa la Deuda del cliente
     */
    public double getDeuda() {
        return Deuda;
    }

    /**
     * Asigna al cliente una deuda
     * @param Deuda double con el valor de la deuda a asignar al cliente
     */
    public void setDeuda(double Deuda) {
        this.Deuda = Deuda;
    }

    /**
     * Da la dirección del cliente
     * @return String conteniendo la dirección del cliente
     */
    public String getDirección() {
        return Dirección;
    }

    /**
     * Asigna una dirección al cliente
     * @param Dirección String que contiene la dirección a asignar al cliente
     */
    public void setDirección(String Dirección) {
        this.Dirección = Dirección;
    }

    /**
     * Da el NIF del cliente
     * @return String que representa el NIF del cliente
     */
    public String getNIF() {
        return NIF;
    }

    /**
     * Asigna un valor al NIF del cliente
     * @param NIF String con el valor a asignar al NIF del cliente
     */
    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    /**
     * Da el nombre del cliente
     * @return String que representa el nombre del cliente.
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * Asigna un valor al nombre del cliente
     * @param Nombre String con el valor a asignar al Nombre del cliente
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * Da el Teléfono del cliente
     * @return String que representa el Teléfono del cliente
     */
    public String getTeléfono() {
        return Teléfono;
    }

    /**
     * Asigna un valor al Teléfono del cliente
     * @param Teléfono String con el valor a asignar al Teléfono del cliente
     */
    public void setTeléfono(String Teléfono) {
        this.Teléfono = Teléfono;
    }

    
}
