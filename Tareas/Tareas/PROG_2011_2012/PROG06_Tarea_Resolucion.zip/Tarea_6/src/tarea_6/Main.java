package tarea_6;

import Utilidades.Entrada;
import java.io.File;



/**
 * Clase para la implementación de la tarea 6 de PROGRAMACIÓN DAM
 * Febrero de 2012
 *
 * @author Fernando Arnedo Ayensa
 */
public class Main {
    // variables a utilizar por todos los métodos
   
    /**
     * Variable para almacenar el NIF de un cliente
     */   
     private static String NIF;

     /**
      * Variable para almacenar la respuesta a un mensaje de confirmación
      * solicitado al usuario
      */
     private static String confirmación;

    /**
     * Variable auxiliar para almacenar un cliente
     */
    private static Cliente cliente;

    /**
     * Variable para guardar la lista de clientes
     */
    private static ListaClientes listaClientes = new ListaClientes();


    // Constantes para representar cada una de las opcione del menú

    /**
     * Constante para representar la opcion de menú de agregar cliente
     */
    private static final char OPCION_AGREGAR_CLIENTE = '1';
    /**
     * Constante para representar la opcion de menú de listar clientes
     */
    private static final char OPCION_LISTAR_CLIENTES = '2';
    /**
     * Constante para representar la opcion de menú de buscar un cliente
     */
    private static final char OPCION_BUSCAR_CLIENTE = '3';
    /**
     * Constante para representar la opcion de menú de borrar un cliente
     */
    private static final char OPCION_BORRAR_CLIENTE = '4';
    /**
     * Constante para representar la opcion de menú de borrar el fichero de datos
     */
    private static final char OPCION_BORRAR_FICHERO = '5';
    /**
     * Constante para representar la opcion de menú Salir de la aplicación
     */
    private static final char OPCION_SALIR = '6';
    

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean bSalir = false;
        // presentar y leer menu mientras no se seleccione la opcion salir
        do {
            // En cada operación que se realice al ejecutar una opción de menú
            // Partiremos de una lista de clientes cargada desde el fichero de
            // datos. Esto no es realmente eficiente, sobre todo si el tamaño
            // del fichero es considerable, ya que lo realmente eficiente sería
            // trabajar durante todas las operaciones sobre la lista de clientes
            // y proceder a su guardado antes de salir o a petición del usuario. 
            // No obstante es lo que se solicita en el enunciado de la tarea
            try {
                 listaClientes.cargaListaFichero();
                } catch (Exception ex) {
                 System.out.println("La lista de clientes no se pudo cargar " +
                         "desde el fichero");
                }
            // obedecer a la opción seleccionada por el usuario
            switch (opcion_Menu()) {
                case OPCION_AGREGAR_CLIENTE:
                    AgregarCliente();
                    break;

                case OPCION_LISTAR_CLIENTES:
                    System.out.println(listaClientes.toString());
                    break;

                case OPCION_BUSCAR_CLIENTE:
                    BuscarCliente();
                    break;

                case OPCION_BORRAR_CLIENTE:
                    BorrarCliente();
                    break;

                case OPCION_BORRAR_FICHERO:
                    BorrarFichero();
                    break;


                case OPCION_SALIR:
                    // No es necesario realizar nada antes de salir, pues los
                    // datos se guardan tras cada operación que los modifica
                    bSalir = true;
                    break;
            }
            // permanecer en el menú hasta que se seleccione salir
        } while (!bSalir);
    }



    /**
     * Funcion que solicita por pantalla un menu y solicita la introducción de
     * de la opción seleccionada
     *
     * @return  caracter correspondiente a la opción seleccionada
     */
    private static char opcion_Menu() {
        String opcionSeleccionada = "";
        boolean valorValido = false;

        // Mostramos el menu
        System.out.println("\n\nMenú Aplicación Tarea 6");
        System.out.println("-------------------------------\n");
        System.out.println("\t1.- Añadir cliente - Pide los datos del cliente y"
                + " añade el registro correspondiente en el fichero");
        System.out.println("\t2.- Listar clientes. Recorre el fichero mostrando "
                + "los clientes almacenados en el mismo.");
        System.out.println("\t3.- Buscar clientes. Pide el nif del cliente a "
                + "buscar, y comprueba si existe en el fichero.");
        System.out.println("\t4.- Borrar cliente. Pide el nif del cliente a "
                + "borrar, y si existe, lo borra del fichero.");
        System.out.println("\t5.- Borrar fichero de clientes completamente. "
                + "Elimina del disco el fichero clientes.dat");
        System.out.println("\t6.- Salir.");
        // Leemos el teclado hasta obtener una opción válida
        do {
            opcionSeleccionada = Entrada.leerString("\tSeleccione una opción: ", "\tOpción no válida");
            // Si la opcion seleccionada está en el rango establecido, marcar como válida
            if (opcionSeleccionada.compareTo("0") >= 0 && opcionSeleccionada.compareTo("6") <= 0) {
                valorValido = true;
            } else {
                System.out.println("\tOpción no válida");
            }

        } while (!valorValido);
        // Una vez leida una opción válida la retornamos
        return opcionSeleccionada.charAt(0);
    }

    /**
     * Solicita la entrada de los datos de un cliente por teclado y lo agrega
     * en caso de no existir previamente ese cliente. En caso de existir
     * previamente ese cliente, solicita confirmación al usuario para
     * sobreescribirlo
     */
    private static void AgregarCliente() {
        cliente = new Cliente();
        cliente.EntrarCliente();
        // Ver si el cliente existe antes de agregarlo
        if (listaClientes.getCliente(cliente.getNIF()) != null) {
            // Si ya existe, pedimos confirmación para sobrescribirlo
            System.out.println("Ya existe el cliente: " + listaClientes.getCliente(cliente.getNIF()));
            do {
                confirmación = Entrada.leerString("¿Está seguro de sobreescribir el cliente (s/n)?",
                        "Pulse s para confirmar, n para cancelar");
            } while (!confirmación.equalsIgnoreCase("s")
                    && !confirmación.equalsIgnoreCase("n"));
            // Si se confirma el borrado
            if (confirmación.equalsIgnoreCase("n"))
                return;
        }

        // En caso de confirmación o de no existir previamente, lo agregamos
        try {
            listaClientes.AgregaCliente(cliente);
        } catch (Exception ex) {
            System.out.println("Se ha intentado agregar un valor nulo"
                    + "en la lista de clientes");
        }
        // una vez leido el cliente y agregado a la lista de clientes
        // guardamos la lista en el fichero de datos
        try {
            listaClientes.guardarEnFichero();
        } catch (Exception ex) {
            System.out.println("Se ha producido el error "
                    + ex.getMessage() + "al guardar la lista en el fichero");
        }
    }


    /**
     * Solicita la entrada del NIF de un cliente por teclado y
     * en caso de existir ese cliente, solicita confirmación al usuario para
     * borrarlo. En caso de no existir el cliente, se informa al usuario
     * de su no existencia.
     */
    private static void BorrarCliente() {
        NIF = Entrada.leerString("\nNIF: ",
                "El valor introducido no es válido.");
        // Eliminamos los espacios y pasamos todo a mayúsculas antes
        // de buscar, ya que así es como los hemos guardado en la
        // lista de clientes
        NIF = NIF.trim().toUpperCase();
        cliente = listaClientes.getCliente(NIF);
        // Si el cliente no se encuentra, lo comunicamos
        if (cliente == null) {
            System.out.println("El cliente con NIF: " + NIF
                    + " no se ha encontrado.");
            // y en caso de encontrarlo lo pedimos confirmación de borrado
            // ya que la acción no tiene paso a tras
        } else {
            // primero mostramos el cliente
            System.out.println("El cliente" + cliente.toString()
                    + "\nha sido encontrado");
            // y pedimos confirmación de borrado
            do {
                confirmación = Entrada.leerString("¿Está seguro de borrar el cliente (s/n)?",
                        "Pulse s para confirmar, n para cancelar");
            } while (!confirmación.equalsIgnoreCase("s")
                    && !confirmación.equalsIgnoreCase("n"));
            // Si se confirma el borrado
            if (confirmación.equalsIgnoreCase("s")) {
                // procedemos al borrado, lo mostramos
                System.out.println("El cliente"
                        + listaClientes.BorraCliente(NIF)
                        + "\nha sido borrado");
                // y guardamos los cambios en el fichero
                try {
                    listaClientes.guardarEnFichero();
                } catch (Exception ex) {
                    System.out.println("Se ha producido un error al borrar cliente");
                }
            } // fin confirmación de borrado
        } // fin else (el cliente existe)
    } // fin BorrarCliente



    /**
     * Muestra un mensaje de confirmación de borrado del fichero de datos,
     * procediendo al borrado del mismo en caso afirmativo.
     */
    private static void BorrarFichero() {
        // Antes de borrar pedimos confirmación de borrado
        do {
            confirmación = Entrada.leerString("¿Está seguro de borrar fichero (s/n)?",
                    "Pulse s para confirmar, n para cancelar");
        } while (!confirmación.equalsIgnoreCase("s")
                && !confirmación.equalsIgnoreCase("n"));
        // Si finalmente el usuario confirma que desea borrar el fichero
        if (confirmación.equalsIgnoreCase("s")) {
            // Mostramos el resultado de la operación de borrado
            File ficheroDatos = new File(listaClientes.getFICHERO_DATOS());
            if (ficheroDatos.delete()) {
                //listaClientes.BorraClientes();
                System.out.println("El fichero ha sido borrado satisfactoriamente");
            } else {
                System.out.println("El fichero no puede ser borrado");
            }
        } // fin si se confirma el borrado
    } // fin BorrarFichero()


    /**
     * Solicita la entrada del NIF de un cliente por teclado y
     * en caso de existir ese cliente, lo muestra.
     * En caso de no existir el cliente, se informa al usuario
     * de su no existencia.
     */
    private static void BuscarCliente() {
        NIF = Entrada.leerString("\nNIF: ",
                "El valor introducido no es válido.");
        // Eliminamos los espacios y pasamos todo a mayúsculas antes
        // de buscar, ya que así es como los hemos guardado en la
        // lista de clientes
        NIF = NIF.trim().toUpperCase();
        cliente = listaClientes.getCliente(NIF);
        // Si el cliente no se encuentra, lo comunicamos
        if (cliente == null) {
            System.out.println("El cliente con NIF: " + NIF
                    + " no se ha encontrado.");
            // y en caso de encontrarlo lo mostramos
        } else {
            System.out.println(cliente.toString());
        }
    }
}
