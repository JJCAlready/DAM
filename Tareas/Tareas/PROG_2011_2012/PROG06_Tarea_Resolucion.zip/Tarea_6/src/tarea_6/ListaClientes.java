
package tarea_6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Implementa una lista mapeada (clave, valor) y serializable de clientes, para 
 * poder ser guardada en un fichero de bytes.
 *
 * @author Fernando
 * @version 1.0
 */
public class ListaClientes implements Serializable {
    private HashMap lista;
    private String FICHERO_DATOS;

    /**
     * Constructor de la clase. Inicializa la lista de clientes y asigna los
     * valores adecuados a los nombres de archivo que se utilizan para guardar
     * en disco.
     * 
     */
    public ListaClientes() {
        lista = new HashMap();
        // El fichero de datos debe estar en el mismo directorio que la aplicación
        // para ello construimos el nombre en función del directorio del usuario
        // y el separador del sistema
        FICHERO_DATOS = System.getProperty("user.dir")
                + System.getProperty("file.separator") + "clientes.dat";
    }

    /**
     *
     * @return String que representa el nombre y la ruta del fichero de datos.
     */
    public String getFICHERO_DATOS() {
        return FICHERO_DATOS;
    }

    /**
     *
     * @return HashMap en el que se guarda la lista de clientes.
     */
    public HashMap getListaClientes() {
        return lista;
    }

    /**
     * Dado un NIF devuelve el cliente con ese NIF en caso de existir,
     * en caso contrario devuelve null
     * @param NIF String con el NIF a buscar
     * @return Cliente con el NIF pasado como parámetro, o null si no existe
     * ningún cliente con ese NIF
     */
    public Cliente getCliente(String NIF) {
        return (Cliente)lista.get(NIF);
    }

    /**
     *  Guarda la lista de clientes en disco
     * @throws Exception
     */
    public void guardarEnFichero() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHERO_DATOS));
            // escribimos este objeto
            oos.writeObject(this);
            // Cerramos el fichero
            oos.close();

        } catch (Exception ex) {
            System.out.println("Se ha producido un error al guardar los datos"
                    + " en el fichero");
        }
    }

    /**
     * Lee el fichero de datos existente en disco y carga sus datos en la lista
     * de clientes
     * @throws Exception
     */
    public void cargaListaFichero() throws Exception {
        ObjectInputStream ois = null;
        lista = new HashMap();
        File f = new File(FICHERO_DATOS);
        if (f.createNewFile()) {
            System.out.println("Se ha creado el fichero de datos: " + FICHERO_DATOS);
            guardarEnFichero();
        }
        try {
            // Abrimos el fichero para leerlo
            ois = new ObjectInputStream(new FileInputStream(f));
            // Leemos el objeto desde el fichero y recuperamos la lista de clientes
            // Los nombres de los ficheros no nos interesan, ya que los que realmente
            // nos sirven son los actuales
            ListaClientes listaAux = (ListaClientes)ois.readObject();
            lista = listaAux.getListaClientes();
        } finally {
          // cerramos el fichero, tanto si hubo excepción como si no
            ois.close();
        }
    }


    /**
     * Agrega un cliente a la lista de clientes.
     * @throws Exception ExcepcionClienteInexistente
     * @param cliente cliente para agregar a la lista
     * @return Devuelve el objeto cliente que existia previamente en la lista con
     *  ese NIF , o Null si no existia ninguno o el cliente pasado es null.
     */
    public Cliente AgregaCliente(Cliente cliente) throws Exception {
        if (cliente != null)
            return (Cliente)lista.put(cliente.getNIF(), cliente);
        else
            throw new Exception("ExcepcionClienteInexistente");
    }
    

    /**
     * Borra un cliente de la lista de clientes
     * @param NIF NIF del cliente a borrar de la lista
     * @return el objeto cliente que existia previamente en la lista con
     * ese NIF. Null si no existia ninguno
     */
    public Cliente BorraCliente(String NIF) {
        // Devuelve 
        return (Cliente)lista.remove(NIF);
    }


    /**
     * Borra todos los clientes de la lista de clientes.
     */
    public void BorraClientes() {
      Collection coleccion = lista.values();
        Iterator it = coleccion.iterator();
    	while(it.hasNext()) {
            it.next();
            it.remove();
        }
        
    }

    /**
     * Crea un String que contiene el listado de todos los clientes de la lista
     * @return String con los clientes de la lista
     */
    @Override
    public String toString() {
        String strListaClientes = "\n---------------------- Lista de clientes -"
                + "-------------------------";
        Collection coleccion = lista.values();
        Iterator it = coleccion.iterator();
    	while(it.hasNext())
    		strListaClientes += ((Cliente)it.next()).toString();
        strListaClientes += "\n-------------------- Fin lista de clientes -"
                + "-----------------------";
        return strListaClientes;
    }
}


 