
package Utilidades;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Clase para facilitar la lectura de un tipos de datos, capturando las 
 * excepciones en caso de leer un dato inexperado y reiterando la lectura del
 * dato solicitado hasta que se introducca un valor correcto del tipo solicitado. 
 * No posee atributos, tan solo métodos.
 * 
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 */
public class Entrada {
    /**
     * Facilita la lectura de un tipo String.
     * @param textoMostrar texto previo que se mostrará al solicitar el dato
     * @param textoError texto que se mostrará si el valor leido es erroneo
     * @return String leido
     */
    public static String leerString(String textoMostrar, String textoError) {
       String valorLeido ="";
       Scanner teclado = new Scanner( System.in );
       do { 
           try { // Tratamos de leer un String y lo guardamos 
               System.out.println(textoMostrar);
               valorLeido = teclado.nextLine();
           }
           catch (InputMismatchException e){ // Si no se introduce un string
              System.out.println(textoError); // mostramos el texto de error
              teclado.nextLine();
           }
         // repetimos hasta leer un string no nulo  
       } while (valorLeido.length()==0);
     // retornamos el string leido  
     return valorLeido;  
   }
  
    
   /**
     * Facilita la lectura de un tipo Double.
     * @param textoMostrar texto previo que se mostrará al solicitar el dato
     * @param textoError texto que se mostrará si el valor leido es erroneo
     * @return Double leido
     */ 
   public static Double leerDouble(String textoMostrar, String textoError) {
       double valorLeido =0;
       boolean valorValido = false;
       Scanner teclado = new Scanner( System.in );
       do { 
           try { // Tratamos de leer un Double y lo guardamos 
               System.out.println(textoMostrar);
               valorLeido = teclado.nextDouble();
               valorValido = true;
           }
           catch (InputMismatchException e){ // Si no se introduce un Double
              System.out.println(textoError); 
              // consumir caracter "\n"
              teclado.nextLine();
              valorValido = false;
           }
         // repetimos hasta leer un Double  
       } while (!valorValido);
     // retornamos el valor leido  
       return valorLeido;  
   }
   
   
   /**
     * Facilita la lectura de un tipo Int.
     * @param textoMostrar texto previo que se mostrará al solicitar el dato
     * @param textoError texto que se mostrará si el valor leido es erroneo
     * @return Double leido
     */ 
   public static int leerInt(String textoMostrar, String textoError) {
       int valorLeido =0;
       boolean valorValido = true;
       Scanner teclado = new Scanner( System.in );
       do { 
           try { // Tratamos de leer un int y lo guardamos 
               System.out.println(textoMostrar);
               valorLeido = teclado.nextInt();
               valorValido = true;
           }
           catch (InputMismatchException e){ // Si no se introduce un int
              System.out.println(textoError); // mostramos mensaje de error
              teclado.nextLine();
              valorValido = false;
           }
         // repetimos hasta leer un int  
       } while (!valorValido);
     // retornamos el valor leido  
       return valorLeido;  
   }
    
}
