/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio_2;

import Utilidades.Entrada;

/**
 * Programa que imita a una calculadora capaz de realizar las operaciones 
 * básicas (suma, resta, producto y multiplicación) y dos operaciones complejas
 * como la potencia y la raíz cuadrada. La aplicación muestra inicialmente un 
 * menú con las opciones: 1. Operaciones básicas, 2. Operaciones complejas, 3.
 * Salir. Si se selecciona la opción 1. muestra un nuevo menú con las opciones:
 * a. suma, b. resta, c. multiplicación, d. división. En el caso de seleccionar 
 * en el primer menú la opción 2. mostrará un nuevo menú con las opciones: a.
 * Potencia, b. Raiz cuadrada.
 * 
 * Una vez elegida la opción correspondiente el programa solicita los datos 
 * necesarios y muestra por pantalla el resultado obtenido en cada caso. 
 * El programa controla los posibles errores que se puedan producir a la hora de
 * elegir la opción y de introducir los datos por teclado de tal forma que si 
 * los datos introducidos son erróneos los vuelve a solicitar. 
 * 
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 * 
 */
public class Ejercicio_2 {
 
    /**
     * @param argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        boolean bSalir = false; 
        // presentar y leer menu del primer nivel 
        // mientras no se seleccione la opcion salir
        do {
            switch(opcion_Menu_1()) {
                case '1':
                    // presentar y leer primer menu del segundo nivel
                    switch(opcion_Menu_2_1()) {
                        case 'a':
                            suma();
                            break;
                            
                       case 'b':
                            resta();
                            break;
                           
                       case 'c':
                            multiplicacion();
                            break;
                           
                       case 'd':
                            division();
                            break;
                    }
                    break;
                case '2':
                    // presentar y leer segundo menu del segundo nivel
                    switch(opcion_Menu_2_2()) {
                        case 'a':
                            potencia();
                            break;
                             
                       case 'b':
                            raizCuadrada();
                            break;
                    }
                    break;
                    
                case '3':
                    bSalir=true;
                    break;
                        
            
            }
          // permanecer en el primer menú hasta que se seleccione salir 
        } while (!bSalir);
       
    }
    
  
   
   /**
     * Solicita dos valores reales y calcula la suma de los mismos, mostrando
     * el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void suma(){
        Entrada entrada = new Entrada();
        double valor1, valor2;
        valor1 = entrada.leerDouble("Introduzca primer sumando", 
                "El valor introducido no es válido");
        valor2 = entrada.leerDouble("Introduzca segundo sumando", 
                "El valor introducido no es válido");
        System.out.println(valor1 + " + " + valor2 + " = " + (valor1+valor2));
    }
    
    /**
     * Solicita dos valores reales y calcula la resta de los mismos, mostrando
     * el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void resta(){
        Entrada entrada = new Entrada();
        double valor1, valor2;
        valor1 = entrada.leerDouble("Introduzca minuendo", 
                "El valor introducido no es válido");
        valor2 = entrada.leerDouble("Introduzca sustraendo", 
                "El valor introducido no es válido");
        System.out.println(valor1 + " - " + valor2 + " = " + (valor1-valor2));
    }
    
    /**
     * Solicita dos valores reales y calcula la multiplicación de los mismos,
     * mostrando el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void multiplicacion(){
        Entrada entrada = new Entrada();
        double valor1, valor2;
        valor1 = entrada.leerDouble("Introduzca multiplicando", 
                "El valor introducido no es válido");
        valor2 = entrada.leerDouble("Introduzca multiplicador", 
                "El valor introducido no es válido");
        System.out.println(valor1 + " * " + valor2 + " = " + (valor1*valor2));
    }
    
    
    /**
     * Solicita dos valores reales y calcula la división del primero entre el 
     * segundo, mostrando el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void division(){
        Entrada entrada = new Entrada();
        double valor1, valor2;
        String strResultado ="";
        valor1 = entrada.leerDouble("Introduzca dividendo", 
                "El valor introducido no es válido");
        valor2 = entrada.leerDouble("Introduzca divisor", 
                "El valor introducido no es válido");
        // En casos especiales, castellanizamos los mensajes del resultado
        if (valor2 == 0) {
            if (valor1 ==0) // los dos valores son 0 (0/0)
                strResultado = "Indeterminado";
            else  // solo el denominador es 0
                strResultado = "Infinito";
            System.out.println(valor1 + " / " + valor2 + " = " + strResultado);
        }
        else { // si ninguno de los valores es 0 mostrar el resultado de la division    
            System.out.println(valor1 + " / " + valor2 + " = " + (valor1/valor2));
        }     
    }
    
    
    /**
     * Solicita dos valores reales y calcula el valor del primero elevado a la 
     * potencia del segungo, mostrando el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void potencia(){
        Entrada entrada = new Entrada();
        double valor1, valor2;
        valor1 = entrada.leerDouble("Introduzca base", 
                "El valor introducido no es válido");
        valor2 = entrada.leerDouble("Introduzca exponente", 
                "El valor introducido no es válido");
        System.out.println(valor1 + " ^ " + valor2 + " = " + (Math.pow(valor1, valor2)));
    }
    
    
    /**
     * Solicita un valor real y calcula la raiz cuadrada del mismo, mostrando
     * el valor calculado por pantalla. 
     * Esta función se implementa con el objeto de simplificar la realización
     * final del programa principal y facilitar la comprensión del código
     */
    private static void raizCuadrada(){
        Entrada entrada = new Entrada();
        double valor1;
        valor1 = entrada.leerDouble("Introduzca valor", 
                "El valor introducido no es válido");
        System.out.println("√" + valor1 + " = " + (Math.sqrt(valor1)));
    }
    
    
   /**
     * Funcion que solicita por pantalla un menu y solicita la introducción de 
     * de la opción seleccionada
     *
     * @return  caracter correspondiente a la opción seleccionada
     */  
   private static char opcion_Menu_1() {
       String opcionSeleccionada = "";
       boolean valorValido = false;
       Entrada entrada = new Entrada();
       
       // Mostramos el menu
       System.out.println("Emulador calculadora");
       System.out.println("--------------------\n");
       System.out.println("\t1.- Operaciones básicas.");
       System.out.println("\t2.- Operaciones complejas.");
       System.out.println("\t3.- Salir.\n");
 
       // Leemos el teclado hasta obtener una opción válida
       do {
           opcionSeleccionada = entrada.leerString("\tSeleccione una opción: ", "\tOpción no válida");
           // Si la opcion seleccionada está en el rango establecido, marcar como válida
           if (opcionSeleccionada.compareTo("0") > 0 && opcionSeleccionada.compareTo("4") < 0)
               valorValido = true;   
           else 
               System.out.println("\tOpción no válida"); 

      } while (!valorValido);
      // Una vez leido un opción válida la retornamos 
      return opcionSeleccionada.charAt(0);
   }
   
   
   /**
     * Funcion que solicita por pantalla un submenu y solicita la introducción 
     * de la opción seleccionada
     *
     * @return  caracter correspondiente a la opción seleccionada
     */ 
   private static char opcion_Menu_2_1() {
       String opcionSeleccionada = "";
       boolean valorValido = false;
       Entrada entrada = new Entrada();
       System.out.println("\tOperaciones básicas");
       System.out.println("\t-------------------\n");
       System.out.println("\t\ta.- Suma.");
       System.out.println("\t\tb.- Resta.");
       System.out.println("\t\tc.- Multiplicación.");
       System.out.println("\t\td.- División.\n");
       
       // Leemos el teclado hasta obtener una opción válida
       do {
        opcionSeleccionada = entrada.leerString("\t\tSeleccione una opción: ", "\t\tOpción no válida");
        if (opcionSeleccionada.compareTo("a") >= 0 && opcionSeleccionada.compareTo("d") <= 0)
            valorValido = true;   
        else 
           System.out.println("\t\tOpción no válida"); 
        
      } while (!valorValido);
      // Una vez leido un opción válida la retornamos 
      return opcionSeleccionada.charAt(0);
   }
   
   
   /**
     * Funcion que solicita por pantalla un submenu y solicita la introducción 
     * de la opción seleccionada
     *
     * @return  caracter correspondiente a la opción seleccionada
     */ 
   private static char opcion_Menu_2_2() {
       String opcionSeleccionada = "";
       boolean valorValido = false;
       Entrada entrada = new Entrada();
       // presentamos las opciones de menú
       System.out.println("\tOperaciones complejas");
       System.out.println("\t---------------------\n");
       System.out.println("\t\ta.- Potencia.");
       System.out.println("\t\tb.- Raiz cuadrada.");
      
       // Leemos el teclado hasta obtener una opción válida
       do {
        opcionSeleccionada = entrada.leerString("\t\tSeleccione una opción: ", "\t\tOpción no válida");
        if (opcionSeleccionada.compareTo("b") == 0 || opcionSeleccionada.compareTo("a") == 0)
            valorValido = true;   
        else 
           System.out.println("\t\tOpción no válida"); 
        
      } while (!valorValido);
      // Una vez leido un opción válida la retornamos 
      return opcionSeleccionada.charAt(0);
   }
}
