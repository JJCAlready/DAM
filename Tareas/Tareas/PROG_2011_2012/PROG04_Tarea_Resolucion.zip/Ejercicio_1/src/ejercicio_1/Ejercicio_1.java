
package ejercicio_1;

import Utilidades.Entrada;

/**
 * Programa que lee una secuencia de notas que se van introduciendo por el 
 * teclado (las notas son valores numéricos que pueden contener decimales). 
 * La secuencia de notas finaliza cuando se introduce un valor negativo. El 
 * programa informa al final del número de aprobados, el número de suspensos
 * y la nota media. El programa controla los posibles errores que se puedan 
 * producir a la hora de introducir las notas por teclado de tal forma que si 
 * alguna nota introducida es errónea la vuelva a solicitar. 
 * Se tendra en cuenta que un supendo es una nota mayor que 0 y menor que 5,
 * un aprobado es una nota entre 5 y 10, y cualquier valor mayor que 10 es una
 * nota no válida.
 * 
 * @author Fernando Arnedo Ayensa
 * @version 1.0
 */
public class Ejercicio_1 {

    /**
     * @param argumentos de la linea de comandos
     */
    public static void main(String[] args) {
         // Declaración de variables
         int nAprobados = 0, nSuspensos = 0, nNotas = 0; 
         double notaActual = 0, totalNotas = 0, notaMedia = 0;
         Entrada entrada = new Entrada();
         do {// leeremos notas como valores Doubles
             notaActual = entrada.leerDouble("Introduzca una nota, o un valor "
                     + "negativo para terminar: ", "La nota introducida no es válida");
             // Verificamos que es una nota válida
             if (notaActual >= 0 && notaActual <=10) {
                // Es una nota válida, incrementar contador de notas y sumatorio
                nNotas++;
                totalNotas += notaActual;
                if (notaActual >= 5) 
                    // Es un aprobado, incrementar contador de aprobados
                    nAprobados++;
                 else
                    // Es un suspenso, incrementar contador de suspensos
                    nSuspensos++;          
            } else if (notaActual >10){
                 System.out.println("La nota introducida no es válida");
            } 
           // seguir leyendo notas mientras no se introduzca un valor negativo  
         } while (notaActual >= 0);
         
 
        // Una vez leidas todas las notas, calcular media y presentar resultados
          if (nNotas > 0) {
            notaMedia = totalNotas/(double)nNotas;
          }
          System.out.printf("\nNúmero total de notas introducidas: %d", nNotas); 
          System.out.printf("\nNúmero total de aprobados: %d", nAprobados); 
          System.out.printf("\nNúmero total de suspensos: %d", nSuspensos); 
          System.out.printf("\nNota media: %.2f",  notaMedia); 
    } // fin función main()
        
} // fin de la clase
