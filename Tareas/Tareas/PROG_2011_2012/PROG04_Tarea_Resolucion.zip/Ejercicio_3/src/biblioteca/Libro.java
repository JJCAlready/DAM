package biblioteca;

/**
 * Clase para el desarrollo del ejercicio 3 de la tarea 4 del módulo de Programación
 * Ciclo Superior de Desarrollo de Aplicaciones Multiplataforma
 * 
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 * @version 1.0
 */
public class Libro {
    private String titulo; // el título del libro.
    private String autor;  // el autor del libro.
    private String isbn;   // el código ISBN del libro.
    
    
    /**
     * Constructor de la clase que inicializa los atributos del objeto con los 
     * datos pasados por parámetro. Se comprueba que el ISBN pasado por parámetro
     * es válido, y en caso contrario se lanza la excepción IllegalArgumentException
     * 
     * @param titulo título del libro
     * @param autor autor del libro
     * @param isbn ISBN del libro
     * @throws IllegalArgumentException 
     */
    public Libro(String titulo, String autor, String isbn) throws IllegalArgumentException {
        // si el isbn es correcto asignamos valores a los atributos
        if (isbnValido(isbn)) {
            this.titulo = titulo;
            this.autor = autor;
            this.isbn = isbn;
        } 
        // en caso contrario lanzamos excepción
        else {
            throw new IllegalArgumentException("isbn no válido");
        }
        
    }

    /*********************************************
     *                                           *
     * Consultores y Modificadores de atributos. *
     *                                           * 
     *********************************************/
    
    /**
     * 
     * @param autor valor para asignar al atributo autor de la clase
     */
    public void cambia_Autor(String autor) {
        this.autor = autor;
    }
    
    /**
     * 
     * @param isbn valor para asignar al atributo isbn de la clase
     * @throws IllegalArgumentException 
     */
     
    public void cambia_Isbn(String isbn) throws IllegalArgumentException {
        // si el isbn es correcto asignamos valor al atributo
        if (isbnValido(isbn)) 
            this.isbn = isbn;
        // en caso contraio, lanzamos excepción
        else 
            throw new IllegalArgumentException("isbn no válido");
    }

    /**
     * 
     * @param titulo valor para asignar al atributo titulo de la clase
     */
    public void cambia_Titulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * 
     * @return valor del atributo autor de la clase
     */
    public String consulta_Autor() {
        return autor;
    }

    /**
     * 
     * @return valor del atributo isbn de la clase
     */
    public String consulta_Isbn() {
        return isbn;
    }

    /**
     * 
     * @return valor del atributo titulo de la clase
     */
    public String consulta_Titulo() {
        return titulo;
    }
    
    /**
     * Función que comprueba si el ISBN pasado como parámetro es un ISBN10
     * válido.
     * Multiplicamod cada dígito (si el último carácter fuera una X, su valor es
     * 10) por la posición que ocupa y calculamos la suma de todos ellos. Si la
     * suma obtenida es múltiplo de 11, el isbn es válido. En caso contrario es
     * no válido.
     * 
     * @param isbn
     * @return true si el isbn pasado como parámetro es un ISBN10 válido
     */
    private boolean compruebaIsbn10(String isbn) {
        int suma = 0;
        // de entrada asumimos que el isbn es válido
        boolean bValido = true;
        // comprobamos cada uno de los dígitos
        for (int i = 1; i <= 10; i++) {
            // obtenemos el dígito en función del caracter ASCII
            // el char '1' corresponde con el decimal 49
            // y el '9' corresponde con el decimal 57
            int digito = isbn.charAt(i-1)-48;
            // Si el digito es un numero
            if ( digito > 0 && digito < 10 )
               suma += i*digito; 
            // Si el digito es una x o X y es el último dígito
            else if ((digito==40 || digito==72) && i==10)
                // el peso del digito es 10
                suma += i*10; 
           // llegando a este paso, el dígito no es válido y por ende el isbn
            else {
                bValido =false;
                // salimos del bucle porque no vale la pena continuar
                break;
            }
        }
        // si todos los dígitos han sido válidos, comprobamos la suma
        if (bValido) {
            // si el resto de la división entre 11 no es cero el isbn no es válido
            if ((suma % 11) != 0) 
                bValido = false;
        }
        // retornamos el valor obtenido
        return bValido;
    }
    
    
    /**
     * Función que comprueba si el ISBN pasado como parámetro es un ISBN13
     * válido.
     * Multiplicamos cada número por 1 si la posición que ocupa es impar o por 3
     * si la posición que ocupa es par y calculamos la suma de todos salvo del 
     * último que es el dígito de control. Dividimos el resultado de la suma 
     * anterior entre 10 y obtenemos el resto de la división. Restamos a 10 el 
     * resto obtenido. El isbn será válido si el valor obtenido es igual al 
     * dígito de control (último dígito del isbn). 
     * 
     * @param isbn
     * @return true si el isbn pasado como parámetro es un ISBN10 válido
     */
    private boolean compruebaIsbn13(String isbn) {
        int suma = 0;
        // de entrada asumimos que el isbn es válido
        boolean bValido = true;
        // comprobamos cada uno de los dígitos
        for (int i = 1; i <12; i+=2) {
            // obtenemos el dígito en función del caracter ASCII
            // el char '1' corresponde con el decimal 49
            // y el '9' corresponde con el decimal 57
            int digito1 = isbn.charAt(i-1)-48;
            int digito2 = isbn.charAt(i)-48;
            // Si los dos digitos son numeros
            if ( digito1 > 0 && digito1 < 10 && digito2 > 0 && digito2 <10) 
               suma += (digito1 + 3*digito2); 
            // Si algún dígito no es un número no es válido y por ende el isbn
            else {
                bValido =false;
                // salimos del bucle porque no vale la pena continuar
                break;
            }
        }
        // si todos los dígitos han sido válidos, comprobamos la suma
        if (bValido) {
            // si 10 menos el resto de la división entre 10 
            // no es igual al último dígito
            if ((10-(suma % 10)) != (isbn.charAt(12)-48))
                // El isbn no será válido
                bValido = false;
        }
        // retornamos el valor obtenido
        return bValido;
    }

    
    /**
     * Función que comprueba si el string pasado como parámetro es un ISBN10
     * o un ISBN13 válido.
     * 
     * @param isbn
     * @return true si el isbn pasado como parámetro es un ISBN válido
     */
    private boolean isbnValido(String isbn) {
        boolean bValido;
        // comprobar validez del isbn en función de su longitud
        // (eliminamos previamente los posibles espacios en blanco 
        //  por delante y por detras)
        switch (isbn.trim().length()) {
            case 10:
                bValido = compruebaIsbn10(isbn);
                break;
            case 13:
                bValido = compruebaIsbn13(isbn);
                break;
            default:
                bValido = false;
                break;
        }
        return bValido;
    }
    
}
