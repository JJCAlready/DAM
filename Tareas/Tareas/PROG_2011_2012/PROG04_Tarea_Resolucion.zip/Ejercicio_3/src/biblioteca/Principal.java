package biblioteca;

import java.util.Scanner;

/**
 * Prueba todos los métodos de la clase Libro
 * 
 * @author Fernando Arnedo Ayensa - Desarrollo de Aplicaciones Multiplataforma
 * @version 1.0
 * 
 */
public class Principal {

    /**
     * @param argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        String titulo, autor, isbn;
        boolean bValido;
        Libro libro = null;
        Scanner teclado = new Scanner( System.in );
         
        //`pedimos la entrada por teclado de los atributos titulo y autor
        System.out.println("Introduzca el título del libro: ");
        titulo = teclado.nextLine();
        System.out.println("Introduzca el autor del libro: ");
        autor = teclado.nextLine();
        // pedimos la entrada por teclado del atributo isbn mientras no se
        // se introduzca un valor válido para el mismo
        do {
            try {  
                System.out.println("Introduzca los digitos (sin guiones) del "
                        + "isbn del libro: ");
                isbn = teclado.nextLine();
                libro = new Libro(titulo, autor, isbn);
                bValido = true;
            }
            catch (IllegalArgumentException e){
                System.out.println("El isbn introducido no es válido");
                bValido = false;
            }
        } while (!bValido);
        
        // una vez introducidos los valores correctos y creado correctamente
        // el libro, mostramos los atributos del mismo.
        System.out.println("Título: " + libro.consulta_Titulo());
        System.out.println("Autor: " + libro.consulta_Autor());
        System.out.println("ISBN: " + libro.consulta_Isbn());
        
        // solicitamos nuevos valores, modificamos los atributos del libro
        // y mostramos los nuevos valores
        System.out.println("Introduzca nuevo título del libro: ");
        titulo = teclado.nextLine();
        libro.cambia_Titulo(titulo);
        System.out.println("Nuevo valor del Título: " + libro.consulta_Titulo());
        
        System.out.println("Introduzca nuevo autor del libro: ");
        autor = teclado.nextLine();
        libro.cambia_Autor(autor);
        System.out.println("Nuevo valor del Autor: " + libro.consulta_Autor());
        
        bValido = false;
        do {
            try {
                System.out.println("Introduzca los digitos (sin guiones) del "
                        + "nuevo ISBN del libro: ");
                isbn = teclado.nextLine();
                libro.cambia_Isbn(isbn);
                bValido = true;
            }
            catch (IllegalArgumentException e) {
                System.out.println("El isbn introducido no es válido");
                bValido = false;
            } 
        } while (!bValido);
        
        System.out.println("Nuevo valor del ISBN: " + libro.consulta_Isbn());
    }     
        
        
       
}
