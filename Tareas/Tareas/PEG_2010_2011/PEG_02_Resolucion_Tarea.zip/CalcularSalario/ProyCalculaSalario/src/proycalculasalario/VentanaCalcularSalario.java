package proycalculasalario;

import java.awt.Color;
import java.awt.Dimension;

import java.awt.Font;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.KeyAdapter;

import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import jtextfieldirpf.JtextFieldIRPF;

public class VentanaCalcularSalario extends JFrame {
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JtextFieldIRPF jtextFieldIRPFRetencion = new JtextFieldIRPF();
    private JtextFieldIRPF jtextFieldIRPFSalarioBruto = new JtextFieldIRPF();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JButton jButtonCalcular = new JButton();
    private JTextField jTextFieldSalarioNeto = new JTextField();

    public VentanaCalcularSalario() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(412, 261));
        this.setTitle("C�lculo de salario");
        jLabel1.setText("Salario Bruto");
        jLabel1.setBounds(new Rectangle(60, 60, 70, 15));
        jLabel1.setToolTipText("null");
        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
        jLabel2.setText("Retenci�n IRPF");
        jLabel2.setBounds(new Rectangle(45, 105, 85, 15));
        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
        jtextFieldIRPFRetencion.setBounds(new Rectangle(155, 95, 100, 35));
        jtextFieldIRPFRetencion.setCaracteresPermitidos("0123456789");
        jtextFieldIRPFRetencion.setLongitud(2);
        jtextFieldIRPFSalarioBruto.setBounds(new Rectangle(155, 50, 155, 35));
        jtextFieldIRPFSalarioBruto.setLongitud(10);
        jtextFieldIRPFSalarioBruto.setCaracteresPermitidos("0123456789");
        jLabel3.setText("�");
        jLabel3.setBounds(new Rectangle(315, 50, 40, 30));
        jLabel3.setFont(new Font("Dialog", 1, 17));
        jLabel4.setText("�");
        jLabel4.setBounds(new Rectangle(320, 155, 40, 30));
        jLabel4.setFont(new Font("Dialog", 1, 17));
        jLabel5.setText("%");
        jLabel5.setBounds(new Rectangle(260, 95, 40, 30));
        jLabel5.setFont(new Font("Dialog", 1, 17));
        jButtonCalcular.setText("Calcular");
        jButtonCalcular.setBounds(new Rectangle(55, 155, 75, 40));
        jButtonCalcular.setActionCommand("null");
        jButtonCalcular.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButtonCalcular_actionPerformed(e);
                    }
                });
        jTextFieldSalarioNeto.setBounds(new Rectangle(155, 155, 160, 40));
        this.getContentPane().add(jTextFieldSalarioNeto, null);
        this.getContentPane().add(jButtonCalcular, null);
        this.getContentPane().add(jLabel5, null);
        this.getContentPane().add(jLabel4, null);
        this.getContentPane().add(jLabel3, null);
        this.getContentPane().add(jtextFieldIRPFSalarioBruto, null);
        this.getContentPane().add(jtextFieldIRPFRetencion, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jLabel1, null);
    }


    private void jButtonCalcular_actionPerformed(ActionEvent e) {
        // Utilizamos float para los salarios, as� los c�lculos ser�n m�s precisos
        float salarioNeto = -1, salarioBruto = -1;
        int retencion = -1;
        
        // Intentamos el c�lculo
        try {
            salarioBruto = Long.parseLong(jtextFieldIRPFSalarioBruto.getText());
            retencion = Integer.parseInt(jtextFieldIRPFRetencion.getText());
            // Calculamos el salario neto y lo redondeamos
            salarioNeto = Math.round(salarioBruto * (100 - retencion) / 100);
            // presentamos el resultado con cast a long para no mostrar decimales
            jTextFieldSalarioNeto.setText("El salario neto es: " + 
                                          (long)salarioNeto);
        // En caso de error, comprobamos las entradas de salario y retenci�n                                  
        } catch (NumberFormatException nfe) {
            // No se pudo obtener el salario bruto
            if (salarioBruto == -1)
                jTextFieldSalarioNeto.setText("Introduzca un salario");
            // Se pudo obtener el salario bruto, pero no la retenci�n    
            else if (retencion == -1) 
                jTextFieldSalarioNeto.setText("Introduzca una retenci�n");
            
         }
         
    }

}
