package jtextfieldirpf;

import java.awt.Toolkit;
import java.awt.event.KeyAdapter;

import java.awt.event.KeyEvent;

import javax.swing.JTextField;

public class JtextFieldIRPF extends JTextField {
    private int longitud;
    private String caracteresPermitidos;
    public JtextFieldIRPF() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setCaracteresPermitidos(String caracteresPermitidos) {
        this.caracteresPermitidos = caracteresPermitidos;
    }

    public String getCaracteresPermitidos() {
        return caracteresPermitidos;
    }

    private void jbInit() throws Exception {
        this.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        this_keyTyped(e);
                    }
                });
    }

    private void this_keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if ((caracteresPermitidos.indexOf(c) != -1) || (c == KeyEvent.VK_DELETE) || 
            (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_ENTER)) {
            if (longitud > 0 && getText().length() >= longitud) {
                Toolkit.getDefaultToolkit().beep();
                System.out.println("Sobrepasada longitud");
                e.consume();
            }
        } else {
            Toolkit.getDefaultToolkit().beep();
            e.consume();
        }

    }
}
