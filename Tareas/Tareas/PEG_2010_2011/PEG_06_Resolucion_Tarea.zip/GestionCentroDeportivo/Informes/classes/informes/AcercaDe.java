package informes;

import java.awt.Dimension;

import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class AcercaDe extends JDialog {
    private JLabel lbImagen = new JLabel();
    private ImageIcon icono = new ImageIcon(this.getClass().getResource("/recursos/imagenes/acerca.jpg"));

    public AcercaDe() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(635, 278));
        this.setResizable(false);
        this.setTitle( "Acerca de CentroDeportivo" );
        lbImagen.setBounds(new Rectangle(0, 0, 629, 254));
        this.getContentPane().add(lbImagen, null);
        lbImagen.setIcon(icono);
        Utilidades.centrar(this);
        this.setVisible(true);
    }
}
