package informes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;


/**
 * Dialogo que se muestra al inicio de la aplicaci�n y que sirve de presentaci�n
*/
public class DialogoInicio extends JDialog {
    private JLabel jL_Imagen = new JLabel();
    private JPanel jP_Inicio = new JPanel();
    private JProgressBar jPB_Carga = new JProgressBar();
    
    /**
     * Constructor de la clase sin par�metros, crea el objeto sin asignarle valores
     */
    public DialogoInicio() {
        this(null, "", false);
    }

    /**
     * Constructor de la clase con parametros
     * @param parent Frame : padre de este
     * @param title String : titulo de la ventana
     * @param modal boolean : �el dialogo ser� modal o no modal?
     */
    public DialogoInicio(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Metodo que configura y muestra el dialogo
    private void jbInit() throws Exception {        
        this.setSize(new Dimension(602, 293));
        this.setResizable(false);
        this.setUndecorated(true);
        this.setAlwaysOnTop(true);
        jP_Inicio.setLayout(new BorderLayout());
        jP_Inicio.setBorder(BorderFactory.createLineBorder(new Color(255, 133, 0)));
        jL_Imagen.setIcon(new ImageIcon(getClass().getResource("/recursos/imagenes/imgSplash.jpg")));
        jL_Imagen.setIconTextGap(0);
        jP_Inicio.add(jL_Imagen, BorderLayout.CENTER);
        jPB_Carga.setMinimumSize(new Dimension(10, 28));
        jPB_Carga.setPreferredSize(new Dimension(148, 20));
        jPB_Carga.setString("Cargando...");
        jPB_Carga.setStringPainted(true);
        jPB_Carga.setForeground(new Color(255, 133, 0));
        jPB_Carga.setBackground(new Color(236, 165, 19));
        jPB_Carga.setOpaque(true);
        jP_Inicio.add(jPB_Carga, BorderLayout.SOUTH);
        getContentPane().add(jP_Inicio, BorderLayout.NORTH);

        Utilidades.centrar(this);
        this.setVisible(true);
    }

    /**M�todo que actualiza el estado de la barra de progreso y la etiqueta de 
     * �sta. Uilizamos el m�todo invokeLater para hacer que dicha actualizaci�n
     * se ejecute desde el EDT (Event Dispatch Thread) para que sea seguro
     * con respecto a las hebras.
     * @param estado int
     * @param etiqueta String
     */
    public void actualizaEstado(int estado, String etiqueta)
    {
        try {
            final int fEstado = estado;
            final String fEtiqueta = etiqueta;
            final Runnable trabajo = new Runnable() {
                    public void run() {
                        jPB_Carga.setValue(fEstado);
                        if (fEtiqueta != null)
                            jPB_Carga.setString(fEtiqueta);
                    }
            };
            SwingUtilities.invokeLater(trabajo);
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
