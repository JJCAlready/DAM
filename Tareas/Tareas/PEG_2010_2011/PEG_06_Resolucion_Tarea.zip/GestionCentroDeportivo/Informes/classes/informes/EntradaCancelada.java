package informes;


public class EntradaCancelada extends Exception { 
    public EntradaCancelada() {
        super();
    }
}
