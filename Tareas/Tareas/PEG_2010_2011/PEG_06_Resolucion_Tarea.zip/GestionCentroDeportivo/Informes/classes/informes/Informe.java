package informes;

import java.io.File;
import java.io.InputStream;

import java.net.URL;

import java.sql.Connection;

import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.oasis.JROdtExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;


public class Informe {
    private Connection conexionBD = null;
    private String nombre = null;
    private JasperDesign informeFuente = null;
    private JasperReport informeCompilado = null;
    private JasperPrint informe = null;

    private static final String pathInformes = "/recursos/informes/";

    public static final String FICHERO_000 = "---";
    public static final String FICHERO_PDF = "PDF";
    public static final String FICHERO_HTML = "HTML";
    public static final String FICHERO_XLS = "XLS";
    public static final String FICHERO_CSV = "CSV";
    public static final String FICHERO_RTF = "RTF";
    public static final String FICHERO_ODT = "ODT";
    public static final String FICHERO_XML = "XML";
    
    public static final String INFORME_MDM = "MaestroDetalleMonitores";
    public static final String INFORME_GS = "GruposSocios";
    public static final String INFORME_GRS = "GraficoGrupos";
    public static final String INFORME_TRC = "GruposInstalacionesSociosRF";
    public static final String INFORME_EM = "ExtractoActividades";

    /**Constructor que asigna el nombre de nuestro informe y la conexi�n a la
     * BD que usaremos para rellenar el informe
     * @param nombre String
     * @param conexionBD Connection
     */
    public Informe(String nombre, Connection conexionBD) {
        this.nombre = nombre;
        this.conexionBD = conexionBD;
    }

    /**Carga un fichero .jrxml para obtener un objeto JasperDesign*/
    public void cargarFuente() {
        String recurso = pathInformes + nombre + ".jrxml";
        if (Utilidades.debug)       
            System.out.println("\nIntentando cargar informe: " + recurso);
        InputStream streamInforme = this.getClass().getResourceAsStream(recurso);
        if (Utilidades.debug)    
             System.out.println("\nstreamInforme.toString() = " + streamInforme.toString());
        try {
            informeFuente = JRXmlLoader.load(streamInforme);
        } catch (JRException jre) {
            System.out.println("No puedo cargar el fichero JRXML: " + jre.getMessage());
        }
    }

    /**Compila el objeto JasperDesign y obtiene un objeto JasperReport*/
    public void compilar() {
        if (informeFuente != null) {
            long inicio = System.currentTimeMillis();
            try {
                informeCompilado = JasperCompileManager.compileReport(informeFuente);
                long fin = System.currentTimeMillis();
                if (Utilidades.debug)
                    System.out.println("Tiempo de compilaci�n: " + (fin - inicio) + " ms.");
            } catch (JRException jre) {
                System.out.println("No puedo compilar el informe: " + jre.getMessage());
            }
        } else {
            System.out.println("El informe fuente no puede ser null");
        }

    }

    /**Carga un fichero .jasper para obtener un objeto JasperReport*/
    public void cargarCompilado() {
        String recurso = pathInformes + nombre + ".jasper";
        URL urlInforme = this.getClass().getResource(recurso);
        try {
            informeCompilado = (JasperReport)JRLoader.loadObject(urlInforme);
        } catch (JRException jre) {
            System.out.println("No puedo cargar el fichero JASPER: " + jre.getMessage());
        }
    }

    /**Rellena el objeto JasperReport con los par�metros pasados y nuestra 
     * conexi�n a la BD para obtener un objeto JasperPrint.
     * @param parametros Map
     */
    public void rellenar(Map parametros) {
        if (informeCompilado == null)
            System.out.println("El informe compilado no puede ser null");
        else if (conexionBD == null)
            System.out.println("La conexion a la BD no puede ser nula");
        else {
            try {
                informe = JasperFillManager.fillReport(informeCompilado, parametros, conexionBD);
            } catch (JRException jre) {
                System.out.println("No puedo rellenar el informe: " + jre.getMessage());
            }
        }
    }

    /**Visualiza el objeto JasperPrint*/
    public void visualizar() {
        if (informe != null) {
            //Podr�amos haber utilizado la llamada JasperViewer.viewReport(informe, false)
            //que visualiza el informe, pero entonces no podr�amos haberle dado
            //el foco para que aparezca encima de nuestra GUI.
            JasperViewer jasperViewer = new JasperViewer(informe, false);
            jasperViewer.setVisible(true);
            jasperViewer.requestFocus();        
        }
        else
            System.out.println("El informe relleno no puede ser null");
    }

    /**Exporta el objeto JasperPrint al formato que le pasemos como par�metro.
     * @param ficheroSalida String
     * @param formato String
     */
    public void exportar(String ficheroSalida, String formato) {
        if (informe == null)
            System.out.println("El informe relleno no puede ser null");
        else {
            long inicio = System.currentTimeMillis();
            if (formato.equals(FICHERO_PDF)) {
                //Para exportarlo a PDF
                try {
                    JasperExportManager.exportReportToPdfFile(informe, ficheroSalida);
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)
                         System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a PDF: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_HTML)) {
                //Para exportarlo a HTML
                try {
                    JasperExportManager.exportReportToHtmlFile(informe, ficheroSalida);
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)   
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a HTML: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_XML)) {
                //Para exportarlo a XML.
                try {
                    //El tercer par�metro de este m�todo indica si las im�genes
                    //ir�n embebidas en el documento XML o no
                    JasperExportManager.exportReportToXmlFile(informe, ficheroSalida, true);
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a PDF: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_XLS)) {
                //Para exportarlo a XLS
                File ficheroXls = new File(ficheroSalida);
                JRXlsExporter exporter = new JRXlsExporter();
                exporter.setParameter(JRXlsExporterParameter.JASPER_PRINT, informe);
                exporter.setParameter(JRXlsExporterParameter.OUTPUT_FILE_NAME, ficheroXls.toString());
                try {
                    exporter.exportReport();
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a XLS: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_CSV)) {
                //Para exportarlo a CSV
                File ficheroCsv = new File(ficheroSalida);
                JRCsvExporter exporter = new JRCsvExporter();
                exporter.setParameter(JRExporterParameter.JASPER_PRINT, informe);
                exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, ficheroCsv.toString());
                try {
                    exporter.exportReport();
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug) 
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a RTF: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_RTF)) {
                //Para exportarlo a RTF
                File ficheroRtf = new File(ficheroSalida);
                JRRtfExporter exporter = new JRRtfExporter();
                exporter.setParameter(JRExporterParameter.JASPER_PRINT, informe);
                exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, ficheroRtf.toString());
                try {
                    exporter.exportReport();
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a RTF: " + jre.getMessage());
                }
            }
            else if (formato.equals(FICHERO_ODT)) {
                //Para exportarlo a ODT
                File ficheroOdt = new File(ficheroSalida);
                JROdtExporter exporter = new JROdtExporter();
                exporter.setParameter(JRExporterParameter.JASPER_PRINT, informe);
                exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, ficheroOdt.toString());
                try {
                    exporter.exportReport();
                    long fin = System.currentTimeMillis();
                    if (Utilidades.debug)
                        System.out.println("Tiempo de exportaci�n: " + (fin - inicio) + " ms.");
                } catch (JRException jre) {
                    System.out.println("Error al exportar a ODT: " + jre.getMessage());
                }
            }
            else {
                System.out.println("Error en el tipo de fichero");
            }
        }
    }
}
