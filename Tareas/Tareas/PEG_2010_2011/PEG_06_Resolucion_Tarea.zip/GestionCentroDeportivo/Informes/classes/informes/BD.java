package informes;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;



public class BD {
    private static Connection conexion = null;

    /**Abre la conexi�n a la BD si es que no est� abierta ya.
     * @param usuario String
     * @param contrase�a char[]
     * @return Connection
     * @throws SQLException
     */
    public static Connection abrirConexion(String usuario, char[] contrase�a) throws SQLException {
        if (conexion == null) {
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            conexion = DriverManager.getConnection(url, usuario, new String(contrase�a));
            if (Utilidades.debug)
               System.out.println("Conexi�n a la BD realizada con �xito");
        }
        return conexion;
    }

     /**Cierra la conexi�n a la BD liberando los recursos.
      */
    public static void cerrarConexion() {
        if (conexion != null) {
            try {
                conexion.close();
                if (Utilidades.debug)
                    System.out.println("Conexi�n a la BD cerrada");
            } catch (SQLException sqle) {
                if (Utilidades.debug)
                    System.out.println("Error al cerrar la conexion a la BD: " + sqle.getMessage());
            }
        }
    }

    /**Metodo de acceso a la propiedad est�tica conexion
     * @return Connection
     */
    public static Connection getConexion() {
        return conexion;
        }
    
  
    /**Retorna un String[] conteniendo los ids y nombre de cada monitor para ser utilizados como items de combobox.
     * @return String[]
     * @throws SQLException
     */  
    public static String[] getIdsMonitores() throws SQLException {
          Statement sentencia = conexion.createStatement();
          ResultSet consulta = sentencia.executeQuery("SELECT idmonitor || ' ' || apellidos || ', ' || nombre FROM monitores");
          Vector monitores = new Vector();
          while (consulta.next()) {
              String monitor = consulta.getString(1);
              monitores.add(monitor);
          }
          return (String[])monitores.toArray(new String[monitores.size()]); 
      }

    /**Retorna un String[] conteniendo los ids y nombre de cada socio para ser utilizados como items de combobox.
     * @return String[]
     * @throws SQLException
     */
    public static String[] getIdsSocios() throws SQLException {
          Statement sentencia = conexion.createStatement();
          ResultSet consulta = sentencia.executeQuery("SELECT idsocio || ' ' || apellidos || ', ' || nombre FROM socios");
          Vector socios = new Vector();
          while (consulta.next()) {
              String socio = consulta.getString(1);
              socios.add(socio);
          }
          return (String[])socios.toArray(new String[socios.size()]); 
      }
}
