package informes;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;


public class Utilidades {
    
    /** variable que nos permitir� activar los mensajes por la salida estandar en
     *  funci�n de si estamos depurando o no
     */
    static boolean debug = true;
    
    
    /**M�todo que centra un Contenedor en la pantalla
     * @param f JFrame
     */
    static void centrar(Container f) {
        // Calculo el tama�o de la pantalla y de la ventana
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = f.getSize();
        // Si es mayor, igualo el tama�o de la ventana al de la pantalla
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        // Sit�o la ventana en el centro de la pantalla
        f.setLocation((screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
    }

    /**Metodo que hace una pausa de tantos milisegundos como diga el par�metro
     * @param tiempoMS int
     */
    public static void pausa(int tiempoMS) {
        try {
            Thread.sleep(tiempoMS);
        } catch (InterruptedException ie) {
            System.out.println(ie.getMessage());
        }
    }
}
