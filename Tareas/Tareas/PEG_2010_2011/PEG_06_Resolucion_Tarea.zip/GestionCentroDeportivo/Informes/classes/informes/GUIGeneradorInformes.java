package informes;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.help.CSH;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;


public class GUIGeneradorInformes extends JFrame {
    private JButton jB_Ver = new JButton();
    private ButtonGroup bG_Informes = new ButtonGroup();
    private JCheckBox jCB_Exportar = new JCheckBox();
    private ButtonGroup bG_Ficheros = new ButtonGroup();
    private JLabel jL_Cabecera = new JLabel();
    private JSeparator jSeparator1 = new JSeparator();
    private DialogoLogin dialogoLogin = 
        new DialogoLogin(this, "CentroDeportivo 45 minutos - Indentificaci�n", 
                         true);
    private DialogoInicio dialogoInicio = new DialogoInicio(this, null, false);
    private DialogoEspera dialogoEspera = 
        new DialogoEspera(this, "Generando Informe", false);
    final int TMP_PAUSA = 500;
    private JFileChooser jFC_Fichero = new JFileChooser();
    private JComboBox jcBB_Informe;
    private JComboBox jcBB_Ficheros;
    private JLabel jL_Informes = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jL_ImagenReport = new JLabel();
    private JMenuBar jMenuBar1 = new JMenuBar();
    private JMenu menuArchivo = new JMenu("Archivo");
    private JMenu menuAyuda = new JMenu("Ayuda");
    private JMenuItem jMI_Salir = new JMenuItem();
    private JMenuItem jMI_Ayuda = new JMenuItem();
    private JMenuItem jMI_QueEs = new JMenuItem();
    private JMenuItem jMI_AcercaDe = new JMenuItem();
    

    public GUIGeneradorInformes() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        dialogoInicio.actualizaEstado(0, "Iniciando...");
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(420, 371));
        this.setTitle("CentroDeportivo 45 minutos");
        this.addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent e) {
                        salir();
                    }
                });

        //Cargamos im�genes
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(10, "Cargando Imagenes...");
        ImageIcon icoLogo = 
            new ImageIcon(this.getClass().getResource("/recursos/imagenes/logoCentroDeportivo.jpg"));
        ImageIcon icoVer = 
            new ImageIcon(this.getClass().getResource("/recursos/imagenes/documento.png"));
        ImageIcon iconoAp = 
            new ImageIcon(this.getClass().getResource("/recursos/imagenes/icono.png"));
        ImageIcon iconoReport = 
            new ImageIcon(this.getClass().getResource("/recursos/imagenes/reports.png"));
        this.setIconImage(iconoAp.getImage());

        //A�adimos botones
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(20, "A�adiendo Botones...");
        jB_Ver.setText("Ver Informe");
        jB_Ver.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jB_Ver_actionPerformed(e);
                    }
                });
        jB_Ver.setBounds(new Rectangle(100, 265, 220, 25));
        jB_Ver.setIcon(icoVer);
        jB_Ver.setIconTextGap(10);

        //A�adimos paneles
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(30, "A�adiendo Paneles...");


        //A�adimos combobox
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(40, "A�adiendo ComboBox ...");

        String[] listaInformes = 
            { "Monitores Maestro - Detalle", "Socios por grupo", 
              "Gr�fico n�mero socios por grupo", "Tabla Grupos-Instalaciones", 
              "Extracto mensual" };
        jcBB_Informe = new JComboBox(listaInformes);
        String[] listaFicheros = 
            { "No exportar", "PDF", "HTML", "XLS", "CSV", "RTF", "ODT" };
        jcBB_Ficheros = new JComboBox(listaFicheros);
        jcBB_Informe.setBounds(new Rectangle(155, 110, 205, 25));
        jcBB_Ficheros.setBounds(new Rectangle(155, 195, 130, 25));
        jcBB_Ficheros.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jcBB_Ficheros_actionPerformed(e);
                    }
                });

         //A�adimos menu
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(50, "A�adiendo Men�...");
        jMI_Salir.setText("Salir");
        jMI_Ayuda.setText("Ayuda Generador Informes");
        jMI_QueEs.setText("Qu� es");
        jMI_AcercaDe.setText("Acerca de ...");
        menuArchivo.add(jMI_Salir);
        jMenuBar1.add(menuArchivo);
        menuAyuda.add(jMI_Ayuda);
        menuAyuda.add(jMI_QueEs);
        menuAyuda.add(jMI_AcercaDe);
        jMenuBar1.add(menuAyuda);
        jMI_AcercaDe.addActionListener( new ActionListener() { public void actionPerformed( ActionEvent ae ) { jMI_AcercaDe_ActionPerformed( ae ); } } );
        jMI_Salir.addActionListener( new ActionListener() { public void actionPerformed( ActionEvent ae ) { jMI_Salir_ActionPerformed( ae ); } } );
        this.setJMenuBar( jMenuBar1 );
        

        //A�adimos etiquetas
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(60, "A�adiendo Etiquetas...");
        jL_Cabecera.setText("Generador de Informes");
        jL_Cabecera.setBounds(new Rectangle(19, 5, 375, 40));
        jL_Cabecera.setFont(new Font("Dialog", 1, 22));
        jL_Cabecera.setIcon(icoLogo);
        jL_Cabecera.setSize(new Dimension(375, 40));
        jL_Cabecera.setIconTextGap(10);
        jL_Cabecera.setHorizontalAlignment(SwingConstants.CENTER);
        jL_Cabecera.setForeground(new Color(255, 132, 0));
        jL_Cabecera.setMaximumSize(new Dimension(400, 28));
        jL_Cabecera.setPreferredSize(new Dimension(395, 45));
        jL_Informes.setText("Tipos de informe");
        jL_Informes.setBounds(new Rectangle(155, 85, 105, 15));
        jL_Informes.setToolTipText("null");
        jLabel2.setText("Exportar a ...");
        jLabel2.setBounds(new Rectangle(155, 170, 85, 15));
        jL_ImagenReport.setBounds(new Rectangle(15, 70, 105, 170));
        jL_ImagenReport.setIcon(iconoReport);
        
        jSeparator1.setBounds(new Rectangle(9, 55, 395, 2));

        //A�adimos componentes a los paneles
        jSeparator1.setBackground(new Color(255, 133, 0));
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(74, 
                                      "A�adiendo Componentes a Paneles...");
        this.getContentPane().add(jL_ImagenReport, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jL_Informes, null);
        this.getContentPane().add(jcBB_Ficheros, null);
        this.getContentPane().add(jcBB_Informe, null);
        this.getContentPane().add(jSeparator1, null);
        this.getContentPane().add(jL_Cabecera, null);
        this.getContentPane().add(jCB_Exportar, null);
        this.getContentPane().add(jB_Ver);
        

        //Centramos la ventana
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(88, "Centrando...");
        Utilidades.centrar(this);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Ocultamos DialogoInicio y mostramos VentanaInformes y DialogoLogin
        Utilidades.pausa(TMP_PAUSA); //Hacemos una pausa para poder apreciar la carga inicial
        dialogoInicio.actualizaEstado(100, "Cargado");
        
        //Creamos el Sistema de Ayuda de nuestra apliaci�n
        crearSistemaAyuda();
        
        
        this.setVisible(true);
        this.setJMenuBar(jMenuBar1);
        dialogoInicio.setVisible(false);
        dialogoInicio.dispose();
        dialogoLogin.setVisible(true);
        
        
    }


    /**M�todo que sale al sistema pero antes cierra la conexi�n a la BD*/
    private void salir() {
        BD.cerrarConexion();
        System.exit(0);
    }


    /**M�todo llamado al pulsar el bot�n de nuestra interfaz (Manejador del
     * evento). Este m�todo debe mostrar el dialogo de Espera y visualizar el 
     * informe (y exportarlo si es necesario). Como esto se ejecuta en el EDT 
     * (Event Dispatcher Thread), no repintar� el di�logo de espera hasta que 
     * no acabe el manejador del evento.
     * Por ello, crearemos una hebra que se encargar� de ejecutar el trabajo que
     * m�s tarda (llamada al m�todo verExportarInforme) y as� el manejador del
     * evento terminar� y se podr� repintar el di�logo de espera y en segundo 
     * plano se estar� ejecutando el m�todo que m�s tarda.
     * @param e ActionEvent
     */
    private void jB_Ver_actionPerformed(ActionEvent e) {
        final boolean exportar = jCB_Exportar.isSelected();
        boolean seguir = true;
        FiltroFicheros ff = null;
        String camino = null;
        jB_Ver.setEnabled(false);
        if (exportar) {
            String formato = getFormato();
            ff = new FiltroFicheros(formato);
            jFC_Fichero.addChoosableFileFilter(ff);
            int valorDevuelto = jFC_Fichero.showSaveDialog(this);
            if (valorDevuelto == JFileChooser.APPROVE_OPTION) {
                camino = jFC_Fichero.getSelectedFile().getPath();
                if (camino.lastIndexOf("." + formato) == -1)
                    camino = camino + "." + formato;
            } else
                seguir = false;
            jFC_Fichero.removeChoosableFileFilter(ff);
        }
        if (seguir) {
            try {
                final String fCamino = camino;
                final String tipoInforme = getTipoInforme();
                final Map parametros = getParametrosInforme(tipoInforme);
                dialogoEspera.setVisible(true);
                Thread hebra = new Thread(new Runnable() {
                            public void run() {
                                verExportarInforme(tipoInforme, parametros, 
                                                   exportar, fCamino);
                                dialogoEspera.setVisible(false);
                                jB_Ver.setEnabled(true);
                            }
                        });
                hebra.start();
            } catch (EntradaCancelada f) {
                jB_Ver.setEnabled(true);
            }
            if (exportar)
                jFC_Fichero.removeChoosableFileFilter(ff);
        } else
            jB_Ver.setEnabled(true);
    }

    /**M�todo que se encarga de ver / exportar el informe, realizando los pasos
     * intermedios que son necesarios (cargar, compilar, rellenar, visualizar y
     * exportar en su caso).
     * @param tipoInforme String
     * @param parametros Map
     * @param exportar boolean
     * @param ficheroSalida String
     */
    private void verExportarInforme(String tipoInforme, Map parametros, 
                                    boolean exportar, String ficheroSalida) {
        Informe informe = new Informe(tipoInforme, BD.getConexion());
        informe.cargarFuente();
        informe.compilar();
        informe.rellenar(parametros);
        informe.visualizar();
        if (exportar)
            informe.exportar(ficheroSalida, getFormato());
    }


    /**Cambia la etiqueta del bot�n jB_Ver
     * @param estado boolean
     */
    private void cambiaEstado(boolean estado) {
        if (estado)
            jB_Ver.setText("Ver / Exportar Informe");
        else
            jB_Ver.setText("Ver Informe");
    }

    /**Devuelve el tipo de documento que hemos seleccionado
     * @return String
     */
    private String getFormato() {
        return (String)jcBB_Ficheros.getSelectedItem();
    }

    /**Devuelve el tipo de Informe elegido
     * @return String
     */
    private String getTipoInforme() {
        String tipoInforme = null;
        switch (jcBB_Informe.getSelectedIndex()) {
        case 0:
            tipoInforme = Informe.INFORME_MDM;
            break;
        case 1:
            tipoInforme = Informe.INFORME_GS;
            break;
        case 2:
            tipoInforme = Informe.INFORME_GRS;
            break;
        case 3:
            tipoInforme = Informe.INFORME_TRC;
            break;
        case 4:
            tipoInforme = Informe.INFORME_EM;
            break;
        }
        return tipoInforme;
    }

    /**Pregunta al usuario por los parametros a introducir dependiendo del tipo de Informe
     * @param tipoInforme String
     * @return HashMap
     * @throws EntradaCancelada
     */
    private HashMap getParametrosInforme(String tipoInforme) throws EntradaCancelada {
        HashMap parametros = new HashMap();
        if (tipoInforme.equals(Informe.INFORME_EM)) {
            String[] socios = null;
            try {
                socios = BD.getIdsSocios();
                String socio = 
                    (String)JOptionPane.showInputDialog(this, "Introduzca el socio para el\n" + 
                                                        "que quiere crear el informe", 
                                                        "Elija el socio", 
                                                        JOptionPane.PLAIN_MESSAGE, 
                                                        new ImageIcon(this.getClass().getResource("/recursos/imagenes/logoCentroDeportivo.jpg")), 
                                                        socios, 1);
                if (socio == null)
                    throw new EntradaCancelada();
                BigDecimal id_socio = new BigDecimal(socio.substring(0, 1));
                parametros.put("ID_SOCIO", id_socio);
            } catch (SQLException e) {
                System.out.println("Error al ejecutar la consulta sobre IDs Socios");
            }
        } else if (tipoInforme.equals(Informe.INFORME_MDM)) {
            String[] monitores = null;
            try {
                monitores = BD.getIdsMonitores();
                String monitor = 
                    (String)JOptionPane.showInputDialog(this, "Introduzca el monitor para el\n" + 
                                                        "que quiere crear el informe", 
                                                        "Elija el monitor", 
                                                        JOptionPane.PLAIN_MESSAGE, 
                                                        new ImageIcon(this.getClass().getResource("/recursos/imagenes/logoCentroDeportivo.jpg")), 
                                                        monitores, 1);

                if (monitor == null)
                    throw new EntradaCancelada();
                BigDecimal id_monitor = 
                    new BigDecimal(monitor.substring(0, 1));
                parametros.put("IDMONITOR", id_monitor);
            } catch (SQLException e) {
                System.out.println("Error al ejecutar la consulta sobre IDs Socios");
            }
        }
        return parametros;
    }

    /**Se ejecuta cuando cambiamos de estado el jcBB_Ficheros y cambia de estado
     * los componentes necesarios.
     * @param e ActionEvent
     */
    private

    void jcBB_Ficheros_actionPerformed(ActionEvent e) {
        cambiaEstado(jcBB_Ficheros.getSelectedIndex() != 0);
        // jCB_Exportar est� oculto pero activo 
        jCB_Exportar.setSelected(jcBB_Ficheros.getSelectedIndex() != 0);
    }

    /**Creamos el Sistema de Ayuda de nuestra apliaci�n*/
    private void crearSistemaAyuda() {
        HelpSet hs = null;
        HelpBroker hb;
        // Buscamos el fichero .hs
        String helpHS = "recursos/help/ayuda.hs";
        ClassLoader cl = this.getClass().getClassLoader();
        try {
            URL hsURL = HelpSet.findHelpSet(cl, helpHS);
            hs = new HelpSet(cl, hsURL);
        } catch (Exception e) {
            System.out.println("HelpSet " + e.getMessage());
        }
        // Creamos el objeto HelpBroker
        hb = hs.createHelpBroker();
        //Habilitamos la tecla F1 para nuestra GUI
        hb.enableHelpKey(getRootPane(), "index", hs);
        //Definimos la ayuda contextual
        hb.enableHelp(jcBB_Informe, "tiposInforme", hs);
        hb.enableHelp(jcBB_Ficheros, "formatos", hs);

        //Lanzamos la ayuda al pulsar sobre el Men� Ayuda
        hb.enableHelpOnButton(jMI_Ayuda, "index", hs);
        //Lanzamos la ayuda despu�s de elegir el componente sobre el que  
        //queremos ayuda
        jMI_QueEs.addActionListener(new CSH.DisplayHelpAfterTracking(hb));
    }
    
    
    private void jMI_Salir_ActionPerformed(ActionEvent ae) {
      salir();
    }
    
    private void jMI_AcercaDe_ActionPerformed(ActionEvent ae) {
        AcercaDe acercade = new AcercaDe();
    }

}
