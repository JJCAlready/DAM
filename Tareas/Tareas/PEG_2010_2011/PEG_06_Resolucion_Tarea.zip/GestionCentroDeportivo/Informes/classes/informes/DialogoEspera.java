package informes;

import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Rectangle;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;

/**
 * Dialogo modal que se mostrar� cuando se ejecute alguna acci�n con una duraci�n considerable.
*/
public class DialogoEspera extends JDialog {
    private JLabel jL_Mensaje = new JLabel();

    /**
     * Constructor de la clase sin par�metros, crea el objeto sin asignarle valores
     */
    public DialogoEspera() {
        this((Frame)null, "", false);
    }

    /**
     * Constructor de la clase con parametros
     * @param parent Frame : padre de este
     * @param title String : titulo de la ventana
     * @param modal boolean : �el dialogo ser� modal o no modal?
     */
    public DialogoEspera(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Constructor de la clase con parametros
     * @param parent Dialog : padre de este
     * @param title String : titulo de la ventana
     * @param modal boolean : �el dialogo ser� modal o no modal?
     */
    public DialogoEspera(Dialog parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Metodo que configura y muestra el dialogo
    private void jbInit() throws Exception {
        this.setSize(new Dimension(345, 166));
        this.getContentPane().setLayout(null);
        this.setTitle("CentroDeportivo 45 minutos");
        jL_Mensaje.setText("Espere un momento por favor...");
        jL_Mensaje.setBounds(new Rectangle(15, 20, 305, 90));
        ImageIcon icoReloj = new ImageIcon(this.getClass().getResource("/recursos/imagenes/reloj-mesa.gif"));
        jL_Mensaje.setIcon(icoReloj); 
        this.getContentPane().add(jL_Mensaje, null);
        Utilidades.centrar(this);
    }
}
