package informes;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


/**
 * Dialogo para solicitar la introducci�n del usuario y contrase�a
 * para conectar con la base de datos
*/
public class DialogoLogin extends JDialog {
    private static final int MAX_INTENTOS = 3;
    private JLabel jL_usuario = new JLabel();
    private JLabel jL_Contrasenya = new JLabel();
    private JTextField jTF_Usuario = new JTextField();
    private JPasswordField jPF_Contrasenya = new JPasswordField();
    private JButton jB_Aceptar = new JButton();
    private JButton jB_Cancelar = new JButton();
    private int intentos = 0;
    private DialogoEspera dialogoEspera = new DialogoEspera(this, "Conectando a la BD", false);
    private JLabel jLabelIconLogin = new JLabel();

    public DialogoLogin() {
        this(null, "", false);
    }

    public DialogoLogin(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(377, 236));
        this.setDefaultCloseOperation(0);
        ImageIcon icoOk = new ImageIcon(this.getClass().getResource("/recursos/imagenes/ok.png"));
        ImageIcon icoNok = new ImageIcon(this.getClass().getResource("/recursos/imagenes/nok.png"));
        ImageIcon icoLogin = new ImageIcon(this.getClass().getResource("/recursos/imagenes/login.png"));
        jL_usuario.setText("Usuario");
        jL_usuario.setBounds(new Rectangle(125, 40, 75, 25));
        jL_usuario.setHorizontalAlignment(SwingConstants.TRAILING);
        jL_Contrasenya.setText("Contrase�a");
        jL_Contrasenya.setBounds(new Rectangle(125, 85, 75, 25));
        jL_Contrasenya.setHorizontalAlignment(SwingConstants.TRAILING);
        jTF_Usuario.setBounds(new Rectangle(210, 40, 125, 25));
        jTF_Usuario.setToolTipText("Introduce el Usuario de la Base de Datos");
        jB_Aceptar.setText("Aceptar");
        jB_Aceptar.setBounds(new Rectangle(50, 150, 115, 30));
        jB_Aceptar.setIcon(icoOk);
        jB_Aceptar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jB_Aceptar_actionPerformed(e);
                    }
                });
        jB_Cancelar.setText("Cancelar");
        jB_Cancelar.setBounds(new Rectangle(200, 150, 115, 30));
        jB_Cancelar.setIcon(icoNok);
        jB_Cancelar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jB_Cancelar_actionPerformed(e);
                    }
                });
        jPF_Contrasenya.setBounds(new Rectangle(210, 85, 125, 25));
        jPF_Contrasenya.setToolTipText("Introduce la contrase�a para el usuario");
        jPF_Contrasenya.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jPF_Contrasenya_actionPerformed(e);
                    }
                });
        jLabelIconLogin.setIcon(icoLogin);;
        jLabelIconLogin.setBounds(new Rectangle(45, 35, 90, 75));

        //Centramos el Dialogo
        this.getContentPane().add(jLabelIconLogin, null);
        this.getContentPane().add(jPF_Contrasenya, null);
        this.getContentPane().add(jB_Aceptar, null);
        this.getContentPane().add(jB_Cancelar, null);
        this.getContentPane().add(jTF_Usuario, null);
        this.getContentPane().add(jL_Contrasenya, null);
        this.getContentPane().add(jL_usuario, null);
        Utilidades.centrar(this);
    }

    /**Metodo que intenta validarse en la BD siempre que no hayamos sobrepasado
     * el n�mero m�ximo de intentos.
     */
    private void validar() {      
        try {
            BD.abrirConexion(jTF_Usuario.getText(), jPF_Contrasenya.getPassword());
            setCursor(null);
            dialogoEspera.setVisible(false);
            JOptionPane.showMessageDialog(this, "Conexi�n a la BD realizada con �xito", "�xito", JOptionPane.INFORMATION_MESSAGE);
            setVisible(false);
            dispose();
        } catch (SQLException sqle) {
            setCursor(null);
            dialogoEspera.setVisible(false);
            JOptionPane.showMessageDialog(this, "No me puedo conectar a la BD.\n" + sqle.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            intentos++;
        }
        if (intentos == MAX_INTENTOS) {
            setCursor(null);
            dialogoEspera.setVisible(false);
            JOptionPane.showMessageDialog(this, "Superado el n�mero m�ximo de reintentos", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(-1);
        }
    }

    /**Metodo que hace visible el DialogoEspera, deshabilita los botones y pone
     * el cursor de espera. Una vez hecho esto crea una hebra en la que se intenta
     * validar en la BD, pone el cursor normal, hace invisible el dialogoEspera
     * y habilita los botones. Se crea una hebra (y se ejecuta la misma) ya que
     * este m�todo es llamado desde los manejadores de eventos del bot�n aceptar
     * y del campo contrase�a (actionPerformed) como esto se ejecuta en el EDT 
     * (Event Dispatcher Thread), no repintar� el di�logo de espera hasta que 
     * no acabe el manejador del evento (es decir, este m�todo ya que los
     * manejadores llaman a este m�todo).
     * Por ello, crearemos una hebra que se encargar� de ejecutar el trabajo que
     * m�s tarda (llamada al m�todo validar) y as� el manejador del
     * evento terminar� y se podr� repintar el di�logo de espera y en segundo 
     * plano se estar� ejecutando el m�todo que m�s tarda.
     */
    private void esperarValidar() {
        jB_Aceptar.setEnabled(false);
        jB_Cancelar.setEnabled(false);
        dialogoEspera.setVisible(true);
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        Thread hebra = new Thread(new Runnable() {
            public void run() {
                validar();
                setCursor(null);
                dialogoEspera.setVisible(false);
                jB_Aceptar.setEnabled(true);
                jB_Cancelar.setEnabled(true);
            }
        });
        hebra.start();
    }
    
    /**Pulsamos Aceptar, por lo que intentamos validarnos en la BD
     * @param e ActionEvent
     */
    private void jB_Aceptar_actionPerformed(ActionEvent e) {
        esperarValidar();       
    }

    /**Pulsamos Enter en PF_Contrase�a, por lo que intentamos validarnos en la BD
     * @param e ActionEvent
     */
    private void jPF_Contrasenya_actionPerformed(ActionEvent e) {
        esperarValidar();
    }

    /**Pulsamos Cancelar, por lo que abandonamos la aplicaci�n
     * @param e ActionEvent
     */
    private void jB_Cancelar_actionPerformed(ActionEvent e) {
        System.exit(1);
    }

}
