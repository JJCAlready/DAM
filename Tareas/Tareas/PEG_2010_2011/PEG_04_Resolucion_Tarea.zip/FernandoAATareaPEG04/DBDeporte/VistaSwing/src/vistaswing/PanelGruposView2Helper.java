package vistaswing;

import com.jgoodies.forms.layout.*;

import java.awt.*;
import java.awt.event.*;

import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.*;

import oracle.adf.model.*;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.*;

import oracle.jbo.uicli.binding.*;
import oracle.jbo.uicli.controls.*;
import oracle.jbo.uicli.jui.*;

import oracle.jdeveloper.layout.*;

public class PanelGruposView2Helper extends JPanel implements JUPanel {
    /**The default constructor for panel
     */
    public PanelGruposView2Helper() {
        this.setLayout(borderLayout);
    }

    /**the JbInit method
     */
    public void jbInit() throws Exception {
        dataPanel.setLayout(panelLayout);
        dataPanel.setMinimumSize(new Dimension(100,100));
        mIdgrupo.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Idgrupo_4")).getTooltip());
        mIdgrupo.setColumns(panelBinding.findCtrlValueBinding("GruposView2Idgrupo_4").getDisplayWidth());
        mIdgrupo.setDocument((Document)panelBinding.bindUIControl("GruposView2Idgrupo_4",mIdgrupo));
        dataPanel.add(labelmIdgrupo, new CellConstraints("2, 2,1,1,default,"+CellConstraints.FILL));
        labelmIdgrupo.setLabelFor(mIdgrupo);
        dataPanel.add(mIdgrupo, new CellConstraints("4, 2,1,1,default,"+CellConstraints.FILL));
        mIdgrupo.setColumns(15);
        labelmIdgrupo.setText(panelBinding.findCtrlValueBinding("GruposView2Idgrupo_4").getLabel());
        mCodigoinstalacion.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Codigoinstalacion_4")).getTooltip());
        mCodigoinstalacion.setColumns(panelBinding.findCtrlValueBinding("GruposView2Codigoinstalacion_4").getDisplayWidth());
        mCodigoinstalacion.setDocument((Document)panelBinding.bindUIControl("GruposView2Codigoinstalacion_4",mCodigoinstalacion));
        dataPanel.add(labelmCodigoinstalacion, new CellConstraints("2, 4,1,1,default,"+CellConstraints.FILL));
        labelmCodigoinstalacion.setLabelFor(mCodigoinstalacion);
        dataPanel.add(mCodigoinstalacion, new CellConstraints("4, 4,1,1,default,"+CellConstraints.FILL));
        mCodigoinstalacion.setColumns(15);
        labelmCodigoinstalacion.setText(panelBinding.findCtrlValueBinding("GruposView2Codigoinstalacion_4").getLabel());
        mCosactividad.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Cosactividad_4")).getTooltip());
        mCosactividad.setColumns(panelBinding.findCtrlValueBinding("GruposView2Cosactividad_4").getDisplayWidth());
        mCosactividad.setDocument((Document)panelBinding.bindUIControl("GruposView2Cosactividad_4",mCosactividad));
        dataPanel.add(labelmCosactividad, new CellConstraints("2, 6,1,1,default,"+CellConstraints.FILL));
        labelmCosactividad.setLabelFor(mCosactividad);
        dataPanel.add(mCosactividad, new CellConstraints("4, 6,1,1,default,"+CellConstraints.FILL));
        mCosactividad.setColumns(15);
        labelmCosactividad.setText(panelBinding.findCtrlValueBinding("GruposView2Cosactividad_4").getLabel());
        mIdmonitor.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Idmonitor_4")).getTooltip());
        mIdmonitor.setColumns(panelBinding.findCtrlValueBinding("GruposView2Idmonitor_4").getDisplayWidth());
        mIdmonitor.setDocument((Document)panelBinding.bindUIControl("GruposView2Idmonitor_4",mIdmonitor));
        dataPanel.add(labelmIdmonitor, new CellConstraints("2, 8,1,1,default,"+CellConstraints.FILL));
        labelmIdmonitor.setLabelFor(mIdmonitor);
        dataPanel.add(mIdmonitor, new CellConstraints("4, 8,1,1,default,"+CellConstraints.FILL));
        mIdmonitor.setColumns(15);
        labelmIdmonitor.setText(panelBinding.findCtrlValueBinding("GruposView2Idmonitor_4").getLabel());
        mNombre.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Nombre_4")).getTooltip());
        mNombre.setColumns(panelBinding.findCtrlValueBinding("GruposView2Nombre_4").getDisplayWidth());
        mNombre.setDocument((Document)panelBinding.bindUIControl("GruposView2Nombre_4",mNombre));
        dataPanel.add(labelmNombre, new CellConstraints("2, 10,1,1,default,"+CellConstraints.FILL));
        labelmNombre.setLabelFor(mNombre);
        dataPanel.add(mNombre, new CellConstraints("4, 10,1,1,default,"+CellConstraints.FILL));
        mNombre.setColumns(15);
        labelmNombre.setText(panelBinding.findCtrlValueBinding("GruposView2Nombre_4").getLabel());
        mHorario.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Horario_4")).getTooltip());
        mHorario.setColumns(panelBinding.findCtrlValueBinding("GruposView2Horario_4").getDisplayWidth());
        mHorario.setDocument((Document)panelBinding.bindUIControl("GruposView2Horario_4",mHorario));
        dataPanel.add(labelmHorario, new CellConstraints("2, 12,1,1,default,"+CellConstraints.FILL));
        labelmHorario.setLabelFor(mHorario);
        dataPanel.add(mHorario, new CellConstraints("4, 12,1,1,default,"+CellConstraints.FILL));
        mHorario.setColumns(15);
        labelmHorario.setText(panelBinding.findCtrlValueBinding("GruposView2Horario_4").getLabel());
        mEstado.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Estado_4")).getTooltip());
        mEstado.setColumns(panelBinding.findCtrlValueBinding("GruposView2Estado_4").getDisplayWidth());
        mEstado.setDocument((Document)panelBinding.bindUIControl("GruposView2Estado_4",mEstado));
        dataPanel.add(labelmEstado, new CellConstraints("2, 14,1,1,default,"+CellConstraints.FILL));
        labelmEstado.setLabelFor(mEstado);
        dataPanel.add(mEstado, new CellConstraints("4, 14,1,1,default,"+CellConstraints.FILL));
        mEstado.setColumns(15);
        labelmEstado.setText(panelBinding.findCtrlValueBinding("GruposView2Estado_4").getLabel());
        mPrecio.setToolTipText((panelBinding.findCtrlValueBinding("GruposView2Precio_4")).getTooltip());
        mPrecio.setColumns(panelBinding.findCtrlValueBinding("GruposView2Precio_4").getDisplayWidth());
        mPrecio.setDocument((Document)panelBinding.bindUIControl("GruposView2Precio_4",mPrecio));
        dataPanel.add(labelmPrecio, new CellConstraints("2, 16,1,1,default,"+CellConstraints.FILL));
        labelmPrecio.setLabelFor(mPrecio);
        dataPanel.add(mPrecio, new CellConstraints("4, 16,1,1,default,"+CellConstraints.FILL));
        mPrecio.setColumns(15);
        labelmPrecio.setText(panelBinding.findCtrlValueBinding("GruposView2Precio_4").getLabel());
        add(dataPanel, BorderLayout.CENTER);
    }
    private JUPanelBinding panelBinding = new JUPanelBinding("PanelGruposView2HelperPageDef");
    private JPanel dataPanel = new JPanel();
    private BorderLayout borderLayout = new BorderLayout();
    private FormLayout panelLayout = new FormLayout("f:3dlu:n, r:d:g, f:5dlu:n, f:71mm:n, f:5dlu:n", "c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n, c:d:n, c:3dlu:n");
    private JLabel labelmIdgrupo = new JLabel();
    private JTextField mIdgrupo = new JTextField();
    private JLabel labelmCodigoinstalacion = new JLabel();
    private JTextField mCodigoinstalacion = new JTextField();
    private JLabel labelmCosactividad = new JLabel();
    private JTextField mCosactividad = new JTextField();
    private JLabel labelmIdmonitor = new JLabel();
    private JTextField mIdmonitor = new JTextField();
    private JLabel labelmNombre = new JLabel();
    private JTextField mNombre = new JTextField();
    private JLabel labelmHorario = new JLabel();
    private JTextField mHorario = new JTextField();
    private JLabel labelmEstado = new JLabel();
    private JTextField mEstado = new JTextField();
    private JLabel labelmPrecio = new JLabel();
    private JTextField mPrecio = new JTextField();

    public static void main(String [] args) {
        try {
            UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticXPLookAndFeel");
        } catch (ClassNotFoundException cnfe) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception exemp) {
                exemp.printStackTrace();
            }
        } catch (Exception exemp) {
            exemp.printStackTrace();
        }
        PanelGruposView2Helper panel = new PanelGruposView2Helper();
        panel.setBindingContext(JUTestFrame.startTestFrame("vistaswing.DataBindings.cpx", "null", panel, panel.getPanelBinding(), new Dimension(400,300)));
        panel.revalidate();
    }

    /**ADF Swing Panel implementation
     */
    public JUPanelBinding getPanelBinding() {
        return panelBinding;
    }

    public void bindNestedContainer(JUPanelBinding ctr) {
        if (panelBinding.getPanel() == null) {
            ctr.setPanel(this);
            panelBinding.release(DCDataControl.REL_VIEW_REFS);
            panelBinding = ctr;
            registerProjectGlobalVariables(panelBinding.getBindingContext());
            try {
                jbInit();
            } catch (Exception ex) {
                ex.printStackTrace();
                ctr.reportException(ex);
            }
        }
    }

    private void registerProjectGlobalVariables(BindingContext bindCtx) {
        JUUtil.registerNavigationBarInterface(panelBinding, bindCtx);
    }

    private void unRegisterProjectGlobalVariables(BindingContext bindCtx) {
        JUUtil.unRegisterNavigationBarInterface(panelBinding, bindCtx);
    }

    public void setBindingContext(BindingContext bindCtx) {
        if (panelBinding.getPanel() == null) {
            panelBinding = panelBinding.setup(bindCtx, this);
            registerProjectGlobalVariables(bindCtx);
            panelBinding.refreshControl();
            try {
                jbInit();
                panelBinding.refreshControl();
            } catch (Exception ex) {
                panelBinding.reportException(ex);
            }
        }
    }
}
