package vistaswing;

import java.awt.*;

import java.util.ArrayList;

import javax.swing.*;

import oracle.adf.model.*;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.*;

import oracle.jbo.uicli.binding.*;
import oracle.jbo.uicli.binding.JUIteratorBinding;
import oracle.jbo.uicli.controls.*;
import oracle.jbo.uicli.controls.JUNavigationBar;
import oracle.jbo.uicli.jui.*;

import oracle.jdeveloper.layout.*;

public class GPanel extends JPanel implements JUPanel {
    private JUNavigationBar jUNavigationBar1 = new JUNavigationBar();
    private PanelGruposView2Helper panelGruposView2Helper1 = 
        new PanelGruposView2Helper();

    /**The default constructor for panel
     */
    public GPanel() {
    }

    /**the JbInit method
     */
    public void jbInit() throws Exception {
        panelGruposView2Helper1.bindNestedContainer(panelBinding.findNestedPanelBinding("PanelGruposView2HelperPageDef4"));
        this.setLayout(null);
        this.setSize(new Dimension(401, 300));
        this.setBounds(new Rectangle(10, 10, 400, 300));
        this.setMaximumSize(new Dimension(300, 400));
        this.setMinimumSize(new Dimension(300, 400));
        jUNavigationBar1.setBounds(new Rectangle(0, 0, 395, 25));
        jUNavigationBar1.setHasInsertButton(false);
        jUNavigationBar1.setHasNavigationButtons(false);
        jUNavigationBar1.setHasFindButton(false);
        this.add(panelGruposView2Helper1, null);
        this.add(jUNavigationBar1, null);
        jUNavigationBar1.setModel(JUNavigationBar.createViewBinding(panelBinding, jUNavigationBar1, "GruposView2", null, "GruposView2Iterator"));panelGruposView2Helper1.setBounds(new Rectangle(5, 30, 380, 225));
    }

    /**JUPanel implementation
     */
    public JUPanelBinding getPanelBinding() {
        return panelBinding;
    }

    public void bindNestedContainer(JUPanelBinding ctr) {
        if (panelBinding.getPanel() == null) {
            ctr.setPanel(this);
            panelBinding.release(DCDataControl.REL_VIEW_REFS);
            panelBinding = ctr;
            registerProjectGlobalVariables(panelBinding.getBindingContext());
            try {
                jbInit();
            } catch (Exception ex) {
                ex.printStackTrace();
                ctr.reportException(ex);
            }
        }
    }
    private JUPanelBinding panelBinding = new JUPanelBinding("GPanelPageDef");

    private void registerProjectGlobalVariables(BindingContext bindCtx) {
        JUUtil.registerNavigationBarInterface(panelBinding, bindCtx);
    }

    private void unRegisterProjectGlobalVariables(BindingContext bindCtx) {
        JUUtil.unRegisterNavigationBarInterface(panelBinding, bindCtx);
    }

    public void setBindingContext(BindingContext bindCtx) {
        if (panelBinding.getPanel() == null) {
            panelBinding = panelBinding.setup(bindCtx, this);
            registerProjectGlobalVariables(bindCtx);
            panelBinding.refreshControl();
            try {
                jbInit();
                panelBinding.refreshControl();
            } catch (Exception ex) {
                panelBinding.reportException(ex);
            }
        }
    }
}
