package accesogcd;

import java.sql.*;

public class DBDeporte {
    private Driver driver;
    private Connection conn;
   
   public DBDeporte () {
       
   }

    public boolean ConectaBD() throws SQLException {
        String username = "usuario_deporte";
        String password = "123456";
        String thinConn = "jdbc:oracle:thin:@localhost:1521:XE";
        // intentamos registrar el driver
        try {
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            // si se registr� correctamente, intentamos la conexi�n
            try {
                conn = DriverManager.getConnection(thinConn, username, password);
                // Ponemos el commit manual
                conn.setAutoCommit(false); 
                // como todo fue bien, retornamos true
                return true;
                // en caso de fallo retornamos false
            } catch (SQLException e) {
                return false;
            }
        } catch (SQLException e) {
            return false;                 
        }
        
    }


    public Boolean DesconectaBD() {
        try {
            conn.close();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public Boolean ConfirmarCambios() {
        try {
            conn.commit();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
    
    public Boolean DeshacerCambios() {
        try {
            conn.rollback();
            return true;
        } catch (SQLException e) {
             return false;
        }
    }
    
     public ResultSet ConsultaBD(String estado) {
        // Crea Statement para cosulta SQL
        PreparedStatement pstmt;
        ResultSet rset;
        // Ejecuta consulta SQL
        try {
            String strSQL = "SELECT  IDGRUPO, G.NOMBRE AS NOM, HORARIO, PRECIO, ESTADO, EQUIPOBASICO, M.NOMBRE || ' ' || M.APELLIDOS AS MONITOR " +   
                            "FROM GRUPOS G, MONITORES M, ACTIVIDADES A " +
                            "WHERE ESTADO LIKE ? AND G.IDMONITOR=M.IDMONITOR AND G.COSACTIVIDAD=A.COSACTIVIDAD " +
                            "ORDER BY IDGRUPO";
            pstmt = conn.prepareStatement(strSQL);
            pstmt.setString(1,estado);
            rset = pstmt.executeQuery();
    
            
        } catch (SQLException e) {
             rset = (ResultSet)null;
             System.out.print("Error " + e.getMessage() + "al ejecutar la consulta en la funci�n ConsultaBD");
        }
        return rset;
    }
    
    public int ActualizaGrupos(String grupo) {
        int filasAfectadas = -1;
        // Crea Statement para cosulta SQL
        PreparedStatement pstmt;
        try {
            String strSQL = "UPDATE GRUPOS SET PRECIO=PRECIO*0.90 WHERE IDGRUPO LIKE ?";
            pstmt = conn.prepareStatement(strSQL);
            System.out.print("IdGrupo a actualizar: " + grupo);
            pstmt.setString(1, grupo);
            filasAfectadas = pstmt.executeUpdate();
            //System.out.print("Filas afectadas: " + filasAfectadas);
            
        } catch (SQLException e) {
            System.out.print("Error " + e.getMessage() + 
                             "al ejecutar la consulta en la funci�n ActualizaBD");

        }
        return (filasAfectadas);
    }
    
}
