package accesogcd;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Principal {
    public Principal() {
    }

    public static void main(String[] args) throws SQLException {
       VistaResultados m = new VistaResultados();
       m.setVisible(true);
    } 
}
