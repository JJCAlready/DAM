package accesogcd;

import java.awt.Dimension;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.ResultSet;

import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class VistaResultados extends JFrame {
    private JScrollPane jScrollPane1 = new JScrollPane();
    private ModeloTabla modelo = new ModeloTabla();
    private ModeloTabla modelo2 = new ModeloTabla();
    private JTable jTable1 = new JTable(modelo);
    private JScrollPane jScrollPane2 = new JScrollPane();
    private JTable jTable2 = new JTable(modelo2);
    private JLabel jLabel1 = new JLabel();
    private JButton jButton1 = new JButton();
    DBDeporte dbd = new DBDeporte();
    private JLabel jLabel2 = new JLabel();
    JOptionPane jop = new JOptionPane();
    private JButton jButton2 = new JButton();
    private JButton jButton3 = new JButton();


    public VistaResultados() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void PonerTitulosTabla(DefaultTableModel modelo) {
        // Poner titulos a la tabla que muestra los resultados de la consulta
        modelo.addColumn("N� Grupo");
        modelo.addColumn("Actividad");
        modelo.addColumn("Horario");
        modelo.addColumn("Precio");
        modelo.addColumn("Estado");
        modelo.addColumn("Equipo");
        modelo.addColumn("Monitor");  
    }
    
    public void ActualizaTabla(DefaultTableModel modelo, String grupo ) throws SQLException {
        ResultSet rs;
        // Borrar el contenido previo de la tabla
       while (modelo.getRowCount()>0) 
            modelo.removeRow(0);
            
        // Actualizar el contenido con la consulta
        rs = dbd.ConsultaBD(grupo);
        while (rs.next()) {
            // Se crea un array que ser� una de las filas de la tabla. 
            Object[] fila = new Object[7]; // Hay 7 columnas en la tabla
            fila[0] = rs.getString("IDGRUPO");
            fila[1] = rs.getString("NOM");
            fila[2] = rs.getString("HORARIO");
            fila[3] = rs.getString("PRECIO");
            fila[4] = rs.getString("ESTADO");
            fila[5] = rs.getString("EQUIPOBASICO");
            fila[6] = rs.getString("MONITOR");           
            // Se rellena la fila
            modelo.addRow(fila);
        } 
        
    }
    
    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(788, 479));
        this.setTitle( "Resultados" );
        jScrollPane1.setBounds(new Rectangle(10, 40, 760, 175));
        jScrollPane2.setBounds(new Rectangle(10, 285, 760, 155));
        jTable2.setEnabled(false);
        jLabel1.setText("Consulta de los grupos deportivos en curso:");
        jLabel1.setBounds(new Rectangle(10, 20, 750, 15));
        jButton1.setText("Rebajar 10%");
        jButton1.setBounds(new Rectangle(15, 235, 135, 20));
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            jButton1_actionPerformed(e);
                        } catch (Exception f) {
                            // TODO
                        }
                    }
                });
        jLabel2.setText("Consulta de todos los grupos deportivos");
        jLabel2.setBounds(new Rectangle(20, 265, 300, 15));
        jButton2.setText("Desconectar");
        jButton2.setBounds(new Rectangle(185, 235, 115, 20));
        jButton2.setToolTipText("null");
        jButton2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton2_actionPerformed(e);
                    }
                });
        jButton3.setText("Conectar");
        jButton3.setBounds(new Rectangle(335, 235, 105, 20));
        jButton3.setToolTipText("null");
        jButton3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton3_actionPerformed(e);
                    }
                });
        jScrollPane1.getViewport().add(jTable1, null);
        this.getContentPane().add(jButton3, null);
        this.getContentPane().add(jButton2, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jButton1, null);
        this.getContentPane().add(jLabel1, null);
        jScrollPane2.getViewport().add(jTable2, null);
        this.getContentPane().add(jScrollPane2, null);
        this.getContentPane().add(jScrollPane1, null);
    
        // Finalizar aplicaci�n al salir
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // selecci�n de una sola fila
        jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
       
        if (dbd.ConectaBD()) {
            jop.showMessageDialog(this, "Establecida la conexi�n con la base de datos");  
        } else {
            jop.showMessageDialog(this, "Ha sido imposible establecer la conexi�n con la base de datos");
        }
        PonerTitulosTabla(modelo);
        PonerTitulosTabla(modelo2);
        ActualizaTabla(modelo, "C");
        ActualizaTabla(modelo2, "%");
 
    }

    private void jButton1_actionPerformed(ActionEvent e) throws Exception{
        int filaGrupo =jTable1.getSelectedRow();
        if (filaGrupo > -1) {
            String grupo = String.valueOf(jTable1.getValueAt(filaGrupo, 0));
            // actualizamos los grupos seleccionados
            if(dbd.ActualizaGrupos(grupo)<0) {
                jop.showMessageDialog(this, "No fue posible la actualizaci�n","GCD",jop.ERROR_MESSAGE);
              return;
            }
            // y mostramos los cambios en las tablas
            ActualizaTabla(modelo2, "%");
            ActualizaTabla(modelo, "C");
            // damos la oportunidad de desacer los cambios
            String string1 = "Si";
            String string2 = "No";
            Object[] opciones = {string1, string2};
            int op= jop.showOptionDialog(this,
                                  "Modificado el grupo con IDGRUPO = " + grupo + 
                                      "\n�Desea guardar cambios en la base de datos?",
                                 "Gesti�n centro deportivo",
                                 jop.YES_NO_OPTION,
                                 jop.QUESTION_MESSAGE,
                                  null,
                                  opciones,
                                  string1);
            if (op==jop.YES_OPTION) {
                if (dbd.ConfirmarCambios()) {
                    jop.showMessageDialog(this, "Cambios guardados correctamente","GCD",jop.INFORMATION_MESSAGE);
                } else {
                    jop.showMessageDialog(this, "No pudieron guardarse los cambios","GCD",jop.ERROR_MESSAGE);
                }
            } else {
                if (dbd.DeshacerCambios()) {
                    jop.showMessageDialog(this, "Cambios anulados correctamente","GCD",jop.INFORMATION_MESSAGE);
                } else {
                    jop.showMessageDialog(this, "No pudieron anularse los cambios","GCD",jop.ERROR_MESSAGE);
                }
                ActualizaTabla(modelo2, "%");
                ActualizaTabla(modelo, "C");
            }
            
        }

    }

    private void jButton2_actionPerformed(ActionEvent e) {
        if (dbd.DesconectaBD()) {
            jop.showMessageDialog(this, "La base de datos se cerr� correctamente","GCD",jop.INFORMATION_MESSAGE);
        } else {
            jop.showMessageDialog(this, "Ha sido imposible establecer la conexi�n con la base de datos","GCD",jop.ERROR_MESSAGE);
        }
    }

    private void jButton3_actionPerformed(ActionEvent e) {
        try {
            dbd.ConectaBD();
            jop.showMessageDialog(this, "Establecida la conexi�n con la base de datos","GCD",jop.INFORMATION_MESSAGE);
            ActualizaTabla(modelo, "C");
            ActualizaTabla(modelo2, "%");
            
        } catch (SQLException f) {
             jop.showMessageDialog(this, "Hubo un error al conectar con la base de datos","GCD",jop.ERROR_MESSAGE);
        }
    }
}
