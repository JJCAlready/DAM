package accesogcd;

import javax.swing.table.DefaultTableModel;

// Extendemos el DefaultTableModel para poder hacer las tablas no editables en todas sus celdas
public class ModeloTabla extends DefaultTableModel {
    public boolean isCellEditable (int row, int column)
    {
      return false;
    }
}
