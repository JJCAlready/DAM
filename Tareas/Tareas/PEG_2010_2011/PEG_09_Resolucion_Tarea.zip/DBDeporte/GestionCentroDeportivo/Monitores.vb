Public Class Monitores
    ''' <summary>
    ''' Guardamos los cambios, tanto del maestro (tabla MONITORES)como del detalle (tabla GRUPOS)
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>El c�digo generado por Microsoft Visual Basic 2005 Express solo guarda los cambios del maestro</remarks>
    Private Sub MONITORESBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MONITORESBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.MONITORESBindingSource.EndEdit()
        Me.MONITORESTableAdapter.Update(Me.DBDeporteDataSet.MONITORES)
        Me.GRUPOSBindingSource.EndEdit()
        Me.GRUPOSTableAdapter.Update(Me.DBDeporteDataSet.GRUPOS)

    End Sub

    Private Sub Monitores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.ACTIVIDADES' Puede moverla o quitarla seg�n sea necesario.
        Me.ACTIVIDADESTableAdapter.Fill(Me.DBDeporteDataSet.ACTIVIDADES)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.INSTALACIONES' Puede moverla o quitarla seg�n sea necesario.
        Me.INSTALACIONESTableAdapter.Fill(Me.DBDeporteDataSet.INSTALACIONES)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.GRUPOS' Puede moverla o quitarla seg�n sea necesario.
        Me.GRUPOSTableAdapter.Fill(Me.DBDeporteDataSet.GRUPOS)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.MONITORES' Puede moverla o quitarla seg�n sea necesario.
        Me.MONITORESTableAdapter.Fill(Me.DBDeporteDataSet.MONITORES)

    End Sub

End Class