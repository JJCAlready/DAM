Public Class Instalaciones

    Private Sub INSTALACIONESBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles INSTALACIONESBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.INSTALACIONESBindingSource.EndEdit()
        Me.INSTALACIONESTableAdapter.Update(Me.DBDeporteDataSet.INSTALACIONES)

    End Sub

    Private Sub Instalaciones_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.INSTALACIONES' Puede moverla o quitarla seg�n sea necesario.
        Me.INSTALACIONESTableAdapter.Fill(Me.DBDeporteDataSet.INSTALACIONES)

    End Sub
End Class