<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Monitores
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IDMONITORLabel As System.Windows.Forms.Label
        Dim NOMBRELabel As System.Windows.Forms.Label
        Dim APELLIDOSLabel As System.Windows.Forms.Label
        Dim DNILabel As System.Windows.Forms.Label
        Dim DOMICILIOLabel As System.Windows.Forms.Label
        Dim POBLACIONLabel As System.Windows.Forms.Label
        Dim TELEFONOLabel As System.Windows.Forms.Label
        Dim TITULACIONLabel As System.Windows.Forms.Label
        Dim CARGOLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Monitores))
        Me.DBDeporteDataSet = New GestionCentroDeportivo.DBDeporteDataSet
        Me.MONITORESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MONITORESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
        Me.MONITORESBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.MONITORESBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.IDMONITORLabel1 = New System.Windows.Forms.Label
        Me.NOMBRETextBox = New System.Windows.Forms.TextBox
        Me.APELLIDOSTextBox = New System.Windows.Forms.TextBox
        Me.DNITextBox = New System.Windows.Forms.TextBox
        Me.DOMICILIOTextBox = New System.Windows.Forms.TextBox
        Me.POBLACIONTextBox = New System.Windows.Forms.TextBox
        Me.TELEFONOTextBox = New System.Windows.Forms.TextBox
        Me.TITULACIONTextBox = New System.Windows.Forms.TextBox
        Me.CARGOTextBox = New System.Windows.Forms.TextBox
        Me.GRUPOSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GRUPOSTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.GRUPOSTableAdapter
        Me.GRUPOSDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NOMBRE = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.INSTALACIONESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.ACTIVIDADESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.INSTALACIONESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
        Me.ACTIVIDADESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
        Me.GRUPOSBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        IDMONITORLabel = New System.Windows.Forms.Label
        NOMBRELabel = New System.Windows.Forms.Label
        APELLIDOSLabel = New System.Windows.Forms.Label
        DNILabel = New System.Windows.Forms.Label
        DOMICILIOLabel = New System.Windows.Forms.Label
        POBLACIONLabel = New System.Windows.Forms.Label
        TELEFONOLabel = New System.Windows.Forms.Label
        TITULACIONLabel = New System.Windows.Forms.Label
        CARGOLabel = New System.Windows.Forms.Label
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MONITORESBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MONITORESBindingNavigator.SuspendLayout()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDMONITORLabel
        '
        IDMONITORLabel.AutoSize = True
        IDMONITORLabel.Location = New System.Drawing.Point(20, 51)
        IDMONITORLabel.Name = "IDMONITORLabel"
        IDMONITORLabel.Size = New System.Drawing.Size(72, 13)
        IDMONITORLabel.TabIndex = 1
        IDMONITORLabel.Text = "IDMONITOR:"
        '
        'NOMBRELabel
        '
        NOMBRELabel.AutoSize = True
        NOMBRELabel.Location = New System.Drawing.Point(20, 80)
        NOMBRELabel.Name = "NOMBRELabel"
        NOMBRELabel.Size = New System.Drawing.Size(57, 13)
        NOMBRELabel.TabIndex = 3
        NOMBRELabel.Text = "NOMBRE:"
        '
        'APELLIDOSLabel
        '
        APELLIDOSLabel.AutoSize = True
        APELLIDOSLabel.Location = New System.Drawing.Point(268, 83)
        APELLIDOSLabel.Name = "APELLIDOSLabel"
        APELLIDOSLabel.Size = New System.Drawing.Size(69, 13)
        APELLIDOSLabel.TabIndex = 5
        APELLIDOSLabel.Text = "APELLIDOS:"
        '
        'DNILabel
        '
        DNILabel.AutoSize = True
        DNILabel.Location = New System.Drawing.Point(268, 51)
        DNILabel.Name = "DNILabel"
        DNILabel.Size = New System.Drawing.Size(29, 13)
        DNILabel.TabIndex = 7
        DNILabel.Text = "DNI:"
        '
        'DOMICILIOLabel
        '
        DOMICILIOLabel.AutoSize = True
        DOMICILIOLabel.Location = New System.Drawing.Point(20, 114)
        DOMICILIOLabel.Name = "DOMICILIOLabel"
        DOMICILIOLabel.Size = New System.Drawing.Size(65, 13)
        DOMICILIOLabel.TabIndex = 9
        DOMICILIOLabel.Text = "DOMICILIO:"
        '
        'POBLACIONLabel
        '
        POBLACIONLabel.AutoSize = True
        POBLACIONLabel.Location = New System.Drawing.Point(20, 150)
        POBLACIONLabel.Name = "POBLACIONLabel"
        POBLACIONLabel.Size = New System.Drawing.Size(71, 13)
        POBLACIONLabel.TabIndex = 11
        POBLACIONLabel.Text = "POBLACION:"
        '
        'TELEFONOLabel
        '
        TELEFONOLabel.AutoSize = True
        TELEFONOLabel.Location = New System.Drawing.Point(268, 147)
        TELEFONOLabel.Name = "TELEFONOLabel"
        TELEFONOLabel.Size = New System.Drawing.Size(67, 13)
        TELEFONOLabel.TabIndex = 13
        TELEFONOLabel.Text = "TELEFONO:"
        '
        'TITULACIONLabel
        '
        TITULACIONLabel.AutoSize = True
        TITULACIONLabel.Location = New System.Drawing.Point(20, 184)
        TITULACIONLabel.Name = "TITULACIONLabel"
        TITULACIONLabel.Size = New System.Drawing.Size(74, 13)
        TITULACIONLabel.TabIndex = 15
        TITULACIONLabel.Text = "TITULACION:"
        '
        'CARGOLabel
        '
        CARGOLabel.AutoSize = True
        CARGOLabel.Location = New System.Drawing.Point(268, 180)
        CARGOLabel.Name = "CARGOLabel"
        CARGOLabel.Size = New System.Drawing.Size(48, 13)
        CARGOLabel.TabIndex = 17
        CARGOLabel.Text = "CARGO:"
        '
        'DBDeporteDataSet
        '
        Me.DBDeporteDataSet.DataSetName = "DBDeporteDataSet"
        Me.DBDeporteDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MONITORESBindingSource
        '
        Me.MONITORESBindingSource.DataMember = "MONITORES"
        Me.MONITORESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'MONITORESTableAdapter
        '
        Me.MONITORESTableAdapter.ClearBeforeFill = True
        '
        'MONITORESBindingNavigator
        '
        Me.MONITORESBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.MONITORESBindingNavigator.BindingSource = Me.MONITORESBindingSource
        Me.MONITORESBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.MONITORESBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.MONITORESBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.MONITORESBindingNavigatorSaveItem})
        Me.MONITORESBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.MONITORESBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.MONITORESBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.MONITORESBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.MONITORESBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.MONITORESBindingNavigator.Name = "MONITORESBindingNavigator"
        Me.MONITORESBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.MONITORESBindingNavigator.Size = New System.Drawing.Size(791, 25)
        Me.MONITORESBindingNavigator.TabIndex = 0
        Me.MONITORESBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'MONITORESBindingNavigatorSaveItem
        '
        Me.MONITORESBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MONITORESBindingNavigatorSaveItem.Image = CType(resources.GetObject("MONITORESBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.MONITORESBindingNavigatorSaveItem.Name = "MONITORESBindingNavigatorSaveItem"
        Me.MONITORESBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.MONITORESBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'IDMONITORLabel1
        '
        Me.IDMONITORLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "IDMONITOR", True))
        Me.IDMONITORLabel1.Location = New System.Drawing.Point(145, 51)
        Me.IDMONITORLabel1.Name = "IDMONITORLabel1"
        Me.IDMONITORLabel1.Size = New System.Drawing.Size(100, 23)
        Me.IDMONITORLabel1.TabIndex = 2
        '
        'NOMBRETextBox
        '
        Me.NOMBRETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "NOMBRE", True))
        Me.NOMBRETextBox.Location = New System.Drawing.Point(145, 77)
        Me.NOMBRETextBox.Name = "NOMBRETextBox"
        Me.NOMBRETextBox.Size = New System.Drawing.Size(100, 20)
        Me.NOMBRETextBox.TabIndex = 4
        '
        'APELLIDOSTextBox
        '
        Me.APELLIDOSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "APELLIDOS", True))
        Me.APELLIDOSTextBox.Location = New System.Drawing.Point(393, 80)
        Me.APELLIDOSTextBox.Name = "APELLIDOSTextBox"
        Me.APELLIDOSTextBox.Size = New System.Drawing.Size(100, 20)
        Me.APELLIDOSTextBox.TabIndex = 6
        '
        'DNITextBox
        '
        Me.DNITextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "DNI", True))
        Me.DNITextBox.Location = New System.Drawing.Point(393, 48)
        Me.DNITextBox.Name = "DNITextBox"
        Me.DNITextBox.Size = New System.Drawing.Size(100, 20)
        Me.DNITextBox.TabIndex = 8
        '
        'DOMICILIOTextBox
        '
        Me.DOMICILIOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "DOMICILIO", True))
        Me.DOMICILIOTextBox.Location = New System.Drawing.Point(145, 111)
        Me.DOMICILIOTextBox.Name = "DOMICILIOTextBox"
        Me.DOMICILIOTextBox.Size = New System.Drawing.Size(348, 20)
        Me.DOMICILIOTextBox.TabIndex = 10
        '
        'POBLACIONTextBox
        '
        Me.POBLACIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "POBLACION", True))
        Me.POBLACIONTextBox.Location = New System.Drawing.Point(145, 147)
        Me.POBLACIONTextBox.Name = "POBLACIONTextBox"
        Me.POBLACIONTextBox.Size = New System.Drawing.Size(100, 20)
        Me.POBLACIONTextBox.TabIndex = 12
        '
        'TELEFONOTextBox
        '
        Me.TELEFONOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "TELEFONO", True))
        Me.TELEFONOTextBox.Location = New System.Drawing.Point(393, 144)
        Me.TELEFONOTextBox.Name = "TELEFONOTextBox"
        Me.TELEFONOTextBox.Size = New System.Drawing.Size(100, 20)
        Me.TELEFONOTextBox.TabIndex = 14
        '
        'TITULACIONTextBox
        '
        Me.TITULACIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "TITULACION", True))
        Me.TITULACIONTextBox.Location = New System.Drawing.Point(145, 181)
        Me.TITULACIONTextBox.Name = "TITULACIONTextBox"
        Me.TITULACIONTextBox.Size = New System.Drawing.Size(100, 20)
        Me.TITULACIONTextBox.TabIndex = 16
        '
        'CARGOTextBox
        '
        Me.CARGOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MONITORESBindingSource, "CARGO", True))
        Me.CARGOTextBox.Location = New System.Drawing.Point(393, 177)
        Me.CARGOTextBox.Name = "CARGOTextBox"
        Me.CARGOTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CARGOTextBox.TabIndex = 18
        '
        'GRUPOSBindingSource
        '
        Me.GRUPOSBindingSource.DataMember = "FK__GRUPOS__IDMONITO__09DE7BCC"
        Me.GRUPOSBindingSource.DataSource = Me.MONITORESBindingSource
        '
        'GRUPOSTableAdapter
        '
        Me.GRUPOSTableAdapter.ClearBeforeFill = True
        '
        'GRUPOSDataGridView
        '
        Me.GRUPOSDataGridView.AutoGenerateColumns = False
        Me.GRUPOSDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.NOMBRE, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn4})
        Me.GRUPOSDataGridView.DataSource = Me.GRUPOSBindingSource
        Me.GRUPOSDataGridView.Location = New System.Drawing.Point(23, 260)
        Me.GRUPOSDataGridView.Name = "GRUPOSDataGridView"
        Me.GRUPOSDataGridView.Size = New System.Drawing.Size(745, 188)
        Me.GRUPOSDataGridView.TabIndex = 19
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "IDGRUPO"
        Me.DataGridViewTextBoxColumn1.HeaderText = "IDGRUPO"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'NOMBRE
        '
        Me.NOMBRE.DataPropertyName = "NOMBRE"
        Me.NOMBRE.HeaderText = "NOMBRE"
        Me.NOMBRE.Name = "NOMBRE"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "CODIGOINSTALACION"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.INSTALACIONESBindingSource
        Me.DataGridViewTextBoxColumn2.DisplayMember = "DENOMINACION"
        Me.DataGridViewTextBoxColumn2.HeaderText = "INSTALACION"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "CODIGOINSTALACION"
        '
        'INSTALACIONESBindingSource
        '
        Me.INSTALACIONESBindingSource.DataMember = "INSTALACIONES"
        Me.INSTALACIONESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "COSACTIVIDAD"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.ACTIVIDADESBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "TITULO"
        Me.DataGridViewTextBoxColumn3.HeaderText = "ACTIVIDAD"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "COSACTIVIDAD"
        '
        'ACTIVIDADESBindingSource
        '
        Me.ACTIVIDADESBindingSource.DataMember = "ACTIVIDADES"
        Me.ACTIVIDADESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "HORARIO"
        Me.DataGridViewTextBoxColumn6.HeaderText = "HORARIO"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "ESTADO"
        Me.DataGridViewTextBoxColumn7.HeaderText = "ESTADO"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "PRECIO"
        Me.DataGridViewTextBoxColumn8.HeaderText = "PRECIO"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "NMIN"
        Me.DataGridViewTextBoxColumn9.HeaderText = "NMIN"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "NMAX"
        Me.DataGridViewTextBoxColumn10.HeaderText = "NMAX"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "NOMBRE"
        Me.DataGridViewTextBoxColumn4.HeaderText = "NOMBRE"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'INSTALACIONESTableAdapter
        '
        Me.INSTALACIONESTableAdapter.ClearBeforeFill = True
        '
        'ACTIVIDADESTableAdapter
        '
        Me.ACTIVIDADESTableAdapter.ClearBeforeFill = True
        '
        'GRUPOSBindingSource1
        '
        Me.GRUPOSBindingSource1.DataMember = "GRUPOS"
        Me.GRUPOSBindingSource1.DataSource = Me.DBDeporteDataSet
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 241)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Grupos que dirige este monitor:"
        '
        'Monitores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(791, 468)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GRUPOSDataGridView)
        Me.Controls.Add(IDMONITORLabel)
        Me.Controls.Add(Me.IDMONITORLabel1)
        Me.Controls.Add(NOMBRELabel)
        Me.Controls.Add(Me.NOMBRETextBox)
        Me.Controls.Add(APELLIDOSLabel)
        Me.Controls.Add(Me.APELLIDOSTextBox)
        Me.Controls.Add(DNILabel)
        Me.Controls.Add(Me.DNITextBox)
        Me.Controls.Add(DOMICILIOLabel)
        Me.Controls.Add(Me.DOMICILIOTextBox)
        Me.Controls.Add(POBLACIONLabel)
        Me.Controls.Add(Me.POBLACIONTextBox)
        Me.Controls.Add(TELEFONOLabel)
        Me.Controls.Add(Me.TELEFONOTextBox)
        Me.Controls.Add(TITULACIONLabel)
        Me.Controls.Add(Me.TITULACIONTextBox)
        Me.Controls.Add(CARGOLabel)
        Me.Controls.Add(Me.CARGOTextBox)
        Me.Controls.Add(Me.MONITORESBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Monitores"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Monitores"
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MONITORESBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MONITORESBindingNavigator.ResumeLayout(False)
        Me.MONITORESBindingNavigator.PerformLayout()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DBDeporteDataSet As GestionCentroDeportivo.DBDeporteDataSet
    Friend WithEvents MONITORESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MONITORESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
    Friend WithEvents MONITORESBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MONITORESBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IDMONITORLabel1 As System.Windows.Forms.Label
    Friend WithEvents NOMBRETextBox As System.Windows.Forms.TextBox
    Friend WithEvents APELLIDOSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DNITextBox As System.Windows.Forms.TextBox
    Friend WithEvents DOMICILIOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents POBLACIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TELEFONOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TITULACIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CARGOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GRUPOSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GRUPOSTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.GRUPOSTableAdapter
    Friend WithEvents GRUPOSDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents INSTALACIONESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents INSTALACIONESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
    Friend WithEvents ACTIVIDADESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ACTIVIDADESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
    Friend WithEvents GRUPOSBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NOMBRE As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
