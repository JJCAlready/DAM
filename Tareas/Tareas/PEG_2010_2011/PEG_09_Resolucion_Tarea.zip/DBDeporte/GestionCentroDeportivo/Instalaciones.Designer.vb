<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Instalaciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim CODIGOINSTALACIONLabel As System.Windows.Forms.Label
        Dim DENOMINACIONLabel As System.Windows.Forms.Label
        Dim SITUACIONLabel As System.Windows.Forms.Label
        Dim CARACTERISTICASLabel As System.Windows.Forms.Label
        Dim DISPONIBLELabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Instalaciones))
        Me.INSTALACIONESBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.INSTALACIONESBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.CODIGOINSTALACIONLabel1 = New System.Windows.Forms.Label
        Me.DENOMINACIONTextBox = New System.Windows.Forms.TextBox
        Me.SITUACIONTextBox = New System.Windows.Forms.TextBox
        Me.CARACTERISTICASTextBox = New System.Windows.Forms.TextBox
        Me.DISPONIBLETextBox = New System.Windows.Forms.TextBox
        Me.INSTALACIONESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DBDeporteDataSet = New GestionCentroDeportivo.DBDeporteDataSet
        Me.INSTALACIONESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
        CODIGOINSTALACIONLabel = New System.Windows.Forms.Label
        DENOMINACIONLabel = New System.Windows.Forms.Label
        SITUACIONLabel = New System.Windows.Forms.Label
        CARACTERISTICASLabel = New System.Windows.Forms.Label
        DISPONIBLELabel = New System.Windows.Forms.Label
        CType(Me.INSTALACIONESBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.INSTALACIONESBindingNavigator.SuspendLayout()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CODIGOINSTALACIONLabel
        '
        CODIGOINSTALACIONLabel.AutoSize = True
        CODIGOINSTALACIONLabel.Location = New System.Drawing.Point(18, 54)
        CODIGOINSTALACIONLabel.Name = "CODIGOINSTALACIONLabel"
        CODIGOINSTALACIONLabel.Size = New System.Drawing.Size(123, 13)
        CODIGOINSTALACIONLabel.TabIndex = 1
        CODIGOINSTALACIONLabel.Text = "CODIGOINSTALACION:"
        '
        'DENOMINACIONLabel
        '
        DENOMINACIONLabel.AutoSize = True
        DENOMINACIONLabel.Location = New System.Drawing.Point(18, 83)
        DENOMINACIONLabel.Name = "DENOMINACIONLabel"
        DENOMINACIONLabel.Size = New System.Drawing.Size(94, 13)
        DENOMINACIONLabel.TabIndex = 3
        DENOMINACIONLabel.Text = "DENOMINACION:"
        '
        'SITUACIONLabel
        '
        SITUACIONLabel.AutoSize = True
        SITUACIONLabel.Location = New System.Drawing.Point(18, 109)
        SITUACIONLabel.Name = "SITUACIONLabel"
        SITUACIONLabel.Size = New System.Drawing.Size(68, 13)
        SITUACIONLabel.TabIndex = 5
        SITUACIONLabel.Text = "SITUACION:"
        '
        'CARACTERISTICASLabel
        '
        CARACTERISTICASLabel.AutoSize = True
        CARACTERISTICASLabel.Location = New System.Drawing.Point(18, 135)
        CARACTERISTICASLabel.Name = "CARACTERISTICASLabel"
        CARACTERISTICASLabel.Size = New System.Drawing.Size(109, 13)
        CARACTERISTICASLabel.TabIndex = 7
        CARACTERISTICASLabel.Text = "CARACTERISTICAS:"
        '
        'DISPONIBLELabel
        '
        DISPONIBLELabel.AutoSize = True
        DISPONIBLELabel.Location = New System.Drawing.Point(18, 161)
        DISPONIBLELabel.Name = "DISPONIBLELabel"
        DISPONIBLELabel.Size = New System.Drawing.Size(74, 13)
        DISPONIBLELabel.TabIndex = 9
        DISPONIBLELabel.Text = "DISPONIBLE:"
        '
        'INSTALACIONESBindingNavigator
        '
        Me.INSTALACIONESBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.INSTALACIONESBindingNavigator.BindingSource = Me.INSTALACIONESBindingSource
        Me.INSTALACIONESBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.INSTALACIONESBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.INSTALACIONESBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.INSTALACIONESBindingNavigatorSaveItem})
        Me.INSTALACIONESBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.INSTALACIONESBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.INSTALACIONESBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.INSTALACIONESBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.INSTALACIONESBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.INSTALACIONESBindingNavigator.Name = "INSTALACIONESBindingNavigator"
        Me.INSTALACIONESBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.INSTALACIONESBindingNavigator.Size = New System.Drawing.Size(399, 25)
        Me.INSTALACIONESBindingNavigator.TabIndex = 0
        Me.INSTALACIONESBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'INSTALACIONESBindingNavigatorSaveItem
        '
        Me.INSTALACIONESBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.INSTALACIONESBindingNavigatorSaveItem.Image = CType(resources.GetObject("INSTALACIONESBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.INSTALACIONESBindingNavigatorSaveItem.Name = "INSTALACIONESBindingNavigatorSaveItem"
        Me.INSTALACIONESBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.INSTALACIONESBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'CODIGOINSTALACIONLabel1
        '
        Me.CODIGOINSTALACIONLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.INSTALACIONESBindingSource, "CODIGOINSTALACION", True))
        Me.CODIGOINSTALACIONLabel1.Location = New System.Drawing.Point(147, 54)
        Me.CODIGOINSTALACIONLabel1.Name = "CODIGOINSTALACIONLabel1"
        Me.CODIGOINSTALACIONLabel1.Size = New System.Drawing.Size(240, 23)
        Me.CODIGOINSTALACIONLabel1.TabIndex = 2
        '
        'DENOMINACIONTextBox
        '
        Me.DENOMINACIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.INSTALACIONESBindingSource, "DENOMINACION", True))
        Me.DENOMINACIONTextBox.Location = New System.Drawing.Point(147, 80)
        Me.DENOMINACIONTextBox.Name = "DENOMINACIONTextBox"
        Me.DENOMINACIONTextBox.Size = New System.Drawing.Size(240, 20)
        Me.DENOMINACIONTextBox.TabIndex = 4
        '
        'SITUACIONTextBox
        '
        Me.SITUACIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.INSTALACIONESBindingSource, "SITUACION", True))
        Me.SITUACIONTextBox.Location = New System.Drawing.Point(147, 106)
        Me.SITUACIONTextBox.Name = "SITUACIONTextBox"
        Me.SITUACIONTextBox.Size = New System.Drawing.Size(240, 20)
        Me.SITUACIONTextBox.TabIndex = 6
        '
        'CARACTERISTICASTextBox
        '
        Me.CARACTERISTICASTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.INSTALACIONESBindingSource, "CARACTERISTICAS", True))
        Me.CARACTERISTICASTextBox.Location = New System.Drawing.Point(147, 132)
        Me.CARACTERISTICASTextBox.Name = "CARACTERISTICASTextBox"
        Me.CARACTERISTICASTextBox.Size = New System.Drawing.Size(240, 20)
        Me.CARACTERISTICASTextBox.TabIndex = 8
        '
        'DISPONIBLETextBox
        '
        Me.DISPONIBLETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.INSTALACIONESBindingSource, "DISPONIBLE", True))
        Me.DISPONIBLETextBox.Location = New System.Drawing.Point(147, 158)
        Me.DISPONIBLETextBox.Name = "DISPONIBLETextBox"
        Me.DISPONIBLETextBox.Size = New System.Drawing.Size(240, 20)
        Me.DISPONIBLETextBox.TabIndex = 10
        '
        'INSTALACIONESBindingSource
        '
        Me.INSTALACIONESBindingSource.DataMember = "INSTALACIONES"
        Me.INSTALACIONESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DBDeporteDataSet
        '
        Me.DBDeporteDataSet.DataSetName = "DBDeporteDataSet"
        Me.DBDeporteDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'INSTALACIONESTableAdapter
        '
        Me.INSTALACIONESTableAdapter.ClearBeforeFill = True
        '
        'Instalaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(399, 198)
        Me.Controls.Add(CODIGOINSTALACIONLabel)
        Me.Controls.Add(Me.CODIGOINSTALACIONLabel1)
        Me.Controls.Add(DENOMINACIONLabel)
        Me.Controls.Add(Me.DENOMINACIONTextBox)
        Me.Controls.Add(SITUACIONLabel)
        Me.Controls.Add(Me.SITUACIONTextBox)
        Me.Controls.Add(CARACTERISTICASLabel)
        Me.Controls.Add(Me.CARACTERISTICASTextBox)
        Me.Controls.Add(DISPONIBLELabel)
        Me.Controls.Add(Me.DISPONIBLETextBox)
        Me.Controls.Add(Me.INSTALACIONESBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Instalaciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Instalaciones"
        CType(Me.INSTALACIONESBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.INSTALACIONESBindingNavigator.ResumeLayout(False)
        Me.INSTALACIONESBindingNavigator.PerformLayout()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DBDeporteDataSet As GestionCentroDeportivo.DBDeporteDataSet
    Friend WithEvents INSTALACIONESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents INSTALACIONESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
    Friend WithEvents INSTALACIONESBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents INSTALACIONESBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents CODIGOINSTALACIONLabel1 As System.Windows.Forms.Label
    Friend WithEvents DENOMINACIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SITUACIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CARACTERISTICASTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DISPONIBLETextBox As System.Windows.Forms.TextBox
End Class
