<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Socios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IDSOCIOLabel As System.Windows.Forms.Label
        Dim NOMBRELabel As System.Windows.Forms.Label
        Dim APELLIDOSLabel As System.Windows.Forms.Label
        Dim DNILabel As System.Windows.Forms.Label
        Dim FECHA_NACIMIENTOLabel As System.Windows.Forms.Label
        Dim EDADLabel As System.Windows.Forms.Label
        Dim DOMICILIOLabel As System.Windows.Forms.Label
        Dim CPLabel As System.Windows.Forms.Label
        Dim POBLACIONLabel As System.Windows.Forms.Label
        Dim TELEFONOLabel As System.Windows.Forms.Label
        Dim FECHADEALTALabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Socios))
        Me.DBDeporteDataSet1 = New GestionCentroDeportivo.DBDeporteDataSet1
        Me.SOCIOSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SOCIOSTableAdapter = New GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.SOCIOSTableAdapter
        Me.SOCIOSBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.SOCIOSBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.NOMBRETextBox = New System.Windows.Forms.TextBox
        Me.APELLIDOSTextBox = New System.Windows.Forms.TextBox
        Me.DNITextBox = New System.Windows.Forms.TextBox
        Me.FECHA_NACIMIENTODateTimePicker = New System.Windows.Forms.DateTimePicker
        Me.EDADTextBox = New System.Windows.Forms.TextBox
        Me.DOMICILIOTextBox = New System.Windows.Forms.TextBox
        Me.CPTextBox = New System.Windows.Forms.TextBox
        Me.POBLACIONTextBox = New System.Windows.Forms.TextBox
        Me.TELEFONOTextBox = New System.Windows.Forms.TextBox
        Me.FECHADEALTADateTimePicker = New System.Windows.Forms.DateTimePicker
        Me.PARTICIPABindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PARTICIPATableAdapter = New GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.PARTICIPATableAdapter
        Me.PARTICIPADataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.GRUPOSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GRUPOSTableAdapter = New GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.GRUPOSTableAdapter
        Me.GRUPOSBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.GRUPOSDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.INSTALACIONESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DBDeporteDataSet = New GestionCentroDeportivo.DBDeporteDataSet
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.ACTIVIDADESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.MONITORESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.INSTALACIONESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
        Me.ACTIVIDADESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
        Me.MONITORESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
        Me.Label1 = New System.Windows.Forms.Label
        Me.IDSOCIOLabel2 = New System.Windows.Forms.Label
        IDSOCIOLabel = New System.Windows.Forms.Label
        NOMBRELabel = New System.Windows.Forms.Label
        APELLIDOSLabel = New System.Windows.Forms.Label
        DNILabel = New System.Windows.Forms.Label
        FECHA_NACIMIENTOLabel = New System.Windows.Forms.Label
        EDADLabel = New System.Windows.Forms.Label
        DOMICILIOLabel = New System.Windows.Forms.Label
        CPLabel = New System.Windows.Forms.Label
        POBLACIONLabel = New System.Windows.Forms.Label
        TELEFONOLabel = New System.Windows.Forms.Label
        FECHADEALTALabel = New System.Windows.Forms.Label
        CType(Me.DBDeporteDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SOCIOSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SOCIOSBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SOCIOSBindingNavigator.SuspendLayout()
        CType(Me.PARTICIPABindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PARTICIPADataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDSOCIOLabel
        '
        IDSOCIOLabel.AutoSize = True
        IDSOCIOLabel.Location = New System.Drawing.Point(20, 43)
        IDSOCIOLabel.Name = "IDSOCIOLabel"
        IDSOCIOLabel.Size = New System.Drawing.Size(54, 13)
        IDSOCIOLabel.TabIndex = 1
        IDSOCIOLabel.Text = "IDSOCIO:"
        '
        'NOMBRELabel
        '
        NOMBRELabel.AutoSize = True
        NOMBRELabel.Location = New System.Drawing.Point(20, 69)
        NOMBRELabel.Name = "NOMBRELabel"
        NOMBRELabel.Size = New System.Drawing.Size(57, 13)
        NOMBRELabel.TabIndex = 3
        NOMBRELabel.Text = "NOMBRE:"
        '
        'APELLIDOSLabel
        '
        APELLIDOSLabel.AutoSize = True
        APELLIDOSLabel.Location = New System.Drawing.Point(20, 95)
        APELLIDOSLabel.Name = "APELLIDOSLabel"
        APELLIDOSLabel.Size = New System.Drawing.Size(69, 13)
        APELLIDOSLabel.TabIndex = 5
        APELLIDOSLabel.Text = "APELLIDOS:"
        '
        'DNILabel
        '
        DNILabel.AutoSize = True
        DNILabel.Location = New System.Drawing.Point(20, 121)
        DNILabel.Name = "DNILabel"
        DNILabel.Size = New System.Drawing.Size(29, 13)
        DNILabel.TabIndex = 7
        DNILabel.Text = "DNI:"
        '
        'FECHA_NACIMIENTOLabel
        '
        FECHA_NACIMIENTOLabel.AutoSize = True
        FECHA_NACIMIENTOLabel.Location = New System.Drawing.Point(20, 148)
        FECHA_NACIMIENTOLabel.Name = "FECHA_NACIMIENTOLabel"
        FECHA_NACIMIENTOLabel.Size = New System.Drawing.Size(115, 13)
        FECHA_NACIMIENTOLabel.TabIndex = 9
        FECHA_NACIMIENTOLabel.Text = "FECHA NACIMIENTO:"
        '
        'EDADLabel
        '
        EDADLabel.AutoSize = True
        EDADLabel.Location = New System.Drawing.Point(20, 173)
        EDADLabel.Name = "EDADLabel"
        EDADLabel.Size = New System.Drawing.Size(40, 13)
        EDADLabel.TabIndex = 11
        EDADLabel.Text = "EDAD:"
        '
        'DOMICILIOLabel
        '
        DOMICILIOLabel.AutoSize = True
        DOMICILIOLabel.Location = New System.Drawing.Point(20, 199)
        DOMICILIOLabel.Name = "DOMICILIOLabel"
        DOMICILIOLabel.Size = New System.Drawing.Size(65, 13)
        DOMICILIOLabel.TabIndex = 13
        DOMICILIOLabel.Text = "DOMICILIO:"
        '
        'CPLabel
        '
        CPLabel.AutoSize = True
        CPLabel.Location = New System.Drawing.Point(20, 225)
        CPLabel.Name = "CPLabel"
        CPLabel.Size = New System.Drawing.Size(24, 13)
        CPLabel.TabIndex = 15
        CPLabel.Text = "CP:"
        '
        'POBLACIONLabel
        '
        POBLACIONLabel.AutoSize = True
        POBLACIONLabel.Location = New System.Drawing.Point(20, 251)
        POBLACIONLabel.Name = "POBLACIONLabel"
        POBLACIONLabel.Size = New System.Drawing.Size(71, 13)
        POBLACIONLabel.TabIndex = 17
        POBLACIONLabel.Text = "POBLACION:"
        '
        'TELEFONOLabel
        '
        TELEFONOLabel.AutoSize = True
        TELEFONOLabel.Location = New System.Drawing.Point(20, 277)
        TELEFONOLabel.Name = "TELEFONOLabel"
        TELEFONOLabel.Size = New System.Drawing.Size(67, 13)
        TELEFONOLabel.TabIndex = 19
        TELEFONOLabel.Text = "TELEFONO:"
        '
        'FECHADEALTALabel
        '
        FECHADEALTALabel.AutoSize = True
        FECHADEALTALabel.Location = New System.Drawing.Point(20, 304)
        FECHADEALTALabel.Name = "FECHADEALTALabel"
        FECHADEALTALabel.Size = New System.Drawing.Size(87, 13)
        FECHADEALTALabel.TabIndex = 21
        FECHADEALTALabel.Text = "FECHADEALTA:"
        '
        'DBDeporteDataSet1
        '
        Me.DBDeporteDataSet1.DataSetName = "DBDeporteDataSet1"
        Me.DBDeporteDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SOCIOSBindingSource
        '
        Me.SOCIOSBindingSource.DataMember = "SOCIOS"
        Me.SOCIOSBindingSource.DataSource = Me.DBDeporteDataSet1
        '
        'SOCIOSTableAdapter
        '
        Me.SOCIOSTableAdapter.ClearBeforeFill = True
        '
        'SOCIOSBindingNavigator
        '
        Me.SOCIOSBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.SOCIOSBindingNavigator.BindingSource = Me.SOCIOSBindingSource
        Me.SOCIOSBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.SOCIOSBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.SOCIOSBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.SOCIOSBindingNavigatorSaveItem})
        Me.SOCIOSBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.SOCIOSBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.SOCIOSBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.SOCIOSBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.SOCIOSBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.SOCIOSBindingNavigator.Name = "SOCIOSBindingNavigator"
        Me.SOCIOSBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.SOCIOSBindingNavigator.Size = New System.Drawing.Size(687, 25)
        Me.SOCIOSBindingNavigator.TabIndex = 0
        Me.SOCIOSBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'SOCIOSBindingNavigatorSaveItem
        '
        Me.SOCIOSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SOCIOSBindingNavigatorSaveItem.Image = CType(resources.GetObject("SOCIOSBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.SOCIOSBindingNavigatorSaveItem.Name = "SOCIOSBindingNavigatorSaveItem"
        Me.SOCIOSBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.SOCIOSBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'NOMBRETextBox
        '
        Me.NOMBRETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "NOMBRE", True))
        Me.NOMBRETextBox.Location = New System.Drawing.Point(141, 66)
        Me.NOMBRETextBox.Name = "NOMBRETextBox"
        Me.NOMBRETextBox.Size = New System.Drawing.Size(200, 20)
        Me.NOMBRETextBox.TabIndex = 4
        '
        'APELLIDOSTextBox
        '
        Me.APELLIDOSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "APELLIDOS", True))
        Me.APELLIDOSTextBox.Location = New System.Drawing.Point(141, 92)
        Me.APELLIDOSTextBox.Name = "APELLIDOSTextBox"
        Me.APELLIDOSTextBox.Size = New System.Drawing.Size(200, 20)
        Me.APELLIDOSTextBox.TabIndex = 6
        '
        'DNITextBox
        '
        Me.DNITextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "DNI", True))
        Me.DNITextBox.Location = New System.Drawing.Point(141, 118)
        Me.DNITextBox.Name = "DNITextBox"
        Me.DNITextBox.Size = New System.Drawing.Size(200, 20)
        Me.DNITextBox.TabIndex = 8
        '
        'FECHA_NACIMIENTODateTimePicker
        '
        Me.FECHA_NACIMIENTODateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.SOCIOSBindingSource, "FECHA_NACIMIENTO", True))
        Me.FECHA_NACIMIENTODateTimePicker.Location = New System.Drawing.Point(141, 144)
        Me.FECHA_NACIMIENTODateTimePicker.Name = "FECHA_NACIMIENTODateTimePicker"
        Me.FECHA_NACIMIENTODateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.FECHA_NACIMIENTODateTimePicker.TabIndex = 10
        '
        'EDADTextBox
        '
        Me.EDADTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "EDAD", True))
        Me.EDADTextBox.Location = New System.Drawing.Point(141, 170)
        Me.EDADTextBox.Name = "EDADTextBox"
        Me.EDADTextBox.Size = New System.Drawing.Size(200, 20)
        Me.EDADTextBox.TabIndex = 12
        '
        'DOMICILIOTextBox
        '
        Me.DOMICILIOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "DOMICILIO", True))
        Me.DOMICILIOTextBox.Location = New System.Drawing.Point(141, 196)
        Me.DOMICILIOTextBox.Name = "DOMICILIOTextBox"
        Me.DOMICILIOTextBox.Size = New System.Drawing.Size(200, 20)
        Me.DOMICILIOTextBox.TabIndex = 14
        '
        'CPTextBox
        '
        Me.CPTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "CP", True))
        Me.CPTextBox.Location = New System.Drawing.Point(141, 222)
        Me.CPTextBox.Name = "CPTextBox"
        Me.CPTextBox.Size = New System.Drawing.Size(200, 20)
        Me.CPTextBox.TabIndex = 16
        '
        'POBLACIONTextBox
        '
        Me.POBLACIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "POBLACION", True))
        Me.POBLACIONTextBox.Location = New System.Drawing.Point(141, 248)
        Me.POBLACIONTextBox.Name = "POBLACIONTextBox"
        Me.POBLACIONTextBox.Size = New System.Drawing.Size(200, 20)
        Me.POBLACIONTextBox.TabIndex = 18
        '
        'TELEFONOTextBox
        '
        Me.TELEFONOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "TELEFONO", True))
        Me.TELEFONOTextBox.Location = New System.Drawing.Point(141, 274)
        Me.TELEFONOTextBox.Name = "TELEFONOTextBox"
        Me.TELEFONOTextBox.Size = New System.Drawing.Size(200, 20)
        Me.TELEFONOTextBox.TabIndex = 20
        '
        'FECHADEALTADateTimePicker
        '
        Me.FECHADEALTADateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.SOCIOSBindingSource, "FECHADEALTA", True))
        Me.FECHADEALTADateTimePicker.Location = New System.Drawing.Point(141, 300)
        Me.FECHADEALTADateTimePicker.Name = "FECHADEALTADateTimePicker"
        Me.FECHADEALTADateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.FECHADEALTADateTimePicker.TabIndex = 22
        '
        'PARTICIPABindingSource
        '
        Me.PARTICIPABindingSource.DataMember = "FK__PARTICIPA__IDSOC__07F6335A"
        Me.PARTICIPABindingSource.DataSource = Me.SOCIOSBindingSource
        '
        'PARTICIPATableAdapter
        '
        Me.PARTICIPATableAdapter.ClearBeforeFill = True
        '
        'PARTICIPADataGridView
        '
        Me.PARTICIPADataGridView.AutoGenerateColumns = False
        Me.PARTICIPADataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2})
        Me.PARTICIPADataGridView.DataSource = Me.PARTICIPABindingSource
        Me.PARTICIPADataGridView.Location = New System.Drawing.Point(389, 38)
        Me.PARTICIPADataGridView.Name = "PARTICIPADataGridView"
        Me.PARTICIPADataGridView.Size = New System.Drawing.Size(273, 282)
        Me.PARTICIPADataGridView.TabIndex = 23
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "IDGRUPO"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.GRUPOSBindingSource
        Me.DataGridViewTextBoxColumn2.DisplayMember = "NOMBRE"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Participa en los grupos:"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "IDGRUPO"
        Me.DataGridViewTextBoxColumn2.Width = 230
        '
        'GRUPOSBindingSource
        '
        Me.GRUPOSBindingSource.DataMember = "GRUPOS"
        Me.GRUPOSBindingSource.DataSource = Me.DBDeporteDataSet1
        '
        'GRUPOSTableAdapter
        '
        Me.GRUPOSTableAdapter.ClearBeforeFill = True
        '
        'GRUPOSBindingSource1
        '
        Me.GRUPOSBindingSource1.DataMember = "FK__PARTICIPA__IDGRU__0BC6C43E"
        Me.GRUPOSBindingSource1.DataSource = Me.PARTICIPABindingSource
        '
        'GRUPOSDataGridView
        '
        Me.GRUPOSDataGridView.AllowUserToAddRows = False
        Me.GRUPOSDataGridView.AllowUserToDeleteRows = False
        Me.GRUPOSDataGridView.AutoGenerateColumns = False
        Me.GRUPOSDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11})
        Me.GRUPOSDataGridView.DataSource = Me.GRUPOSBindingSource1
        Me.GRUPOSDataGridView.Location = New System.Drawing.Point(23, 371)
        Me.GRUPOSDataGridView.Name = "GRUPOSDataGridView"
        Me.GRUPOSDataGridView.ReadOnly = True
        Me.GRUPOSDataGridView.Size = New System.Drawing.Size(639, 63)
        Me.GRUPOSDataGridView.TabIndex = 24
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "IDGRUPO"
        Me.DataGridViewTextBoxColumn1.HeaderText = "IDGRUPO"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "CODIGOINSTALACION"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.INSTALACIONESBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "DENOMINACION"
        Me.DataGridViewTextBoxColumn3.HeaderText = "INSTALACION"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "CODIGOINSTALACION"
        '
        'INSTALACIONESBindingSource
        '
        Me.INSTALACIONESBindingSource.DataMember = "INSTALACIONES"
        Me.INSTALACIONESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DBDeporteDataSet
        '
        Me.DBDeporteDataSet.DataSetName = "DBDeporteDataSet"
        Me.DBDeporteDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "COSACTIVIDAD"
        Me.DataGridViewTextBoxColumn4.DataSource = Me.ACTIVIDADESBindingSource
        Me.DataGridViewTextBoxColumn4.DisplayMember = "TITULO"
        Me.DataGridViewTextBoxColumn4.HeaderText = "ACTIVIDAD"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn4.ValueMember = "COSACTIVIDAD"
        '
        'ACTIVIDADESBindingSource
        '
        Me.ACTIVIDADESBindingSource.DataMember = "ACTIVIDADES"
        Me.ACTIVIDADESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "IDMONITOR"
        Me.DataGridViewTextBoxColumn5.DataSource = Me.MONITORESBindingSource
        Me.DataGridViewTextBoxColumn5.DisplayMember = "NOMBRE_COMPLETO"
        Me.DataGridViewTextBoxColumn5.HeaderText = "MONITOR"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn5.ToolTipText = "Monitor que dirige el grupo"
        Me.DataGridViewTextBoxColumn5.ValueMember = "IDMONITOR"
        '
        'MONITORESBindingSource
        '
        Me.MONITORESBindingSource.DataMember = "MONITORES"
        Me.MONITORESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "NOMBRE"
        Me.DataGridViewTextBoxColumn6.HeaderText = "NOMBRE"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "HORARIO"
        Me.DataGridViewTextBoxColumn7.HeaderText = "HORARIO"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "ESTADO"
        Me.DataGridViewTextBoxColumn8.HeaderText = "ESTADO"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "PRECIO"
        Me.DataGridViewTextBoxColumn9.HeaderText = "PRECIO"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "NMIN"
        Me.DataGridViewTextBoxColumn10.HeaderText = "NMIN"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "NMAX"
        Me.DataGridViewTextBoxColumn11.HeaderText = "NMAX"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'INSTALACIONESTableAdapter
        '
        Me.INSTALACIONESTableAdapter.ClearBeforeFill = True
        '
        'ACTIVIDADESTableAdapter
        '
        Me.ACTIVIDADESTableAdapter.ClearBeforeFill = True
        '
        'MONITORESTableAdapter
        '
        Me.MONITORESTableAdapter.ClearBeforeFill = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 355)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 13)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Descripción del grupo seleccionado:"
        '
        'IDSOCIOLabel2
        '
        Me.IDSOCIOLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SOCIOSBindingSource, "IDSOCIO", True))
        Me.IDSOCIOLabel2.Location = New System.Drawing.Point(138, 43)
        Me.IDSOCIOLabel2.Name = "IDSOCIOLabel2"
        Me.IDSOCIOLabel2.Size = New System.Drawing.Size(203, 18)
        Me.IDSOCIOLabel2.TabIndex = 26
        '
        'Socios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(687, 458)
        Me.Controls.Add(Me.IDSOCIOLabel2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GRUPOSDataGridView)
        Me.Controls.Add(Me.PARTICIPADataGridView)
        Me.Controls.Add(IDSOCIOLabel)
        Me.Controls.Add(NOMBRELabel)
        Me.Controls.Add(Me.NOMBRETextBox)
        Me.Controls.Add(APELLIDOSLabel)
        Me.Controls.Add(Me.APELLIDOSTextBox)
        Me.Controls.Add(DNILabel)
        Me.Controls.Add(Me.DNITextBox)
        Me.Controls.Add(FECHA_NACIMIENTOLabel)
        Me.Controls.Add(Me.FECHA_NACIMIENTODateTimePicker)
        Me.Controls.Add(EDADLabel)
        Me.Controls.Add(Me.EDADTextBox)
        Me.Controls.Add(DOMICILIOLabel)
        Me.Controls.Add(Me.DOMICILIOTextBox)
        Me.Controls.Add(CPLabel)
        Me.Controls.Add(Me.CPTextBox)
        Me.Controls.Add(POBLACIONLabel)
        Me.Controls.Add(Me.POBLACIONTextBox)
        Me.Controls.Add(TELEFONOLabel)
        Me.Controls.Add(Me.TELEFONOTextBox)
        Me.Controls.Add(FECHADEALTALabel)
        Me.Controls.Add(Me.FECHADEALTADateTimePicker)
        Me.Controls.Add(Me.SOCIOSBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Socios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Socios"
        CType(Me.DBDeporteDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SOCIOSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SOCIOSBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SOCIOSBindingNavigator.ResumeLayout(False)
        Me.SOCIOSBindingNavigator.PerformLayout()
        CType(Me.PARTICIPABindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PARTICIPADataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DBDeporteDataSet1 As GestionCentroDeportivo.DBDeporteDataSet1
    Friend WithEvents SOCIOSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SOCIOSTableAdapter As GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.SOCIOSTableAdapter
    Friend WithEvents SOCIOSBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SOCIOSBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents NOMBRETextBox As System.Windows.Forms.TextBox
    Friend WithEvents APELLIDOSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DNITextBox As System.Windows.Forms.TextBox
    Friend WithEvents FECHA_NACIMIENTODateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents EDADTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DOMICILIOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CPTextBox As System.Windows.Forms.TextBox
    Friend WithEvents POBLACIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TELEFONOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FECHADEALTADateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents PARTICIPABindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PARTICIPATableAdapter As GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.PARTICIPATableAdapter
    Friend WithEvents PARTICIPADataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents GRUPOSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GRUPOSTableAdapter As GestionCentroDeportivo.DBDeporteDataSet1TableAdapters.GRUPOSTableAdapter
    Friend WithEvents GRUPOSBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents GRUPOSDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DBDeporteDataSet As GestionCentroDeportivo.DBDeporteDataSet
    Friend WithEvents INSTALACIONESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents INSTALACIONESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
    Friend WithEvents ACTIVIDADESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ACTIVIDADESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
    Friend WithEvents MONITORESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MONITORESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents IDSOCIOLabel2 As System.Windows.Forms.Label
End Class
