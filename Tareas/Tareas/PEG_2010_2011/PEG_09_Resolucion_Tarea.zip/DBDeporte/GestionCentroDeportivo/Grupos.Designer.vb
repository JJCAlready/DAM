<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Grupos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IDGRUPOLabel As System.Windows.Forms.Label
        Dim CODIGOINSTALACIONLabel As System.Windows.Forms.Label
        Dim COSACTIVIDADLabel As System.Windows.Forms.Label
        Dim IDMONITORLabel As System.Windows.Forms.Label
        Dim NOMBRELabel As System.Windows.Forms.Label
        Dim HORARIOLabel As System.Windows.Forms.Label
        Dim ESTADOLabel As System.Windows.Forms.Label
        Dim PRECIOLabel As System.Windows.Forms.Label
        Dim NMINLabel As System.Windows.Forms.Label
        Dim NMAXLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Grupos))
        Me.DBDeporteDataSet = New GestionCentroDeportivo.DBDeporteDataSet
        Me.GRUPOSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GRUPOSTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.GRUPOSTableAdapter
        Me.GRUPOSBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.GRUPOSBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.IDGRUPOLabel1 = New System.Windows.Forms.Label
        Me.CODIGOINSTALACIONComboBox = New System.Windows.Forms.ComboBox
        Me.INSTALACIONESBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.INSTALACIONESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.COSACTIVIDADComboBox = New System.Windows.Forms.ComboBox
        Me.ACTIVIDADESBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ACTIVIDADESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IDMONITORComboBox = New System.Windows.Forms.ComboBox
        Me.MONITORESBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MONITORESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NOMBRETextBox = New System.Windows.Forms.TextBox
        Me.HORARIOTextBox = New System.Windows.Forms.TextBox
        Me.ESTADOTextBox = New System.Windows.Forms.TextBox
        Me.PRECIOTextBox = New System.Windows.Forms.TextBox
        Me.NMINTextBox = New System.Windows.Forms.TextBox
        Me.NMAXTextBox = New System.Windows.Forms.TextBox
        Me.PARTICIPABindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PARTICIPATableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.PARTICIPATableAdapter
        Me.INSTALACIONESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
        Me.PARTICIPADataGridView = New System.Windows.Forms.DataGridView
        Me.SOCIOSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SOCIOSTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.SOCIOSTableAdapter
        Me.ACTIVIDADESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
        Me.MONITORESTableAdapter = New GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewComboBoxColumn
        IDGRUPOLabel = New System.Windows.Forms.Label
        CODIGOINSTALACIONLabel = New System.Windows.Forms.Label
        COSACTIVIDADLabel = New System.Windows.Forms.Label
        IDMONITORLabel = New System.Windows.Forms.Label
        NOMBRELabel = New System.Windows.Forms.Label
        HORARIOLabel = New System.Windows.Forms.Label
        ESTADOLabel = New System.Windows.Forms.Label
        PRECIOLabel = New System.Windows.Forms.Label
        NMINLabel = New System.Windows.Forms.Label
        NMAXLabel = New System.Windows.Forms.Label
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GRUPOSBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GRUPOSBindingNavigator.SuspendLayout()
        CType(Me.INSTALACIONESBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ACTIVIDADESBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MONITORESBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PARTICIPABindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PARTICIPADataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SOCIOSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDGRUPOLabel
        '
        IDGRUPOLabel.AutoSize = True
        IDGRUPOLabel.Location = New System.Drawing.Point(29, 55)
        IDGRUPOLabel.Name = "IDGRUPOLabel"
        IDGRUPOLabel.Size = New System.Drawing.Size(60, 13)
        IDGRUPOLabel.TabIndex = 1
        IDGRUPOLabel.Text = "IDGRUPO:"
        '
        'CODIGOINSTALACIONLabel
        '
        CODIGOINSTALACIONLabel.AutoSize = True
        CODIGOINSTALACIONLabel.Location = New System.Drawing.Point(29, 84)
        CODIGOINSTALACIONLabel.Name = "CODIGOINSTALACIONLabel"
        CODIGOINSTALACIONLabel.Size = New System.Drawing.Size(81, 13)
        CODIGOINSTALACIONLabel.TabIndex = 3
        CODIGOINSTALACIONLabel.Text = "INSTALACION:"
        '
        'COSACTIVIDADLabel
        '
        COSACTIVIDADLabel.AutoSize = True
        COSACTIVIDADLabel.Location = New System.Drawing.Point(29, 111)
        COSACTIVIDADLabel.Name = "COSACTIVIDADLabel"
        COSACTIVIDADLabel.Size = New System.Drawing.Size(67, 13)
        COSACTIVIDADLabel.TabIndex = 5
        COSACTIVIDADLabel.Text = "ACTIVIDAD:"
        '
        'IDMONITORLabel
        '
        IDMONITORLabel.AutoSize = True
        IDMONITORLabel.Location = New System.Drawing.Point(29, 138)
        IDMONITORLabel.Name = "IDMONITORLabel"
        IDMONITORLabel.Size = New System.Drawing.Size(61, 13)
        IDMONITORLabel.TabIndex = 7
        IDMONITORLabel.Text = "MONITOR:"
        '
        'NOMBRELabel
        '
        NOMBRELabel.AutoSize = True
        NOMBRELabel.Location = New System.Drawing.Point(29, 165)
        NOMBRELabel.Name = "NOMBRELabel"
        NOMBRELabel.Size = New System.Drawing.Size(57, 13)
        NOMBRELabel.TabIndex = 9
        NOMBRELabel.Text = "NOMBRE:"
        '
        'HORARIOLabel
        '
        HORARIOLabel.AutoSize = True
        HORARIOLabel.Location = New System.Drawing.Point(29, 191)
        HORARIOLabel.Name = "HORARIOLabel"
        HORARIOLabel.Size = New System.Drawing.Size(60, 13)
        HORARIOLabel.TabIndex = 11
        HORARIOLabel.Text = "HORARIO:"
        '
        'ESTADOLabel
        '
        ESTADOLabel.AutoSize = True
        ESTADOLabel.Location = New System.Drawing.Point(29, 217)
        ESTADOLabel.Name = "ESTADOLabel"
        ESTADOLabel.Size = New System.Drawing.Size(54, 13)
        ESTADOLabel.TabIndex = 13
        ESTADOLabel.Text = "ESTADO:"
        '
        'PRECIOLabel
        '
        PRECIOLabel.AutoSize = True
        PRECIOLabel.Location = New System.Drawing.Point(29, 243)
        PRECIOLabel.Name = "PRECIOLabel"
        PRECIOLabel.Size = New System.Drawing.Size(50, 13)
        PRECIOLabel.TabIndex = 15
        PRECIOLabel.Text = "PRECIO:"
        '
        'NMINLabel
        '
        NMINLabel.AutoSize = True
        NMINLabel.Location = New System.Drawing.Point(29, 269)
        NMINLabel.Name = "NMINLabel"
        NMINLabel.Size = New System.Drawing.Size(38, 13)
        NMINLabel.TabIndex = 17
        NMINLabel.Text = "NMIN:"
        '
        'NMAXLabel
        '
        NMAXLabel.AutoSize = True
        NMAXLabel.Location = New System.Drawing.Point(29, 295)
        NMAXLabel.Name = "NMAXLabel"
        NMAXLabel.Size = New System.Drawing.Size(41, 13)
        NMAXLabel.TabIndex = 19
        NMAXLabel.Text = "NMAX:"
        '
        'DBDeporteDataSet
        '
        Me.DBDeporteDataSet.DataSetName = "DBDeporteDataSet"
        Me.DBDeporteDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GRUPOSBindingSource
        '
        Me.GRUPOSBindingSource.DataMember = "GRUPOS"
        Me.GRUPOSBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'GRUPOSTableAdapter
        '
        Me.GRUPOSTableAdapter.ClearBeforeFill = True
        '
        'GRUPOSBindingNavigator
        '
        Me.GRUPOSBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.GRUPOSBindingNavigator.BindingSource = Me.GRUPOSBindingSource
        Me.GRUPOSBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.GRUPOSBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.GRUPOSBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.GRUPOSBindingNavigatorSaveItem})
        Me.GRUPOSBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.GRUPOSBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.GRUPOSBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.GRUPOSBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.GRUPOSBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.GRUPOSBindingNavigator.Name = "GRUPOSBindingNavigator"
        Me.GRUPOSBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.GRUPOSBindingNavigator.Size = New System.Drawing.Size(623, 25)
        Me.GRUPOSBindingNavigator.TabIndex = 0
        Me.GRUPOSBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'GRUPOSBindingNavigatorSaveItem
        '
        Me.GRUPOSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GRUPOSBindingNavigatorSaveItem.Image = CType(resources.GetObject("GRUPOSBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.GRUPOSBindingNavigatorSaveItem.Name = "GRUPOSBindingNavigatorSaveItem"
        Me.GRUPOSBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.GRUPOSBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'IDGRUPOLabel1
        '
        Me.IDGRUPOLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "IDGRUPO", True))
        Me.IDGRUPOLabel1.Location = New System.Drawing.Point(146, 55)
        Me.IDGRUPOLabel1.Name = "IDGRUPOLabel1"
        Me.IDGRUPOLabel1.Size = New System.Drawing.Size(174, 23)
        Me.IDGRUPOLabel1.TabIndex = 2
        '
        'CODIGOINSTALACIONComboBox
        '
        Me.CODIGOINSTALACIONComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.GRUPOSBindingSource, "CODIGOINSTALACION", True))
        Me.CODIGOINSTALACIONComboBox.DataSource = Me.INSTALACIONESBindingSource1
        Me.CODIGOINSTALACIONComboBox.DisplayMember = "DENOMINACION"
        Me.CODIGOINSTALACIONComboBox.FormattingEnabled = True
        Me.CODIGOINSTALACIONComboBox.Location = New System.Drawing.Point(146, 81)
        Me.CODIGOINSTALACIONComboBox.Name = "CODIGOINSTALACIONComboBox"
        Me.CODIGOINSTALACIONComboBox.Size = New System.Drawing.Size(174, 21)
        Me.CODIGOINSTALACIONComboBox.TabIndex = 4
        Me.CODIGOINSTALACIONComboBox.ValueMember = "CODIGOINSTALACION"
        '
        'INSTALACIONESBindingSource1
        '
        Me.INSTALACIONESBindingSource1.DataMember = "INSTALACIONES"
        Me.INSTALACIONESBindingSource1.DataSource = Me.DBDeporteDataSet
        '
        'INSTALACIONESBindingSource
        '
        Me.INSTALACIONESBindingSource.DataMember = "INSTALACIONES"
        Me.INSTALACIONESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'COSACTIVIDADComboBox
        '
        Me.COSACTIVIDADComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.GRUPOSBindingSource, "COSACTIVIDAD", True))
        Me.COSACTIVIDADComboBox.DataSource = Me.ACTIVIDADESBindingSource1
        Me.COSACTIVIDADComboBox.DisplayMember = "TITULO"
        Me.COSACTIVIDADComboBox.FormattingEnabled = True
        Me.COSACTIVIDADComboBox.Location = New System.Drawing.Point(146, 108)
        Me.COSACTIVIDADComboBox.Name = "COSACTIVIDADComboBox"
        Me.COSACTIVIDADComboBox.Size = New System.Drawing.Size(174, 21)
        Me.COSACTIVIDADComboBox.TabIndex = 6
        Me.COSACTIVIDADComboBox.ValueMember = "COSACTIVIDAD"
        '
        'ACTIVIDADESBindingSource1
        '
        Me.ACTIVIDADESBindingSource1.DataMember = "ACTIVIDADES"
        Me.ACTIVIDADESBindingSource1.DataSource = Me.DBDeporteDataSet
        '
        'ACTIVIDADESBindingSource
        '
        Me.ACTIVIDADESBindingSource.DataMember = "ACTIVIDADES"
        Me.ACTIVIDADESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'IDMONITORComboBox
        '
        Me.IDMONITORComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.GRUPOSBindingSource, "IDMONITOR", True))
        Me.IDMONITORComboBox.DataSource = Me.MONITORESBindingSource1
        Me.IDMONITORComboBox.DisplayMember = "NOMBRE_COMPLETO"
        Me.IDMONITORComboBox.FormattingEnabled = True
        Me.IDMONITORComboBox.Location = New System.Drawing.Point(146, 135)
        Me.IDMONITORComboBox.Name = "IDMONITORComboBox"
        Me.IDMONITORComboBox.Size = New System.Drawing.Size(174, 21)
        Me.IDMONITORComboBox.TabIndex = 8
        Me.IDMONITORComboBox.ValueMember = "IDMONITOR"
        '
        'MONITORESBindingSource1
        '
        Me.MONITORESBindingSource1.DataMember = "MONITORES"
        Me.MONITORESBindingSource1.DataSource = Me.DBDeporteDataSet
        '
        'MONITORESBindingSource
        '
        Me.MONITORESBindingSource.DataMember = "MONITORES"
        Me.MONITORESBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'NOMBRETextBox
        '
        Me.NOMBRETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "NOMBRE", True))
        Me.NOMBRETextBox.Location = New System.Drawing.Point(146, 162)
        Me.NOMBRETextBox.Name = "NOMBRETextBox"
        Me.NOMBRETextBox.Size = New System.Drawing.Size(174, 20)
        Me.NOMBRETextBox.TabIndex = 10
        '
        'HORARIOTextBox
        '
        Me.HORARIOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "HORARIO", True))
        Me.HORARIOTextBox.Location = New System.Drawing.Point(146, 188)
        Me.HORARIOTextBox.Name = "HORARIOTextBox"
        Me.HORARIOTextBox.Size = New System.Drawing.Size(174, 20)
        Me.HORARIOTextBox.TabIndex = 12
        '
        'ESTADOTextBox
        '
        Me.ESTADOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "ESTADO", True))
        Me.ESTADOTextBox.Location = New System.Drawing.Point(146, 214)
        Me.ESTADOTextBox.Name = "ESTADOTextBox"
        Me.ESTADOTextBox.Size = New System.Drawing.Size(174, 20)
        Me.ESTADOTextBox.TabIndex = 14
        '
        'PRECIOTextBox
        '
        Me.PRECIOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "PRECIO", True))
        Me.PRECIOTextBox.Location = New System.Drawing.Point(146, 240)
        Me.PRECIOTextBox.Name = "PRECIOTextBox"
        Me.PRECIOTextBox.Size = New System.Drawing.Size(174, 20)
        Me.PRECIOTextBox.TabIndex = 16
        '
        'NMINTextBox
        '
        Me.NMINTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "NMIN", True))
        Me.NMINTextBox.Location = New System.Drawing.Point(146, 266)
        Me.NMINTextBox.Name = "NMINTextBox"
        Me.NMINTextBox.Size = New System.Drawing.Size(174, 20)
        Me.NMINTextBox.TabIndex = 18
        '
        'NMAXTextBox
        '
        Me.NMAXTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GRUPOSBindingSource, "NMAX", True))
        Me.NMAXTextBox.Location = New System.Drawing.Point(146, 292)
        Me.NMAXTextBox.Name = "NMAXTextBox"
        Me.NMAXTextBox.Size = New System.Drawing.Size(174, 20)
        Me.NMAXTextBox.TabIndex = 20
        '
        'PARTICIPABindingSource
        '
        Me.PARTICIPABindingSource.DataMember = "FK__PARTICIPA__IDGRU__0BC6C43E"
        Me.PARTICIPABindingSource.DataSource = Me.GRUPOSBindingSource
        '
        'PARTICIPATableAdapter
        '
        Me.PARTICIPATableAdapter.ClearBeforeFill = True
        '
        'INSTALACIONESTableAdapter
        '
        Me.INSTALACIONESTableAdapter.ClearBeforeFill = True
        '
        'PARTICIPADataGridView
        '
        Me.PARTICIPADataGridView.AutoGenerateColumns = False
        Me.PARTICIPADataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1})
        Me.PARTICIPADataGridView.DataSource = Me.PARTICIPABindingSource
        Me.PARTICIPADataGridView.Location = New System.Drawing.Point(352, 55)
        Me.PARTICIPADataGridView.Name = "PARTICIPADataGridView"
        Me.PARTICIPADataGridView.Size = New System.Drawing.Size(244, 257)
        Me.PARTICIPADataGridView.TabIndex = 21
        '
        'SOCIOSBindingSource
        '
        Me.SOCIOSBindingSource.DataMember = "SOCIOS"
        Me.SOCIOSBindingSource.DataSource = Me.DBDeporteDataSet
        '
        'SOCIOSTableAdapter
        '
        Me.SOCIOSTableAdapter.ClearBeforeFill = True
        '
        'ACTIVIDADESTableAdapter
        '
        Me.ACTIVIDADESTableAdapter.ClearBeforeFill = True
        '
        'MONITORESTableAdapter
        '
        Me.MONITORESTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "IDSOCIO"
        Me.DataGridViewTextBoxColumn1.DataSource = Me.SOCIOSBindingSource
        Me.DataGridViewTextBoxColumn1.DisplayMember = "NOMBRE_COMPLETO"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Socios que integran este grupo:"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn1.ValueMember = "IDSOCIO"
        Me.DataGridViewTextBoxColumn1.Width = 200
        '
        'Grupos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(623, 360)
        Me.Controls.Add(Me.PARTICIPADataGridView)
        Me.Controls.Add(IDGRUPOLabel)
        Me.Controls.Add(Me.IDGRUPOLabel1)
        Me.Controls.Add(CODIGOINSTALACIONLabel)
        Me.Controls.Add(Me.CODIGOINSTALACIONComboBox)
        Me.Controls.Add(COSACTIVIDADLabel)
        Me.Controls.Add(Me.COSACTIVIDADComboBox)
        Me.Controls.Add(IDMONITORLabel)
        Me.Controls.Add(Me.IDMONITORComboBox)
        Me.Controls.Add(NOMBRELabel)
        Me.Controls.Add(Me.NOMBRETextBox)
        Me.Controls.Add(HORARIOLabel)
        Me.Controls.Add(Me.HORARIOTextBox)
        Me.Controls.Add(ESTADOLabel)
        Me.Controls.Add(Me.ESTADOTextBox)
        Me.Controls.Add(PRECIOLabel)
        Me.Controls.Add(Me.PRECIOTextBox)
        Me.Controls.Add(NMINLabel)
        Me.Controls.Add(Me.NMINTextBox)
        Me.Controls.Add(NMAXLabel)
        Me.Controls.Add(Me.NMAXTextBox)
        Me.Controls.Add(Me.GRUPOSBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Grupos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Grupos"
        CType(Me.DBDeporteDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GRUPOSBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GRUPOSBindingNavigator.ResumeLayout(False)
        Me.GRUPOSBindingNavigator.PerformLayout()
        CType(Me.INSTALACIONESBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.INSTALACIONESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ACTIVIDADESBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ACTIVIDADESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MONITORESBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MONITORESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PARTICIPABindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PARTICIPADataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SOCIOSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DBDeporteDataSet As GestionCentroDeportivo.DBDeporteDataSet
    Friend WithEvents GRUPOSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GRUPOSTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.GRUPOSTableAdapter
    Friend WithEvents GRUPOSBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GRUPOSBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IDGRUPOLabel1 As System.Windows.Forms.Label
    Friend WithEvents CODIGOINSTALACIONComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents COSACTIVIDADComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents IDMONITORComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents NOMBRETextBox As System.Windows.Forms.TextBox
    Friend WithEvents HORARIOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ESTADOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PRECIOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NMINTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NMAXTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PARTICIPABindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PARTICIPATableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.PARTICIPATableAdapter
    Friend WithEvents INSTALACIONESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents INSTALACIONESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.INSTALACIONESTableAdapter
    Friend WithEvents PARTICIPADataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents SOCIOSBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SOCIOSTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.SOCIOSTableAdapter
    Friend WithEvents ACTIVIDADESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ACTIVIDADESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.ACTIVIDADESTableAdapter
    Friend WithEvents MONITORESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MONITORESTableAdapter As GestionCentroDeportivo.DBDeporteDataSetTableAdapters.MONITORESTableAdapter
    Friend WithEvents INSTALACIONESBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents ACTIVIDADESBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents MONITORESBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewComboBoxColumn
End Class
