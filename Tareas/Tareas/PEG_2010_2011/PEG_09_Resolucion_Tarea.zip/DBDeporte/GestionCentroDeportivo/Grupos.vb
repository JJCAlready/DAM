Public Class Grupos
    ''' <summary>
    ''' Guardamos los cambios, tanto del maestro (tabla GRUPOS)como del detalle (tabla PARTICIPA)
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>El c�digo generado por Microsoft Visual Basic 2005 Express solo guarda los cambios del maestro</remarks>
    Private Sub GRUPOSBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GRUPOSBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.GRUPOSBindingSource.EndEdit()
        Me.GRUPOSTableAdapter.Update(Me.DBDeporteDataSet.GRUPOS)
        Me.PARTICIPABindingSource.EndEdit()
        Me.PARTICIPATableAdapter.Update(Me.DBDeporteDataSet.PARTICIPA)
    End Sub

    Private Sub Grupos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.MONITORES' Puede moverla o quitarla seg�n sea necesario.
        Me.MONITORESTableAdapter.Fill(Me.DBDeporteDataSet.MONITORES)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.ACTIVIDADES' Puede moverla o quitarla seg�n sea necesario.
        Me.ACTIVIDADESTableAdapter.Fill(Me.DBDeporteDataSet.ACTIVIDADES)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.SOCIOS' Puede moverla o quitarla seg�n sea necesario.
        Me.SOCIOSTableAdapter.Fill(Me.DBDeporteDataSet.SOCIOS)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.INSTALACIONES' Puede moverla o quitarla seg�n sea necesario.
        Me.INSTALACIONESTableAdapter.Fill(Me.DBDeporteDataSet.INSTALACIONES)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.PARTICIPA' Puede moverla o quitarla seg�n sea necesario.
        Me.PARTICIPATableAdapter.Fill(Me.DBDeporteDataSet.PARTICIPA)
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.GRUPOS' Puede moverla o quitarla seg�n sea necesario.
        Me.GRUPOSTableAdapter.Fill(Me.DBDeporteDataSet.GRUPOS)
    End Sub
End Class