Public Class Actividades

    Private Sub ACTIVIDADESBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ACTIVIDADESBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ACTIVIDADESBindingSource.EndEdit()
        Me.ACTIVIDADESTableAdapter.Update(Me.DBDeporteDataSet.ACTIVIDADES)

    End Sub

    Private Sub Actividades_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta l�nea de c�digo carga datos en la tabla 'DBDeporteDataSet.ACTIVIDADES' Puede moverla o quitarla seg�n sea necesario.
        Me.ACTIVIDADESTableAdapter.Fill(Me.DBDeporteDataSet.ACTIVIDADES)

    End Sub
End Class
