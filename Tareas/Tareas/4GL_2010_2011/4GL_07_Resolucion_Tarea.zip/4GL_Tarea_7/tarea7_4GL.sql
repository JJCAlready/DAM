/*
Created		05/03/2011
Modified		06/03/2011
Project		Tarea 7 - 4GL
Model		numismatica
Company		Junta de Andalucia - Consejer�a de Educaci�n
Author		
Version		1.0.0
Database		Oracle 10g 
*/


-- Create Types section


-- Create Tables section


Create table "Moneda" (
	"codigo" Varchar2 (10) NOT NULL ,
	"cod_molde" Varchar2 (10) NOT NULL ,
	"descripcion" Varchar2 (30),
	"es_variante" Varchar2 (30),
primary key ("codigo") 
) 
/

Create table "Ejemplar" (
	"desc" Varchar2 (30),
	"codigo" Varchar2 (10) NOT NULL ,
	"iniciales" Varchar2 (10) NOT NULL ,
primary key ("codigo") 
) 
/

Create table "Estado" (
	"iniciales" Varchar2 (10) NOT NULL ,
	"nom" Varchar2 (30),
	"desc" Varchar2 (30),
primary key ("iniciales") 
) 
/

Create table "catalogada" (
	"codigo" Varchar2 (10),
	"iniciales" Varchar2 (10),
	"precio_aproximado" Decimal(9,2)
) 
/

Create table "Molde" (
	"cod_molde" Varchar2 (10) NOT NULL ,
	"cod_modelo" Varchar2 (10) NOT NULL ,
	"descripci" Varchar2 (30),
	"fecha_estrellas" Date,
	"anyo_grabado" Decimal(4,0),
	"anyo_acunyacion" Decimal(4,0),
primary key ("cod_molde") 
) 
/

Create table "Modelo" (
	"cod_modelo" Varchar2 (10) NOT NULL ,
	"valor" Decimal(9,2),
	"desc" Varchar2 (30),
	"peso" Decimal(2,3),
primary key ("cod_modelo") 
) 
/

Create table "Metal" (
	"nombre" Varchar2 (30) NOT NULL ,
primary key ("nombre") 
) 
/

Create table "Compone" (
	"cod_modelo" Varchar2 (10),
	"nombre" Varchar2 (30) NOT NULL ,
	"ley" Varchar2 (30),
	"proporcion" Decimal(1,4)
) 
/


-- Create Foreign keys section

Alter table "Ejemplar" add  foreign key ("codigo") references "Moneda" ("codigo") 
/

Alter table "catalogada" add  foreign key ("codigo") references "Moneda" ("codigo") 
/

Alter table "Ejemplar" add  foreign key ("iniciales") references "Estado" ("iniciales")  on delete set null
/

Alter table "catalogada" add  foreign key ("iniciales") references "Estado" ("iniciales") 
/

Alter table "Moneda" add  foreign key ("cod_molde") references "Molde" ("cod_molde") 
/

Alter table "Molde" add  foreign key ("cod_modelo") references "Modelo" ("cod_modelo") 
/

Alter table "Compone" add  foreign key ("cod_modelo") references "Modelo" ("cod_modelo")  on delete cascade
/

Alter table "Compone" add  foreign key ("nombre") references "Metal" ("nombre") 
/


-- Create Table comments section


-- Create Attribute comments section


