﻿/*
Created		10/02/2011
Modified		02/03/2011
Project		Pr�ctica 6 - 4GL
Model		E/R
Company		
Author		
Version		1
Database		mySQL 5 
*/


drop table IF EXISTS Banco.Asesora;
drop table IF EXISTS Banco.Pertenece;
drop table IF EXISTS Banco.Cuenta_Ahorro;
drop table IF EXISTS Banco.Cuenta_Corriente;
drop table IF EXISTS Banco.Tarjeta;
drop table IF EXISTS Banco.operacion;
drop table IF EXISTS Banco.Cuenta;
drop table IF EXISTS Banco.Cliente;
drop table IF EXISTS Banco.Empleado;
drop table IF EXISTS Banco.Sucursal;


Create table if not exists Banco.Sucursal (
	Id_sucursal Char(5) NOT NULL,
	Direcci_n Char(30),
	Id_emple Char(5) NOT NULL,
	UNIQUE (Id_sucursal),
	UNIQUE (Id_emple),
 Primary Key (Id_sucursal)) ENGINE = InnoDB;

Create table if not exists Banco.Empleado (
	Id_emple Char(5) NOT NULL,
	Dni Char(9),
	Id_sucursal Char(5) NOT NULL,
	UNIQUE (Id_emple),
	UNIQUE (Dni),
 Primary Key (Id_emple)) ENGINE = InnoDB;

Create table if not exists Banco.Cliente (
	Id_Cliente Char(5) NOT NULL,
	Id_Cliente_Aval Char(5),
	DNI Char(9),
	UNIQUE (Id_Cliente),
 Primary Key (Id_Cliente)) ENGINE = InnoDB;

Create table if not exists Banco.Cuenta (
	N_cuenta Char(20) NOT NULL,
	Saldo Decimal(12,2),
	Id_sucursal Char(5) NOT NULL,
	UNIQUE (N_cuenta),
 Primary Key (N_cuenta)) ENGINE = InnoDB;

Create table if not exists Banco.Operacion (
	N_operacion Char(20) NOT NULL,
	Tipo Char(10),
	Importe Decimal(12,2),
	fecha Datetime,
	N_cuenta Char(20) NOT NULL,
 Primary Key (N_operacion,N_cuenta)) ENGINE = InnoDB;

Create table if not exists Banco.Tarjeta (
	N_tarjeta Char(12) NOT NULL,
	Cr_dito Int,
	N_cuenta Char(20) NOT NULL,
	UNIQUE (N_tarjeta),
 Primary Key (N_tarjeta,N_cuenta)) ENGINE = InnoDB;

Create table if not exists Banco.Cuenta_Corriente (
	Descubierto Decimal(6,2),
	N_cuenta Char(20) NOT NULL,
	UNIQUE (N_cuenta),
 Primary Key (N_cuenta)) ENGINE = InnoDB;

Create table if not exists Banco.Cuenta_Ahorro (
	T_interes Decimal(2,2),
	N_cuenta Char(20) NOT NULL,
	UNIQUE (N_cuenta),
 Primary Key (N_cuenta)) ENGINE = InnoDB;

Create table if not exists Banco.Pertenece (
	N_cuenta Char(20) NOT NULL,
	Id_Cliente Char(5) NOT NULL,
 Primary Key (N_cuenta,Id_Cliente)) ENGINE = InnoDB;

Create table if not exists Banco.Asesora (
	Id_emple Char(5) NOT NULL,
	Id_Cliente Char(5) NOT NULL,
	Fecha Date NOT NULL,
	Motivo Varchar(200),
 Primary Key (Id_emple,Id_Cliente,Fecha)) ENGINE = InnoDB;


Alter table Banco.Empleado add Constraint Trabaja Foreign Key (Id_sucursal) references Banco.Sucursal (Id_sucursal) on delete  restrict on update cascade;
Alter table Banco.Cuenta add Constraint Tiene Foreign Key (Id_sucursal) references Banco.Sucursal (Id_sucursal) on delete  restrict on update cascade;
Alter table Banco.Sucursal add Constraint Dirige Foreign Key (Id_emple) references Banco.Empleado (Id_emple) on delete  restrict on update cascade;
Alter table Banco.Asesora add Constraint Empleado_Asesora_Cliente Foreign Key (Id_emple) references Banco.Empleado (Id_emple) on delete cascade on update cascade;
Alter table Banco.Cliente add Constraint Avala Foreign Key (Id_Cliente_Aval) references Banco.Cliente (Id_Cliente) on delete  restrict on update cascade;
Alter table Banco.Pertenece add Constraint Cliente_Pertenece_Cuenta Foreign Key (Id_Cliente) references Banco.Cliente (Id_Cliente) on delete  restrict on update cascade;
Alter table Banco.Asesora add Constraint Cliente_Asesorado_Empleado Foreign Key (Id_Cliente) references Banco.Cliente (Id_Cliente) on delete cascade on update cascade;
Alter table Banco.operacion add Constraint Se_realiza Foreign Key (N_cuenta) references Banco.Cuenta (N_cuenta) on delete cascade on update cascade;
Alter table Banco.Cuenta_Corriente add Constraint tipo_CC Foreign Key (N_cuenta) references Banco.Cuenta (N_cuenta) on delete cascade on update cascade;
Alter table Banco.Cuenta_Ahorro add Constraint tipo_CH Foreign Key (N_cuenta) references Banco.Cuenta (N_cuenta) on delete cascade on update cascade;
Alter table Banco.Pertenece add Constraint Cuenta_Pertenece_Cliente Foreign Key (N_cuenta) references Banco.Cuenta (N_cuenta) on delete  restrict on update  restrict;
Alter table Banco.Tarjeta add Constraint Asocia Foreign Key (N_cuenta) references Banco.Cuenta_Corriente (N_cuenta) on delete  restrict on update  restrict;

